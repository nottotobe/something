module.exports = {
  productionSourceMap: false,
  assetsDir: 'static',
  devServer: {
    proxy: {
      '/oam': {
        // target: 'http://172.1.213.32:7070/',
        target: 'http://10.0.1.95:7070/',
        changeOrigin: true,
        pathRewrite: {
          '^/oam': '/oam'
        }
      }
    }
  },
  configureWebpack: config => {
    if (process.env.NODE_ENV === 'production') {
      // 为生产环境修改配置...
    } else {
      // 为开发环境修改配置...
    }
  },
  chainWebpack: config => {
    config.plugin('html').tap(args => {
      args[0].title = process.env.VUE_APP_TITLE
      return args
    })
    // ============压缩图片 start============

    // ============压缩图片 end============
  }
  // publicPath: '/oam/'
}
