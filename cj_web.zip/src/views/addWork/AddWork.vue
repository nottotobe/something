<template>
  <My-tabs ref="myTabs" :tabTitle="'新建工单'">
    <template v-slot:collapseTab>
      <New-work ref="workForm" />
    </template>
  </My-tabs>
</template>

<script>
import NewWork from '../query/components/NewWork'
export default {
  name: 'AddWork',
  components: {
    NewWork
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
