<template>
  <My-tabs :tabTitle="'工单数据统计'">
    <template v-slot:collapseTab>
      <el-form :model="filterForm">
        <el-row :gutter="24">
          <el-col :span="6">
            <el-form-item label="提交日期" prop="dateRange">
              <el-date-picker
                v-model="filterForm.dateRange"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                unlink-panels
                value-format="yyyy-MM-dd HH:mm:ss"
                :default-time="['00:00:00', '23:59:59']"
              >
                >
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="工单数据统计" prop="endTime">
              <el-input v-model="filterForm.totle" placeholder="请输入内容" disabled></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </template>

    <el-row :gutter="24" class="echarts_box" v-if="filterForm.totle > 0">
      <el-col :span="14">
        <el-card>
          <el-button class="export" type="text" @click="exportExcel('addtickets')">导出</el-button>
          <My-echarts :timeRang="filterForm.dateRange" :uuid="'work'" :uuoptions="workData" />
        </el-card>
      </el-col>
      <el-col :span="10">
        <el-card>
          <el-button class="export" type="text" @click="exportExcel('optTickets')">导出</el-button>
          <My-echarts :timeRang="filterForm.dateRange" :uuid="'opt'" :uuoptions="optData" />
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card>
          <el-button class="export" type="text" @click="exportExcel('platformTickets')"
            >导出</el-button
          >
          <My-echarts
            :timeRang="filterForm.dateRange"
            :uuid="'platform'"
            :uuoptions="platformData"
          />
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card>
          <el-button class="export" type="text" @click="exportExcel('typeTickets')">导出</el-button>
          <My-echarts :timeRang="filterForm.dateRange" :uuid="'type'" :uuoptions="typeData" />
        </el-card>
      </el-col>
      <el-col :span="24" v-show="$route.query.isAdmin === 'admin'">
        <el-card>
          <el-button class="export" type="text" @click="exportExcel('processTickets')"
            >导出</el-button
          >
          <My-echarts :timeRang="filterForm.dateRange" :uuid="'process'" :uuoptions="processData" />
        </el-card>
      </el-col>
    </el-row>
    <el-empty :image-size="300" v-else></el-empty>
  </My-tabs>
</template>

<script>
import MyEcharts from '@/components/MyEcharts'
import { getStatisticData } from '@/api/user'
export default {
  name: 'Statistics',
  data() {
    return {
      filterForm: {
        startTime: '',
        endTime: '',
        dateRange: [],
        totle: ''
      },
      workData: {},
      optData: {},
      platformData: {},
      typeData: {},
      processData: {}
    }
  },
  components: {
    MyEcharts
  },
  watch: {
    'filterForm.dateRange'(value) {
      if (value) {
        this.filterForm.startTime = value[0]
        this.filterForm.endTime = value[1]
      } else {
        this.filterForm.startTime = ''
        this.filterForm.endTime = ''
      }
      this.statisticDataInit()
    }
  },
  mounted() {
    this.statisticDataInit(true)
  },
  activated() {
    this.statisticDataInit()
  },
  methods: {
    // 初始化
    async statisticDataInit(flag) {
      if (flag) {
        const end = new Date()
        const start = new Date()
        start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
        this.filterForm.startTime = this.timestampToTime(start, true)
        this.filterForm.endTime = this.timestampToTime(end)
        this.filterForm.dateRange.push(this.filterForm.startTime)
        this.filterForm.dateRange.push(this.filterForm.endTime)
      }

      const res = await getStatisticData(this.filterForm)
      if (res.data.status === 200) {
        this.filterForm.totle = res.data.obj.totle
        this.workDataDeal(res.data.obj.addtickets)
        this.optDataDeal(res.data.obj.optTickets)
        this.platformDataDeal(res.data.obj.platformTickets)
        this.typeDataDeal(res.data.obj.typeTickets)
        this.processDataDeal(res.data.obj.processTickets)
      } else {
        this.filterForm.totle = 0
        this.$message.error(res.data.msg)
      }
    },
    // 工单数据统计
    workDataDeal(v) {
      // console.log('工单数据', v)
      const xAxisList = []
      const seriesList = []
      v.forEach(item => {
        xAxisList.push(item.date)
        seriesList.push(item.count)
      })
      this.workData = {
        title: {
          text: '工单数据统计'
        },
        tooltip: {},
        xAxis: {
          data: xAxisList
        },
        yAxis: {},
        series: [
          {
            name: '数量',
            type: 'bar',
            data: seriesList
          }
        ],
        animationDuration: 2000
      }
    },
    // 提交机构统计
    optDataDeal(v) {
      // console.log('提交机构', v)
      const arr = []
      v.forEach(item => {
        arr.push({ name: item.dptName, value: item.count })
      })
      this.optData = {
        title: {
          text: '提交机构统计'
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b} :<span style="font-weight:900"> {c} </span>({d}%)'
        },
        legend: {
          orient: 'vertical',
          right: '0',
          top: 'center'
        },
        series: [
          {
            name: '机构',
            type: 'pie',
            center: ['40%', '50%'],
            label: {
              show: false
            },
            data: arr,
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      }
    },
    // 问题平台统计
    platformDataDeal(v) {
      // console.log('问题平台', v)
      const arr = []
      v.forEach(item => {
        arr.push({ name: item.C_NAME, value: item.count })
      })
      this.platformData = {
        title: {
          text: '问题平台统计'
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b} :<span style="font-weight:900"> {c} </span>({d}%)'
        },
        legend: {
          orient: 'vertical',
          right: '0',
          top: 'center'
        },
        series: [
          {
            name: '平台',
            type: 'pie',
            center: ['40%', '50%'],
            label: {
              show: false
            },
            data: arr,
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      }
    },
    // 问题类型统计
    typeDataDeal(v) {
      // console.log('问题类型', v)
      const arr = []
      v.forEach(item => {
        arr.push({ name: item.C_NAME, value: item.count })
      })
      this.typeData = {
        title: {
          text: '问题类型统计'
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b} :<span style="font-weight:900"> {c} </span>({d}%)'
        },
        legend: {
          orient: 'vertical',
          right: '0',
          top: 'center'
        },
        series: [
          {
            name: '类型',
            type: 'pie',
            center: ['40%', '50%'],
            label: {
              show: false
            },
            data: arr,
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      }
    },
    // 工单处理统计
    processDataDeal(v) {
      // console.log('工单处理', v)
      const xAxisList = []
      const seriesXList = []
      const seriesYList = []
      v.forEach(item => {
        xAxisList.push(item.userName)
        seriesXList.push(item.processing)
        seriesYList.push(item.processed)
      })
      this.processData = {
        title: {
          text: '工单数据统计'
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        legend: {
          data: ['处理中', '超时']
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: xAxisList
        },
        yAxis: {
          type: 'value',
          boundaryGap: [0, 0.01]
        },
        series: [
          {
            name: '处理中',
            type: 'bar',
            data: seriesXList
          },
          {
            name: '超时',
            type: 'bar',
            data: seriesYList
          }
        ],
        animationDuration: 2000
      }
    },
    // 转换时间
    timestampToTime(timestamp, flag) {
      var date = new Date(timestamp)
      var Y = date.getFullYear() + '-'
      var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-'
      var D = date.getDate() + ' '
      // var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':'
      // var m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':'
      // var s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()
      var hms = flag ? '00:00:00' : '23:59:59'
      return Y + M + D + hms
    },
    // 导出
    exportExcel(v) {
      const pars =
        'startTime=' +
        this.filterForm.startTime +
        '&endTime=' +
        this.filterForm.endTime +
        '&type=' +
        v
      window.open('/oam/ticket/export/statistic?' + pars, '_parent')
    }
  }
}
</script>

<style scoped lang="less">
.echarts_box {
  .el-col {
    margin-bottom: 20px;
    .el-card {
      position: relative;
      width: 100%;
      height: 550px;
      padding: 20px;
      box-sizing: border-box;
      /deep/ .el-card__body {
        padding: 0;
        height: 100%;
      }
      .export {
        position: absolute;
        top: 22px;
        right: 20px;
        font-size: 20px;
        padding: 0 0;
        z-index: 9;
      }
    }
  }
}
</style>
