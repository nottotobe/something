<template>
  <div>
    <!-- <iframe :src="customerSrc" frameborder="0" target="_parent"></iframe> -->
    <el-button @click="customerInit">登陆</el-button>
  </div>
</template>

<script>
import { getCustomer } from '@/api/user'
export default {
  name: 'Customer',
  data() {
    return {
      customerSrc: ''
    }
  },
  mounted() {},
  methods: {
    async customerInit() {
      const res = await getCustomer()
      const par = res.data.obj
      this.customerSrc =
        par.url +
        '?pId=' +
        par.pId +
        '&nonce=' +
        par.nonce +
        '&timestamp=' +
        par.timestamp +
        '&sign=' +
        par.sign
      window.open(this.customerSrc)
    }
  }
}
</script>

<style scoped lang="less"></style>
