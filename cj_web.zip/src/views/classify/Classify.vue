<template>
  <div>
    <My-tabs :tabTitle="publicTitle">
      <template v-slot:collapseTab>
        <el-table
          ref="tableRef"
          :data="tableData"
          stripe
          style="width:100%"
          class="publicTable"
          @row-click="rowClick"
          @selection-change="selectionChange"
          @sort-change="tableSortChange"
        >
          <el-table-column type="selection"> </el-table-column>
          <el-table-column
            label="ID"
            prop="id"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column
            :label="publicTitle"
            prop="name"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column
            label="提交机构"
            prop="createdByDptName"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column
            label="提交人"
            prop="createdByUserName"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column
            label="提交时间"
            prop="createdTime"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column label="启用" prop="status" show-overflow-tooltip>
            <template slot-scope="scope">
              <el-switch
                v-model="scope.row.status"
                @click.native.stop
                inactive-value="0"
                active-value="1"
                @change="stateChange(scope.row.id, scope.row.status)"
              ></el-switch>
            </template>
          </el-table-column>
        </el-table>

        <el-pagination
          layout="total, prev, pager, next, jumper"
          :total="filterForm.pagTotal"
          :page-size="filterForm.size"
          :current-page="filterForm.page"
          background
          @current-change="currentChange"
        >
        </el-pagination>

        <el-row class="tableBtn">
          <el-button type="primary" round @click="addClassify">新增</el-button>
          <el-button type="primary" round @click="editClassify">修改</el-button>
        </el-row>
      </template>
    </My-tabs>
    <My-dialog :title="titleDia" :className="'publicNDialog'" ref="addCDPDia" :width="'40%'">
      <Add-CDP
        @classifyDataReset="classifyInit"
        :publicLabel="publicLabel"
        :keyword="keyword"
        :flag="flag"
        :rows="rows"
      />
    </My-dialog>
  </div>
</template>

<script>
import AddCDP from './components/AddCDP'
import { getClassifyData, classifyReset } from '@/api/user'
import { tableMix } from '@/mixins'
export default {
  name: 'Classify',
  components: {
    AddCDP
  },
  mixins: [tableMix],
  data() {
    return {
      publicTitle: '',
      publicLabel: '',
      titleDia: '',
      keyword: '',
      flag: '',
      rows: {},
      filterForm: {
        page: 1,
        size: 10,
        pagTotal: 0
      }
    }
  },
  mounted() {
    this.classifyInit()
  },
  watch: {
    $route(to, from) {
      this.classifyInit()
    }
  },
  methods: {
    // 新增
    addClassify() {
      this.$refs.addCDPDia.dialogVisible = true
      this.flag = 'add'

      switch (this.keyword) {
        case 'platform':
          this.titleDia = '新增问题平台'
          break
        case 'type':
          this.titleDia = '新增问题分类'
          break
        case 'urgent':
          this.titleDia = '新增紧急程度'
          break
      }
    },

    // 修改
    editClassify() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      if (this.selectedRows.length > 1) return this.$message.warning('只能勾选一条数据')
      this.$refs.addCDPDia.dialogVisible = true
      this.flag = 'edit'
      this.rows = this.selectedRows[0]
      switch (this.keyword) {
        case 'platform':
          this.titleDia = '修改问题平台'
          break
        case 'type':
          this.titleDia = '修改问题分类'
          break
        case 'urgent':
          this.titleDia = '修改紧急程度'
          break
      }
    },

    // switch发生改变时候的回调
    async stateChange(id, status) {
      const res = await classifyReset({
        id,
        status
      })
      if (res.data.status !== 200) {
        this.$message.error(res.data.msg)
      }
    },

    // 表格排序
    tableSortChange(par) {
      this.sortChange(par, this.classifyInit)
    },

    // 分页改变
    currentChange(currentPage) {
      this.filterForm.page = currentPage
      this.classifyInit()
    },

    // 初始化
    async classifyInit(v, p) {
      if (v) {
        this.$refs.addCDPDia.dialogVisible = false
      }
      if (p) return

      if (this.$route.path === '/typesPlatform') {
        this.publicTitle = '问题平台'
        this.publicLabel = '问题平台名称'
        this.keyword = 'platform'
      }
      if (this.$route.path === '/typesType') {
        this.publicTitle = '问题类型'
        this.publicLabel = '问题分类名称'
        this.keyword = 'type'
      }
      if (this.$route.path === '/typesUrgent') {
        this.publicTitle = '紧急程度'
        this.publicLabel = '紧急程度名称'
        this.keyword = 'urgent'
      }
      this.filterForm.item = this.keyword
      const res = await getClassifyData(this.filterForm)
      this.tableData = res.data.obj.typesList
      this.filterForm.pagTotal = res.data.obj.totle
    }
  }
}
</script>

<style scoped lang="less"></style>
