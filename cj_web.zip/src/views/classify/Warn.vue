<template>
  <div>
    <My-tabs :tabTitle="'预紧管理'">
      <template v-slot:collapseTab>
        <el-form :model="filterForm" ref="formRef">
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="提交人" prop="createdByUserName">
                <el-input
                  v-model="filterForm.createdByUserName"
                  placeholder="请输入内容"
                  clearable
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="问题平台" prop="platform">
                <el-select v-model="filterForm.platform" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in newPlatformList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="问题类型" prop="type">
                <el-select v-model="filterForm.type" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in newTypeList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="紧急程度" prop="urgent">
                <el-select v-model="filterForm.urgent" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in newUrgentList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="提交日期" prop="dateRange">
                <el-date-picker
                  v-model="filterForm.dateRange"
                  type="daterange"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  unlink-panels
                  value-format="yyyy-MM-dd HH:mm:ss"
                  :default-time="['00:00:00', '23:59:59']"
                >
                  >
                </el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="是否启用" prop="status">
                <el-select v-model="filterForm.status" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in statusList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col class="formBtn">
              <el-button type="primary" round @click="warnDataInit('query')">查询</el-button>
              <el-button round type="info" plain @click="resetForm('formRef')">重置</el-button>
            </el-col>
          </el-row>
        </el-form>
      </template>

      <el-table
        ref="tableRef"
        :data="tableData"
        stripe
        style="width:100%"
        class="publicTable"
        @row-click="rowClick"
        @selection-change="selectionChange"
        @sort-change="tableSortChange"
      >
        <el-table-column type="selection"> </el-table-column>
        <el-table-column
          label="ID"
          prop="id"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="问题平台"
          prop="platform"
          show-overflow-tooltip
          :formatter="tableFormatter"
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="问题类型"
          prop="type"
          show-overflow-tooltip
          :formatter="tableFormatter"
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="紧急程度"
          prop="urgent"
          show-overflow-tooltip
          :formatter="tableFormatter"
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="处理时长"
          prop="threshold"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="提交机构"
          prop="createdDptName"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="提交人"
          prop="createdByUserName"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="提交时间"
          prop="createdTime"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column label="启用" show-overflow-tooltip prop="status">
          <template slot-scope="scope">
            <el-switch
              v-model="scope.row.status"
              @click.native.stop
              @change="stateChange(scope.row.id, scope.row.status)"
              inactive-value="0"
              active-value="1"
            ></el-switch>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        layout="total, prev, pager, next, jumper"
        :total="filterForm.pagTotal"
        :page-size="filterForm.size"
        :current-page="filterForm.page"
        background
        @current-change="currentChange"
      >
      </el-pagination>

      <el-row class="tableBtn">
        <el-button type="primary" round @click="$refs.addWarnDia.dialogVisible = true"
          >新增</el-button
        >
        <el-button type="primary" round @click="editWarn">修改</el-button>
      </el-row>
    </My-tabs>

    <My-dialog title="新增预警" :className="'publicNDialog'" ref="addWarnDia" :width="'40%'">
      <Add-Warn @warnDataReset="warnDataInit" :rows="rows" />
    </My-dialog>

    <My-dialog title="修改预警" :className="'publicNDialog'" ref="editWarnDia" :width="'40%'">
      <Edit-Warn @warnDataReset="warnDataInit" :rows="rows" />
    </My-dialog>
  </div>
</template>

<script>
import AddWarn from './components/AddWarn'
import EditWarn from './components/EditWarn'
import { getWarnData, warnReset } from '@/api/user'
import { tableMix, selectMix } from '@/mixins'
export default {
  name: 'Warn',
  components: {
    AddWarn,
    EditWarn
  },
  mixins: [tableMix, selectMix],
  data() {
    return {
      filterForm: {
        createdByUserName: '',
        platform: '',
        type: '',
        urgent: '',
        startTime: '',
        endTime: '',
        dateRange: '',
        status: '',
        page: 1,
        size: 10,
        pagTotal: 0
      },
      statusList: [
        {
          id: '1',
          name: '是'
        },
        {
          id: '0',
          name: '否'
        }
      ],
      rows: {}
    }
  },
  watch: {
    'filterForm.dateRange'(value) {
      if (value) {
        this.filterForm.startTime = value[0]
        this.filterForm.endTime = value[1]
      } else {
        this.filterForm.startTime = ''
        this.filterForm.endTime = ''
      }
    }
  },
  mounted() {
    this.warnDataInit()
  },
  methods: {
    // 修改
    editWarn() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      if (this.selectedRows.length > 1) return this.$message.warning('只能勾选一条数据')
      this.$refs.editWarnDia.dialogVisible = true
      this.rows = Object.assign({}, this.selectedRows[0])
    },

    // 获取预警数据
    async warnDataInit(c, v, p, n) {
      if (c === 'query') {
        this.filterForm.page = 1
      }

      if (v) {
        this.$refs[n].dialogVisible = false
      }

      if (p) return

      const res = await getWarnData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.ticketWarnList
        this.filterForm.pagTotal = res.data.obj.totle
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 表格排序
    tableSortChange(par) {
      this.sortChange(par, this.warnDataInit)
    },

    // 分页改变
    currentChange(currentPage) {
      this.filterForm.page = currentPage
      this.warnDataInit()
    },

    // switch发生改变时候的回调
    async stateChange(id, status) {
      const res = await warnReset({
        id,
        status
      })
      if (res.data.status !== 200) {
        this.$message.error(res.data.msg)
      }
    },

    // 表格数据格式化
    tableFormatter(row, column, cellValue, index) {
      let value = ''
      this[`${column.property}List`].forEach(item => {
        if (Number(cellValue) === Number(item.id)) {
          value = item.name
        }
      })
      return value
    }
  }
}
</script>

<style scoped lang="less"></style>
