<template>
  <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
    <el-form-item label="问题平台" prop="platform">
      <el-select v-model="filterForm.platform" placeholder="请选择" clearable>
        <el-option
          v-for="item in newPlatformList"
          :key="item.id"
          :label="item.name"
          :value="item.id"
        >
        </el-option>
      </el-select>
    </el-form-item>

    <el-form-item label="问题类型" prop="type">
      <el-select v-model="filterForm.type" placeholder="请选择" clearable>
        <el-option v-for="item in newTypeList" :key="item.id" :label="item.name" :value="item.id">
        </el-option>
      </el-select>
    </el-form-item>

    <el-form-item label="紧急程度" prop="urgent">
      <el-select v-model="filterForm.urgent" placeholder="请选择" clearable>
        <el-option v-for="item in newUrgentList" :key="item.id" :label="item.name" :value="item.id">
        </el-option>
      </el-select>
    </el-form-item>

    <el-form-item label="处理时长（小时）" prop="threshold">
      <el-input placeholder="请输入内容" v-model="filterForm.threshold" clearable> </el-input>
    </el-form-item>

    <el-row class="formBtn">
      <el-button @click="$emit('warnDataReset', false, true, true, 'editWarnDia')" round
        >取 消</el-button
      >
      <el-button type="primary" @click="confirmWarnData" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { editWarnData } from '@/api/user'
import { selectMix } from '@/mixins'
export default {
  name: 'EditWarn',
  props: {
    rows: {
      type: Object,
      default: () => {}
    }
  },
  mixins: [selectMix],
  data() {
    return {
      filterForm: {
        platform: '',
        type: '',
        urgent: '',
        threshold: ''
      },
      rulesForm: {
        platform: [{ required: true, message: '问题平台不能为空', trigger: 'change' }],
        type: [{ required: true, message: '问题类型不能为空', trigger: 'change' }],
        urgent: [{ required: true, message: '紧急程度不能为空', trigger: 'change' }],
        threshold: [{ required: true, message: '处理时长不能为空', trigger: 'change' }]
      }
    }
  },
  mounted() {
    this.filterForm = Object.assign({}, this.rows)
  },
  methods: {
    // 确认按钮
    confirmWarnData() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return

        const res = await editWarnData(this.filterForm)
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('warnDataReset', false, true, false, 'editWarnDia')
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
