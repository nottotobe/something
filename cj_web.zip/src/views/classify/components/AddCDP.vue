<template>
  <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
    <el-form-item :label="publicLabel" prop="name">
      <el-input placeholder="请输入内容" v-model="filterForm.name" clearable> </el-input>
    </el-form-item>

    <el-row class="formBtn">
      <el-button @click="$emit('classifyDataReset', true, true)" round>取 消</el-button>
      <el-button type="primary" @click="confirmClassifyData" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { addClassifyData, editClassifyData } from '@/api/user'
export default {
  name: 'AddCDP',
  props: {
    publicLabel: {
      type: String,
      default: '弹出框'
    },
    keyword: {
      type: String,
      required: true
    },
    flag: {
      type: String,
      default: 'add'
    },
    rows: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      filterForm: {
        name: ''
      },
      rulesForm: {
        name: [{ required: true, message: this.publicLabel + '不能为空', trigger: 'change' }]
      }
    }
  },
  mounted() {
    if (this.flag === 'edit') {
      this.filterForm.name = this.rows.name
      this.filterForm.id = this.rows.id
    }
  },
  methods: {
    // 确认
    confirmClassifyData() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        let res
        if (this.flag === 'add') {
          res = await addClassifyData({
            item: this.keyword,
            name: this.filterForm.name
          })
        } else {
          res = await editClassifyData(this.filterForm)
        }
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('classifyDataReset', true)
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
