<template>
  <div style="height:100%">
    <el-row :gutter="24" class="dashboard_box" v-if="workAdmin">
      <el-col :span="18" v-if="workDeal">
        <el-card>
          <div slot="header">
            <span>工单管理</span>
          </div>
          <div class="work_box">
            <Board
              :boardUrl="imgList.doingUrl"
              :boardFlag="true"
              :quantity="quantityList.doingQuantity"
              :describe="describeList.doingDescribe"
              @toDistance="goDispose('execStatus', '0')"
            />
            <Board
              :boardUrl="imgList.overtimeUrl"
              :boardFlag="true"
              :quantity="quantityList.overtimeQuantity"
              :describe="describeList.overtimeDescribe"
              @toDistance="goDispose('isOverTime', '1')"
            />
            <Board
              :boardUrl="imgList.finishUrl"
              :boardFlag="true"
              :quantity="quantityList.finishQuantity"
              :describe="describeList.finishDescribe"
              @toDistance="goDispose('execStatus', '1')"
            />
            <Board
              :boardUrl="imgList.workUrl"
              :boardFlag="false"
              :describe="describeList.workDescribe"
              @toDistance="goQuery"
            />
          </div>
        </el-card>
      </el-col>
      <el-col :span="6" v-if="messageFlag">
        <el-card>
          <div slot="header">
            <span>推送消息</span>
          </div>
          <div class="message_box">
            <Board
              :boardUrl="imgList.messageUrl"
              :boardFlag="false"
              :widthFlag="true"
              :describe="describeList.messageDescribe"
              @toDistance="$router.push('/message')"
            />
          </div>
        </el-card>
      </el-col>
      <el-col :span="workUser ? 18 : 24" v-if="workDeal">
        <el-card class="overtime_st">
          <div slot="header">
            <span>工单列表</span>
          </div>
          <div>
            <TBoard :isAdmin="workAdmin" />
          </div>
        </el-card>
      </el-col>
      <el-col :span="6" v-if="workUser">
        <el-card>
          <div slot="header">
            <span>用户管理</span>
          </div>
          <div class="user_box">
            <Board
              :boardUrl="imgList.approvalUrl"
              :boardFlag="false"
              :widthFlag="true"
              :describe="describeList.approvalDescribe"
              @toDistance="goUser('examStatus')"
            />
            <Board
              :boardUrl="imgList.importUrl"
              :boardFlag="false"
              :widthFlag="true"
              :describe="describeList.importDescribe"
              @toDistance="goUser('batchImport')"
            />
            <Board
              :boardUrl="imgList.createUrl"
              :boardFlag="false"
              :widthFlag="true"
              :describe="describeList.createDescribe"
              @toDistance="goUser('addUser')"
            />
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { setSession, getLocal } from '@/utils/storage'
import { mapMutations } from 'vuex'
import { getWorkData } from '@/api/user'
import Board from './components/Board'
import TBoard from './components/TBoard'
import EventBus from '@/utils/eventBus'
export default {
  name: 'Dashboard',
  components: {
    Board,
    TBoard
  },
  data() {
    return {
      imgList: {
        doingUrl: require('@/assets/images/dashboard/workpage_icon_list2_default.png'),
        overtimeUrl: require('@/assets/images/dashboard/workpage_icon_list3_default.png'),
        finishUrl: require('@/assets/images/dashboard/workpage_icon_list4_default.png'),
        messageUrl: require('@/assets/images/dashboard/workpage_icon_news_default.png'),
        approvalUrl: require('@/assets/images/dashboard/workpage_icon_check_default.png'),
        importUrl: require('@/assets/images/dashboard/workpage_icon_download_default.png'),
        createUrl: require('@/assets/images/dashboard/workpage_icon_add_default.png'),
        workUrl: require('@/assets/images/dashboard/workpage_icon_addlist_default.png')
      },
      quantityList: {
        doingQuantity: '',
        overtimeQuantity: '',
        finishQuantity: ''
      },
      describeList: {
        doingDescribe: '处理中',
        overtimeDescribe: '超时',
        finishDescribe: '已处理',
        messageDescribe: '新建消息',
        approvalDescribe: '待审批中',
        importDescribe: '导入用户',
        createDescribe: '创建用户',
        workDescribe: '新建工单'
      },
      messageFlag: false,
      menuList: []
    }
  },
  mounted() {
    this.loading()
    setTimeout(() => {
      this.menuList = getLocal('menuList')
      if (!this.workAdmin) {
        this.$router.push('/ticketDataAdd')
        this.saveNavState('/ticketDataAdd')
        return
      }
      this.messageFlag = true
      this.totalQuery()
    }, 500)
  },
  computed: {
    workDeal() {
      return this.menuList.some(item => {
        return item.name === '工单处理'
      })
    },
    workUser() {
      return this.menuList.some(item => {
        return item.name === '用户管理'
      })
    },
    workAdmin() {
      const workFlag = this.menuList.some(item => {
        return item.name === '工作台'
      })
      if (workFlag) {
        return this.menuList[0].children[0].explain
      } else {
        return false
      }
    }
  },
  methods: {
    ...mapMutations(['saveNavState']),
    ...mapMutations('CWork', ['createWorkTab']),
    // 去工单查询页面新建工单
    goQuery() {
      let par
      this.menuList.forEach(item => {
        if (item.name === '工单查询') {
          par = item.children[0].explain
        }
      })
      this.$router.push({
        path: '/ticketDataQuery',
        query: par ? { isAdmin: par } : {}
      })
      this.saveNavState('/ticketDataQuery')
      setSession('subMenuIndex', 1)
      this.createWorkTab()
    },

    // 去工单处理页面
    goDispose(v, n) {
      let par
      this.menuList.forEach(item => {
        if (item.name === '工单处理') {
          par = item.children[0].explain
        }
      })
      this.$router.push({
        path: '/ticketDataExcute',
        query: par ? { isAdmin: par } : {}
      })
      this.saveNavState('/ticketDataExcute')
      setSession('subMenuIndex', 3)
      setTimeout(() => {
        EventBus.$emit('dashboardEnter', v, n)
      }, 800)
    },

    // 去用户管理页面
    goUser(v) {
      this.$router.push('/userData')
      this.saveNavState('/userData')
      setSession('subMenuIndex', 8)
      setTimeout(() => {
        EventBus.$emit('userEnter', v)
      }, 800)
    },

    // 条数渲染
    async totalQuery() {
      let updatedBy = ''
      if (this.workAdmin !== 'admin') {
        updatedBy = getLocal('isUser').userId
      }
      let overtime = 0
      let finish = 0
      let doing = 0

      const res = await getWorkData({ updatedBy: updatedBy })
      const workData = res.data.obj.ticketList
      workData.forEach(item => {
        if (item.overTime && item.execStatus === '0') {
          overtime += 1
        }
        if (item.execStatus === '1') {
          finish += 1
        }
        if (item.execStatus === '0') {
          doing += 1
        }
      })
      this.quantityList.overtimeQuantity = overtime
      this.quantityList.finishQuantity = finish
      this.quantityList.doingQuantity = doing
    },

    // 关闭dialog (根据情况选择是否重新查询表格数据)
    closeDialog(dia, close) {
      this.$refs[dia].dialogVisible = false
    },

    loading() {
      const loading = this.$loading({
        target: '.el-main',
        background: '#fff',
        text: '加载中'
      })
      setTimeout(() => {
        loading.close()
      }, 800)
    }
  }
}
</script>

<style scoped lang="less">
.dashboard_box {
  .el-col {
    margin-bottom: 20px;
  }
  .el-card__header {
    span {
      font-weight: 900;
    }
  }
  .work_box {
    display: flex;
    justify-content: space-around;
  }
  .message_box {
    display: flex;
    justify-content: center;
  }
  .user_box {
    display: flex;
    flex-direction: column;
    align-items: center;
    .board_box {
      margin-bottom: 20px;
    }
    .board_box:last-child {
      margin-bottom: 0;
    }
  }
}
</style>
