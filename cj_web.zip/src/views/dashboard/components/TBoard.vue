<template>
  <div>
    <el-table
      ref="tableRef"
      :data="tableData"
      stripe
      style="width:100%"
      class="publicTable"
      @row-dblclick="rowDblclick"
    >
      <el-table-column label="问题ID" show-overflow-tooltip prop="ticketId"> </el-table-column>
      <el-table-column
        label="问题标题"
        prop="title"
        show-overflow-tooltip
        width="300"
      ></el-table-column>
      <el-table-column label="问题平台" prop="platformName" show-overflow-tooltip></el-table-column>
      <el-table-column label="问题类型" prop="typeName" show-overflow-tooltip></el-table-column>
      <el-table-column label="紧急程度" prop="urgentName" show-overflow-tooltip></el-table-column>
      <el-table-column
        label="提交机构"
        prop="createdByDptName"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column
        label="提交人"
        prop="createdByUserName"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column
        label="提交时间"
        prop="createdTime"
        show-overflow-tooltip
        width="200"
      ></el-table-column>
      <el-table-column label="处理时长" prop="threshold" show-overflow-tooltip></el-table-column>
      <el-table-column label="超时预紧" prop="overTime" show-overflow-tooltip>
        <template slot-scope="scope">
          <span v-if="scope.row.overTime" style="color: #f56c6c">{{ '超时' }}</span>
          <span v-else>{{ '-' }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="经办人"
        prop="updatedByUserName"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column
        label="进度"
        prop="execStatus"
        show-overflow-tooltip
        :formatter="tableFormatter"
      ></el-table-column>
    </el-table>

    <My-dialog :title="'工单详情'" :className="'publicFDialog'" ref="workDetailsDia">
      <Work-details @closeDialog="$refs.workDetailsDia.dialogVisible = false" :rows="rows" />
    </My-dialog>
  </div>
</template>

<script>
import WorkDetails from '../../workPublic/WorkDetails.vue'
import { getWorkData } from '@/api/user'
import { getLocal } from '@/utils/storage'
export default {
  name: 'TBoard',
  components: {
    WorkDetails
  },
  props: {
    isAdmin: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      tableData: [],

      // 下拉框数据
      execStatusList: [
        {
          id: '1',
          name: '已处理'
        },
        {
          id: '0',
          name: '未处理'
        }
      ],

      rows: ''
    }
  },
  mounted() {
    this.getData()
  },
  methods: {
    // 获取数据
    async getData() {
      let updatedBy = ''
      if (this.isAdmin !== 'admin') {
        updatedBy = getLocal('isUser').userId
      }
      const overtime = await getWorkData({
        updatedBy: updatedBy,
        page: 1,
        size: 10
      })
      this.tableData = overtime.data.obj.ticketList
    },

    // 表格数据格式化
    tableFormatter(row, column, cellValue, index) {
      let value = ''
      this[`${column.property}List`].forEach(item => {
        if (Number(cellValue) === Number(item.id)) {
          value = item.name
        }
      })
      return value
    },

    // 双击查看详情
    rowDblclick(row, column, event) {
      this.$refs.workDetailsDia.dialogVisible = true
      this.rows = row
    }
  }
}
</script>

<style scoped lang="less"></style>
