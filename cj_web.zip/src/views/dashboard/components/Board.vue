<template>
  <div>
    <div :class="'board_box ' + boardWidth" @click="$emit('toDistance')">
      <el-image :src="boardUrl"></el-image>
      <div class="board_cont" v-if="boardFlag">
        <span class="quantity" :title="quantity">{{ quantity }}</span>
        <span class="describe">{{ describe }}</span>
      </div>
      <div v-else :class="'describeElse ' + workDescribe">{{ describe }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Board',
  props: {
    boardFlag: {
      type: Boolean,
      required: true
    },
    boardUrl: {
      type: String,
      required: true
    },
    quantity: {
      type: [Number, String],
      default: 100
    },
    describe: {
      type: String,
      default: '文字描述'
    },
    widthFlag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      boardWidth: '',
      workDescribe: ''
    }
  },
  mounted() {
    if (this.widthFlag) {
      this.boardWidth = 'board_width'
    }
    if (this.describe === '新建工单') {
      this.workDescribe = 'work_describe'
    }
  },
  methods: {}
}
</script>

<style scoped lang="less">
.board_box {
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 0 20px;
  box-sizing: border-box;
  width: 260px;
  height: 150px;
  background-color: #f9f9f9;
  border-radius: 15px;
  cursor: pointer;
  .el-image {
    width: 120px;
    height: 120px;
  }
  .board_cont {
    display: flex;
    flex-direction: column;
    text-align: center;
    .quantity {
      font-weight: 900;
      font-size: 25px;
      max-width: 80px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .describe {
      font-size: 20px;
    }
  }
  .describeElse {
    font-weight: 900;
    font-size: 30px;
  }
}

.board_width {
  width: 330px;
}

.work_describe {
  width: 60px;
}
</style>
