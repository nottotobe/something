<template>
  <el-menu
    unique-opened
    router
    active-text-color="#fff"
    :default-active="activePath"
    ref="menuRef"
    @open="handleOpen"
  >
    <el-submenu v-for="item in validMenuList" :key="item.id" :index="item.id + ''">
      <template slot="title">
        <span>{{ item.name }}</span>
      </template>
      <el-menu-item
        v-for="value in item.children"
        :index="value.path"
        :key="value.id"
        :route="{ path: value.path, query: value.explain ? { isAdmin: value.explain } : {} }"
        @click="saveNavState(value.path)"
      >
        <template slot="title">
          <span>{{ value.name }}</span>
        </template>
      </el-menu-item>
    </el-submenu>
  </el-menu>
</template>

<script>
import { setSession, getSession, removeSession } from '@/utils/storage'
import { mapState, mapMutations } from 'vuex'
export default {
  name: 'Aside',
  props: {
    menuList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {}
  },
  mounted() {
    if (getSession('activePath')) {
      this.saveNavState(getSession('activePath'))
    }
  },
  methods: {
    // 保存activePath   删除activePath
    ...mapMutations(['saveNavState', 'deleteNavState']),

    // 展示工作台时关闭侧边栏
    closeMenu() {
      const subMenuIndex = String(getSession('subMenuIndex'))
      this.$refs.menuRef.close(subMenuIndex)
      removeSession('subMenuIndex')
      this.deleteNavState()
    },

    // 保存展开的sub-menu的index
    handleOpen(index, indexPath) {
      setSession('subMenuIndex', index)
    }
  },
  computed: {
    ...mapState(['activePath']),
    validMenuList() {
      return this.menuList.filter(item => {
        return item.type === 'menu'
      })
    }
  }
}
</script>

<style scoped lang="less">
.el-menu {
  border-right: none;
  background-color: unset;
  /deep/ .el-submenu__title:hover {
    background-color: unset;
  }
}
</style>
