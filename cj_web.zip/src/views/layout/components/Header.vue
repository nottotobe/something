<template>
  <el-row class="header_container">
    <el-col :span="6" class="header_logo"></el-col>
    <el-col :span="18" class="header_other">
      <el-carousel direction="vertical" indicator-position="none">
        <el-carousel-item v-for="item in carouselList" :key="item.messageId" :title="item.content">
          {{ item.content }}
        </el-carousel-item>
      </el-carousel>
      <span class="header_time">{{ testTime }}</span>
      <span class="header_welcome">欢迎你，{{ username }}</span>
      <div class="iconGroup ignore">
        <i
          class="iconfont icon-top-table"
          title="工作台"
          v-show="tableFlag"
          @click="goDashboard"
        ></i>
        <i
          class="iconfont icon-top-user"
          title="个人中心"
          v-show="userFlag"
          @click="goMycenter"
        ></i>
        <i
          class="iconfont icon-top-kefu"
          title="在线客服"
          v-show="kefuFlag"
          @click="goCustomer"
        ></i>
        <el-dropdown @command="handleCommand">
          <i class="iconfont icon-top-skin"></i>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="white">远山白</el-dropdown-item>
            <el-dropdown-item command="black">星空黑</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <i class="iconfont icon-top-exit" title="退出" @click="logout"></i>
      </div>
    </el-col>
  </el-row>
</template>

<script>
import { setSession, setLocal, getLocal, removeLocal } from '@/utils/storage'
import { mapState, mapMutations, mapActions } from 'vuex'
import { logout, getCustomer } from '@/api/user'
export default {
  name: 'Header',
  props: {
    menuList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      testTime: '',
      username: ''
    }
  },
  computed: {
    ...mapState(['carouselList']),
    kefuFlag() {
      return this.menuList.some(item => {
        return item.name === '客服管理'
      })
    },
    userFlag() {
      return this.menuList.some(item => {
        return item.name === '个人中心'
      })
    },
    tableFlag() {
      return this.menuList.some(item => {
        return item.name === '工作台'
      })
    }
  },
  mounted() {
    this.testTime = new Date().toLocaleDateString()
    this.getCarouselData()
    this.username = getLocal('isUser').username
  },
  methods: {
    // 删除activePath
    ...mapMutations(['deleteNavState', 'saveNavState']),
    // 轮播图数据
    ...mapActions(['getCarouselData']),

    // 前往工作台
    goDashboard() {
      if (window.location.href.indexOf('dashboard') !== -1) return
      this.$router.push('/dashboard')
      this.$emit('closeMenu')
    },

    // 前往个人中心
    goMycenter() {
      if (window.location.href.indexOf('personManager') !== -1) return
      this.$router.push('/personManager')
      this.saveNavState('/personManager')
      setSession('subMenuIndex', 10)
    },

    // 退出
    logout() {
      this.$confirm('确定要退出吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'info',
        closeOnClickModal: false
      })
        .then(async () => {
          const res = await logout()
          if (res.data.status === 200) {
            this.$router.push('/login')
            this.deleteNavState()
            removeLocal('isUser')
            removeLocal('menuList')
            this.$message.success(res.data.msg)
            window.location.reload()
          } else {
            this.$message.error(res.data.msg)
          }
        })
        .catch(() => {})
    },

    // 点击下拉菜单项触发的事件回调
    handleCommand(command) {
      document.getElementById('app').className = 'theme_' + command
      setLocal('theme', 'theme_' + command)
    },

    // 客服中心
    async goCustomer() {
      const res = await getCustomer()
      const par = res.data.obj
      const customerSrc =
        par.url +
        '?pId=' +
        par.pId +
        '&nonce=' +
        par.nonce +
        '&timestamp=' +
        par.timestamp +
        '&sign=' +
        par.sign
      window.open(customerSrc)
    }
  }
}
</script>

<style scoped lang="less">
.header_container {
  display: flex;
  align-items: center;
  height: 100%;
  .header_logo {
    height: 100%;
    background-size: 300px auto;
    background-position: center left;
  }
  .header_other {
    display: flex;
    justify-content: flex-end;
    height: 35px;
    line-height: 35px;
    .el-carousel {
      width: 400px;
      border-radius: 20px;
      padding: 0 20px;
      color: #5980ff;
      cursor: pointer;
      .el-carousel__item {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }
    .header_welcome,
    .header_time {
      margin-left: 40px;
    }
    .iconGroup.ignore {
      margin-left: 20px;
      i {
        font-size: 25px;
        color: #bcc0cf;
        cursor: pointer;
        margin-left: 20px;
      }
      .icon-top-user,
      .icon-top-kefu {
        font-size: 27px;
      }
      i:hover {
        color: #5980ff;
      }
    }
  }
}
</style>
