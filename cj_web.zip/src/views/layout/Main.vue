<template>
  <el-container>
    <el-header>
      <Header @closeMenu="closeMenu" :menuList="menuList" />
    </el-header>
    <el-container>
      <el-aside width="200px">
        <My-scroll>
          <Aside ref="asideRef" :menuList="menuList" />
        </My-scroll>
      </el-aside>
      <el-main>
        <My-scroll>
          <div style="margin-right:20px">
            <keep-alive>
              <router-view v-if="$route.meta.keepAlive" />
            </keep-alive>
            <router-view v-if="!$route.meta.keepAlive" />
          </div>
        </My-scroll>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import { getLocal, setLocal } from '@/utils/storage'
import Header from './components/Header.vue'
import Aside from './components/Aside.vue'
import MyScroll from '@/components/MyScroll'
import { getMenuList } from '@/api/user'
export default {
  name: 'Main',
  components: {
    Header, // 头部组件
    Aside, // 侧边栏组件
    MyScroll // 滚动条组件
  },
  data() {
    return {
      menuList: []
    }
  },
  mounted() {
    this.getMenuList()
    this.judgeSkin()
  },
  methods: {
    // 从Header中关闭Aside中展开的sub-menu
    closeMenu() {
      this.$refs.asideRef.closeMenu()
    },

    // 初始化时判断皮肤
    judgeSkin() {
      let skin = 'theme_white'
      if (getLocal('theme')) {
        skin = getLocal('theme')
      }
      document.getElementById('app').className = skin
    },

    // 获取侧边栏数据
    async getMenuList() {
      const res = await getMenuList()
      this.menuList = res.data
      setLocal('menuList', this.menuList)
    }
  }
}
</script>

<style scoped lang="less">
.el-container {
  height: 100%;
  overflow: hidden;
  background-color: #f5f5f5;
}

.el-main {
  margin: 20px;
  border-radius: 20px;
  padding-right: 0;
  background-color: #fff;
}
</style>
