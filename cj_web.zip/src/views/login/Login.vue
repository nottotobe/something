<template>
  <div class="login_container">
    <div class="login_bg">
      <div class="login_box">
        <div class="login_em"></div>
        <div class="login_title">工单管理系统</div>
        <User-login v-if="loginFlag" @changeFlag="changeFlag" />
        <Code-login v-else @changeFlag="changeFlag" />
      </div>
    </div>
  </div>
</template>

<script>
import UserLogin from './components/UserLogin.vue'
import CodeLogin from './components/CodeLogin.vue'
export default {
  name: 'Login',
  components: {
    UserLogin, // 用户名登陆组件
    CodeLogin // 验证码登陆组件
  },
  data() {
    return {
      loginFlag: true
    }
  },
  mounted() {},
  methods: {
    // 接受子组件数据切换登录方式
    changeFlag(val) {
      this.loginFlag = val
    }
  }
}
</script>

<style scoped lang="less">
.login_box {
  height: 550px;
}
</style>
