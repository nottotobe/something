<template>
  <el-form ref="loginForm" :model="filterForm" class="login_form" :rules="rulesForm">
    <el-form-item prop="mobile">
      <el-input
        v-model="filterForm.mobile"
        placeholder="手机号"
        clearable
        prefix-icon="iconfont icon-phone"
      >
      </el-input>
    </el-form-item>
    <el-form-item prop="verifyCode">
      <el-input
        v-model="filterForm.verifyCode"
        placeholder="短信验证码"
        clearable
        prefix-icon="iconfont icon-text"
      >
        <el-button slot="append" @click="sendCode" class="send_btn">{{ sendValue }}</el-button>
      </el-input>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="onLogin" :loading="loginLoading">登陆</el-button>
    </el-form-item>
    <div class="login_other">
      <span @click="changeFlag">密码登录</span>
      <span> | </span>
      <span @click="$router.push('/register')">注册账号</span>
    </div>
  </el-form>
</template>

<script>
import { login, getPhoneCode } from '@/api/user'
import { setLocal } from '@/utils/storage'
import { validMobile } from '@/utils/validate'
export default {
  name: 'CodeLogin',
  data() {
    return {
      filterForm: {
        mobile: '',
        verifyCode: ''
      },
      rulesForm: {
        mobile: [
          { required: true, message: '手机号不能为空', trigger: 'change' },
          { validator: validMobile, trigger: 'blur' }
        ],
        verifyCode: [{ required: true, message: '验证码不能为空', trigger: 'change' }]
      },
      sendValue: '发送验证码',
      sendTimer: null,
      sendCount: 60,
      loginLoading: false
    }
  },
  mounted() {},
  methods: {
    // 点击登录按钮
    onLogin() {
      this.$refs.loginForm.validate(async valid => {
        if (!valid) return
        this.loginLoading = true
        try {
          const res = await login(this.filterForm)
          if (res.data.status === 200) {
            setLocal('isUser', {
              username: res.data.obj.username,
              userId: res.data.obj.userId
            })
            this.$router.push('/main')
            this.$message.success(res.data.msg)
          } else {
            this.$message.error(res.data.msg)
          }
          this.loginLoading = false
        } catch (err) {
          this.loginLoading = false
        }
      })
    },
    // 切换登录方式
    changeFlag() {
      this.$emit('changeFlag', true)
    },
    // 发送验证码
    sendCode() {
      this.$refs.loginForm.validateField('mobile', async valid => {
        if (valid) return
        if (!this.sendTimer) {
          const res = await getPhoneCode({
            type: 'login',
            mobile: this.filterForm.mobile
          })
          this.$message.success(res.data.obj)
          const that = this
          const fun = function() {
            that.sendValue = that.sendCount + '秒后重新发送'
            that.sendCount--
            if (that.sendCount < 0) {
              that.sendValue = '发送验证码'
              that.sendCount = 60
              window.clearInterval(that.sendTimer)
              that.sendTimer = null
            }
          }
          fun()
          this.sendTimer = window.setInterval(fun, 1000)
        }
      })
    }
  }
}
</script>
