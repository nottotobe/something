<template>
  <el-form ref="loginForm" :model="filterForm" class="login_form" :rules="rulesForm">
    <el-form-item prop="username">
      <el-input
        v-model="filterForm.username"
        placeholder="用户ID"
        clearable
        prefix-icon="iconfont icon-user"
      >
      </el-input>
    </el-form-item>
    <el-form-item prop="password">
      <el-input
        v-model="filterForm.password"
        type="password"
        placeholder="密码"
        clearable
        prefix-icon="iconfont icon-password"
      >
      </el-input>
    </el-form-item>
    <div class="login_userChange">
      <el-checkbox v-model="rememberPWD" @change="rememberChange">记住密码</el-checkbox>
      <span class="login_change" @click="changeFlag">手机号码登陆</span>
    </div>
    <el-form-item>
      <el-button type="primary" @click="onLogin" :loading="loginLoading">登陆</el-button>
    </el-form-item>
    <div class="login_other">
      <span @click="$router.push('/password')">忘记密码</span>
      <span> | </span>
      <span @click="$router.push('/register')">注册账号</span>
    </div>
  </el-form>
</template>

<script>
import { login } from '@/api/user'
import { setLocal } from '@/utils/storage'
import secret from '@/utils/secret'
export default {
  name: 'UserLogin',
  data() {
    return {
      filterForm: {
        username: '',
        password: ''
      },
      rulesForm: {
        username: [{ required: true, message: '用户ID不能为空', trigger: 'change' }],
        password: [{ required: true, message: '密码不能为空', trigger: 'change' }]
      },
      rememberPWD: false,
      loginLoading: false
    }
  },
  mounted() {
    this.exgetCookie()
  },
  methods: {
    // 点击登录按钮
    onLogin() {
      this.$refs.loginForm.validate(async valid => {
        if (!valid) return
        this.loginLoading = true
        try {
          const res = await login(this.filterForm)
          if (res.data.status === 200) {
            setLocal('isUser', {
              username: res.data.obj.username,
              userId: res.data.obj.userId
            })
            this.$router.push('/main')
            this.$message.success(res.data.msg)
            if (this.rememberPWD) {
              this.setCookie(this.filterForm.username, this.filterForm.password, 7)
            }
          } else {
            this.$message.error(res.data.msg)
          }
          this.loginLoading = false
        } catch (err) {
          this.loginLoading = false
        }
      })
    },

    // 切换登录方式
    changeFlag() {
      this.$emit('changeFlag', false)
    },

    // 记住密码
    rememberChange() {
      if (!this.rememberPWD) {
        this.clearCookie()
      }
    },

    // 设置cookie
    setCookie(username, password, exdays) {
      var exdate = new Date() // 获取时间
      exdate.setTime(exdate.getTime() + 24 * 60 * 60 * 1000 * exdays) // 保存的天数
      // 字符串拼接cookie
      window.document.cookie =
        'cname' + '=' + secret.Encrypt(username) + ';path=/;expires=' + exdate.toGMTString()
      // expires是设置cookie的过期时间，toGMTString是将日期转为GMT的字符串进行拼接
      window.document.cookie =
        'cword' + '=' + secret.Encrypt(password) + ';path=/;expires=' + exdate.toGMTString()
    },

    // 读取cookie
    exgetCookie() {
      if (document.cookie.length > 0) {
        if (document.cookie.indexOf('cname') !== -1) {
          this.rememberPWD = true
          var arr = document.cookie.split('; ')
          for (var i = 0; i < arr.length; i++) {
            var arr2 = arr[i].split('=')
            if (arr2[0] === 'cname') {
              this.filterForm.username = secret.Decrypt(arr2[1])
            } else if (arr2[0] === 'cword') {
              this.filterForm.password = secret.Decrypt(arr2[1])
            }
          }
        }
      }
    },

    // 清除cookie
    clearCookie() {
      this.setCookie('', '', -1) // 修改2值都为空，天数为负1天就好了
    }
  }
}
</script>
