<template>
  <div class="login_container">
    <div class="login_bg">
      <div class="login_box">
        <div class="login_em"></div>
        <div class="login_title">重置密码</div>
        <el-form ref="passwordForm" :model="filterForm" class="login_form" :rules="rulesForm">
          <el-form-item prop="userId">
            <el-input
              v-model="filterForm.userId"
              placeholder="用户ID"
              clearable
              prefix-icon="iconfont icon-user"
            >
            </el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input
              v-model="filterForm.password"
              type="password"
              placeholder="新密码"
              clearable
              prefix-icon="iconfont icon-password"
            >
            </el-input>
          </el-form-item>
          <el-form-item prop="confirmPWD">
            <el-input
              v-model="filterForm.confirmPWD"
              type="password"
              placeholder="确认新密码"
              clearable
              prefix-icon="iconfont icon-password"
            >
            </el-input>
          </el-form-item>
          <el-form-item prop="mobile">
            <el-input
              v-model="filterForm.mobile"
              placeholder="手机号"
              clearable
              prefix-icon="iconfont icon-phone"
            >
            </el-input>
          </el-form-item>
          <el-form-item prop="verifyCode">
            <el-input
              v-model="filterForm.verifyCode"
              placeholder="短信验证码"
              clearable
              prefix-icon="iconfont icon-text"
            >
              <el-button slot="append" @click="sendCode" class="send_btn">
                {{ sendValue }}
              </el-button>
            </el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="onPassword">确定</el-button>
          </el-form-item>
          <div class="login_other">
            <span @click="$router.push('/login')">登录</span>
            <span> | </span>
            <span @click="$router.push('/register')">注册账号</span>
          </div>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import { forgetPWD, getPhoneCode } from '@/api/user'
import { validMobile, validPassword, validChinese } from '@/utils/validate'
export default {
  name: 'Password',
  data() {
    return {
      filterForm: {
        userId: '',
        password: '',
        confirmPWD: '',
        mobile: '',
        verifyCode: ''
      },
      rulesForm: {
        userId: [
          { required: true, message: '用户ID不能为空', trigger: 'change' },
          { validator: validChinese, trigger: 'blur' }
        ],
        password: [
          { required: true, message: '新密码不能为空', trigger: 'change' },
          { validator: validPassword, trigger: 'blur' }
        ],
        confirmPWD: [
          { required: true, message: '确认的新密码不能为空', trigger: 'change' },
          { validator: validPassword, trigger: 'blur' }
        ],
        mobile: [
          { required: true, message: '手机号不能为空', trigger: 'change' },
          { validator: validMobile, trigger: 'blur' }
        ],
        verifyCode: [{ required: true, message: '验证码不能为空', trigger: 'change' }]
      },
      sendValue: '发送验证码',
      sendTimer: null,
      sendCount: 60
    }
  },
  mounted() {},
  methods: {
    // 点击确定按钮
    onPassword() {
      this.$refs.passwordForm.validate(async valid => {
        if (!valid) return
        if (this.filterForm.password !== this.filterForm.confirmPWD) {
          this.$message.warning('两次密码输入的不一致')
          return
        }
        const res = await forgetPWD(this.filterForm)
        if (res.data.status === 200) {
          this.$router.push('/login')
          this.$message.success('密码重置成功')
        } else {
          this.$message.error(res.data.msg)
        }
      })
    },
    // 发送验证码
    sendCode() {
      this.$refs.passwordForm.validateField('mobile', async valid => {
        if (valid) return
        if (!this.sendTimer) {
          const res = await getPhoneCode({
            type: 'editPass',
            mobile: this.filterForm.mobile
          })
          if (res.data.status === 200) {
            this.$message.success(res.data.msg)
          } else {
            this.$message.error(res.data.msg)
          }
          const that = this
          const fun = function() {
            that.sendValue = that.sendCount + '秒后重新发送'
            that.sendCount--
            if (that.sendCount < 0) {
              that.sendValue = '发送验证码'
              that.sendCount = 60
              window.clearInterval(that.sendTimer)
              that.sendTimer = null
            }
          }
          fun()
          this.sendTimer = window.setInterval(fun, 1000)
        }
      })
    }
  }
}
</script>

<style scoped lang="less">
.login_box {
  height: 750px;
}
</style>
