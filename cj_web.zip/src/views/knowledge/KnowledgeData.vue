<template>
  <div>
    <My-tabs
      ref="myTabs"
      :tabTitle="'知识数据'"
      :editableTabs="editableTabs"
      @filterEditableTabs="filterEditableTabs"
    >
      <template v-slot:collapseTab>
        <el-form :model="filterForm" ref="formRef">
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="一级分类" prop="firstType">
                <el-select
                  v-model="filterForm.firstType"
                  placeholder="请选择"
                  clearable
                  @change="firstTypeChange"
                >
                  <el-option
                    v-for="item in firstTypeList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="子类" prop="secondType">
                <el-select v-model="filterForm.secondType" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in secondTypeList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6" v-show="identity !== 'issue'">
              <el-form-item label="提交人" prop="createdByUserName">
                <el-input
                  v-model="filterForm.createdByUserName"
                  placeholder="请输入内容"
                  clearable
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="标签" prop="labelId">
                <el-select v-model="filterForm.labelId" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in labelIdList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="标题关键词" prop="title">
                <el-input v-model="filterForm.title" placeholder="请输入内容" clearable></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6" v-show="identity !== 'issue'">
              <el-form-item label="提交日期" prop="dateRange">
                <el-date-picker
                  v-model="filterForm.dateRange"
                  type="daterange"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  unlink-panels
                  value-format="yyyy-MM-dd HH:mm:ss"
                  :default-time="['00:00:00', '23:59:59']"
                >
                  >
                </el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="6" v-show="identity !== 'issue'">
              <el-form-item label="审核状态" prop="examStatus">
                <el-select v-model="filterForm.examStatus" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in examStatusList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col class="formBtn">
              <el-button type="primary" round @click="knowledgeDataInit(false, false, 'query')"
                >查询</el-button
              >
              <el-button round type="info" plain @click="resetForm('formRef')">重置</el-button>
            </el-col>
          </el-row>
        </el-form>
      </template>

      <el-table
        ref="tableRef"
        :data="tableData"
        stripe
        style="width:100%"
        class="publicTable"
        @row-click="(row, column, e) => rowClick(row, column, e, true)"
        @selection-change="selectionChange"
        @row-dblclick="rowDblclick"
        @sort-change="tableSortChange"
      >
        <el-table-column type="selection"> </el-table-column>
        <el-table-column
          label="知识ID"
          prop="id"
          show-overflow-tooltip
          sortable="custom"
          width="100"
        ></el-table-column>
        <el-table-column
          label="问题标题"
          prop="title"
          show-overflow-tooltip
          width="300"
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="一级分类"
          prop="firstTypeName"
          show-overflow-tooltip
          sortable="custom"
          width="150"
        ></el-table-column>
        <el-table-column
          label="子类"
          prop="secondTypeName"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column label="标签" prop="labelId">
          <template slot-scope="scope">
            <el-button @click.native.stop="viewTag(scope.row.labelList)" type="text">
              查看
            </el-button>
          </template>
        </el-table-column>
        <el-table-column
          label="提交机构"
          prop="createdDptName"
          show-overflow-tooltip
          sortable="custom"
          width="100"
        ></el-table-column>
        <el-table-column
          label="提交人"
          prop="createdByUserName"
          show-overflow-tooltip
          sortable="custom"
          width="100"
        ></el-table-column>
        <el-table-column
          label="提交时间"
          prop="createdTime"
          show-overflow-tooltip
          width="200"
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="审核"
          prop="examStatus"
          show-overflow-tooltip
          :formatter="tableFormatter"
          sortable="custom"
        ></el-table-column>
      </el-table>

      <el-pagination
        :total="filterForm.pagTotal"
        layout="total, prev, pager, next, jumper"
        background
        :current-page="filterForm.page"
        :page-size="filterForm.size"
        @current-change="currentChange"
      >
      </el-pagination>

      <el-row class="tableBtn">
        <el-button type="primary" round @click="addKnowledge" v-show="this.identity !== 'issue'"
          >新增</el-button
        >
        <el-button type="primary" round @click="editKnowledge" v-show="this.identity !== 'issue'"
          >修改</el-button
        >
        <el-button type="warning" round @click="reviewKnowledge" v-show="this.identity === 'admin'"
          >审核</el-button
        >
        <el-button
          round
          type="danger"
          plain
          @click="delKnowledge"
          v-show="this.identity !== 'issue'"
          >删除</el-button
        >
        <el-button type="primary" round @click="exportExcel">导出</el-button>
      </el-row>

      <template v-slot:customTab>
        <el-tab-pane
          v-for="item in editableTabs"
          :key="item.name"
          :label="item.title"
          :name="item.name"
          closable
        >
          <div>
            <component
              :is="item.type"
              :flag="item.flag ? item.flag : ''"
              :rows="item.rows ? item.rows : {}"
              @closeTab="closeTab"
            ></component>
          </div>
        </el-tab-pane>
      </template>
    </My-tabs>

    <My-dialog
      :title="'知识审核'"
      :className="'publicNDialog'"
      ref="auditKnowledgeDia"
      :width="'40%'"
    >
      <Audit-knowledge :auditId="auditId" @knowledgeReset="knowledgeDataInit" />
    </My-dialog>

    <My-dialog :title="'查看标签'" :className="'publicNDialog'" :width="'40%'" ref="viewDia">
      <My-view :viewList="viewList" @closeView="closeView" />
    </My-dialog>

    <My-dialog :title="'知识详情'" :className="'publicNDialog'" ref="loreDetailsDia" :width="'80%'">
      <Lore-details :loreDetailsRows="loreDetailsRows" @loreDetailsClose="knowledgeDataInit" />
    </My-dialog>
  </div>
</template>

<script>
import CKnowledge from '../workPublic/CKnowledge'
import AuditKnowledge from './components/AuditKnowledge'
import LoreDetails from '../dispose/components/LoreDetails'
import MyView from '@/components/MyView'
import { tableMix, viewMix } from '@/mixins'
import { getKnowledgeData, getTagData, getKnowledgeClass, delKnowledgeData } from '@/api/user'
export default {
  name: 'KnowledgeData',
  components: {
    AuditKnowledge,
    CKnowledge,
    LoreDetails,
    MyView
  },
  mixins: [tableMix, viewMix],
  watch: {
    'filterForm.dateRange'(value) {
      if (value) {
        this.filterForm.startTime = value[0]
        this.filterForm.endTime = value[1]
      } else {
        this.filterForm.startTime = ''
        this.filterForm.endTime = ''
      }
    }
  },
  data() {
    return {
      filterForm: {
        createdByUserName: '',
        firstType: '',
        secondType: '',
        labelId: '',
        startTime: '',
        endTime: '',
        dateRange: '',
        title: '',
        examStatus: '',
        page: 1,
        size: 10,
        pagTotal: 0
      },
      tableData: [],
      labelIdList: [],
      firstTypeList: [],
      secondTypeList: [],
      examStatusList: [
        {
          id: '0',
          name: '待审核'
        },
        {
          id: '1',
          name: '审核通过'
        },
        {
          id: '2',
          name: '审批退回'
        }
      ],

      auditId: [],
      editableTabs: [],
      loreDetailsRows: {},
      identity: ''
    }
  },
  mounted() {},
  activated() {
    this.identity = this.$route.query.isAdmin
    this.getClassLabel()
    this.knowledgeDataInit()
  },
  methods: {
    // 双击查看详情
    rowDblclick(row, column, event) {
      if (this.clickFlag) {
        // 取消上次延时未执行的方法
        this.clickFlag = clearTimeout(this.clickFlag)
      }
      this.$refs.loreDetailsDia.dialogVisible = true
      this.loreDetailsRows = Object.assign({}, row)
    },

    // 获取知识数据
    async knowledgeDataInit(v, p, n) {
      if (v) {
        this.$refs[n].dialogVisible = false
      }
      if (p) return

      if (n === 'query') {
        this.filterForm.page = 1
      }

      if (this.identity === 'issue') {
        this.filterForm.examStatus = '1'
      }
      const res = await getKnowledgeData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.knowledgeDetailList
        this.filterForm.pagTotal = res.data.obj.total
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 审核
    reviewKnowledge() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      this.$refs.auditKnowledgeDia.dialogVisible = true
      this.auditId = []
      this.selectedRows.forEach(item => {
        this.auditId.push(item.id)
      })
    },

    // 新增
    addKnowledge() {
      const workFlag = this.editableTabs.some(item => {
        return item.name === '2'
      })
      if (workFlag) return this.$message.warning('请先完成当前的新增知识标签')
      this.editableTabs.push({
        title: '新增知识数据',
        name: '2',
        type: 'CKnowledge',
        flag: 'add'
      })
      this.$refs.myTabs.editableTabsValue = '2'
    },

    // 修改
    editKnowledge() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      if (this.selectedRows.length > 1) return this.$message.warning('只能勾选一条数据')

      const workFlag = this.editableTabs.some(item => {
        return item.name === '3'
      })
      if (workFlag) return this.$message.warning('请先完成当前的修改知识标签')
      const rows = Object.assign({}, this.selectedRows[0])
      this.editableTabs.push({
        title: '修改知识数据',
        name: '3',
        type: 'CKnowledge',
        flag: 'edit',
        rows
      })
      this.$refs.myTabs.editableTabsValue = '3'
    },

    // 删除
    delKnowledge() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      const newArr = []
      this.selectedRows.forEach(item => {
        newArr.push({
          id: item.id
        })
      })
      this.$confirm('确定删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        closeOnClickModal: false
      })
        .then(async () => {
          const res = await delKnowledgeData(newArr)
          if (res.data.status === 200) {
            this.$message.success(res.data.msg)
            this.knowledgeDataInit()
          } else {
            this.$message.error(res.data.msg)
          }
        })
        .catch(() => {})
    },

    // 获取知识分类和标签
    async getClassLabel() {
      const tag = await getTagData()
      const knowledgeClass = await getKnowledgeClass()
      this.labelIdList = tag.data.obj.labelList.filter(item => {
        return item.examStatus === '1'
      })
      this.firstTypeList = knowledgeClass.data.obj.knowledgeMainList
      this.firstTypeChange()
    },

    // 一级分类发生变化
    firstTypeChange() {
      this.secondTypeList = []
      this.filterForm.secondType = ''
      this.firstTypeList.forEach(item => {
        if (item.id === this.filterForm.firstType) {
          this.secondTypeList = item.children
        }
      })
    },

    // 表格排序
    tableSortChange(par) {
      this.sortChange(par, this.knowledgeDataInit)
    },

    // 分页改变
    currentChange(currentPage) {
      this.filterForm.page = currentPage
      this.knowledgeDataInit()
    },

    // 表格数据格式化
    tableFormatter(row, column, cellValue, index) {
      let value = ''
      this[`${column.property}List`].forEach(item => {
        if (Number(cellValue) === Number(item.id)) {
          value = item.name
        }
      })
      return value
    },

    // 导出
    exportExcel() {
      const obj = this.filterForm
      let pars = ''
      for (var k in obj) {
        const par = k + '=' + obj[k] + '&'
        pars = pars + par
      }
      pars = pars.substring(0, pars.length - 1)
      window.open('/oam/knowledge/detail/export?' + pars, '_parent')
    },

    // 关闭标签
    closeTab(num, v) {
      this.$refs.myTabs.removeWorkTab(num)
      if (v) return
      this.knowledgeDataInit()
    },

    // 过滤关闭的tab
    filterEditableTabs(a, b) {
      this.editableTabs = a.filter(tab => tab.name !== b)
    }
  }
}
</script>

<style scoped lang="less"></style>
