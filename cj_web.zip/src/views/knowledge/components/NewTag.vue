<template>
  <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
    <el-form-item label="标签名称" prop="name">
      <el-input v-model="filterForm.name" placeholder="请输入内容" clearable></el-input>
    </el-form-item>

    <el-row class="formBtn">
      <el-button @click="$emit('tagDataReset', true, true, 'newTagDia')" round>取 消</el-button>
      <el-button type="primary" @click="confirmTagData" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { addTagData, editTagData } from '@/api/user'
export default {
  name: 'NewTag',
  props: {
    flag: {
      type: String,
      default: 'add'
    },
    identity: {
      type: String,
      default: ''
    },
    rows: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      filterForm: {
        name: ''
      },
      rulesForm: {
        name: [{ required: true, message: '标签不能为空', trigger: 'change' }]
      }
    }
  },
  mounted() {
    if (this.flag === 'edit') {
      this.filterForm = Object.assign({}, this.rows)
    }
  },
  methods: {
    // 确认按钮
    confirmTagData() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        if (this.identity === 'admin') {
          this.filterForm.examStatus = '1'
        } else {
          this.filterForm.examStatus = '0'
        }
        let res
        if (this.flag === 'add') {
          res = await addTagData(this.filterForm)
        } else {
          res = await editTagData(this.filterForm)
        }
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('tagDataReset', true, false, 'newTagDia')
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
