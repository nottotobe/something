<template>
  <div>
    <My-tabs :tabTitle="'子类'">
      <template v-slot:collapseTab>
        <el-table
          ref="tableRef"
          :data="tableData"
          stripe
          style="width:100%"
          class="publicTable"
          @row-click="rowClick"
          @selection-change="selectionChange"
        >
          <el-table-column type="selection"> </el-table-column>
          <el-table-column label="ID" prop="id" show-overflow-tooltip sortable></el-table-column>
          <el-table-column
            label="子类名称"
            prop="name"
            show-overflow-tooltip
            sortable
          ></el-table-column>
          <el-table-column
            label="描述"
            prop="explain"
            show-overflow-tooltip
            width="300"
            sortable
          ></el-table-column>
          <el-table-column
            label="提交机构"
            prop="createdDptName"
            show-overflow-tooltip
            sortable
          ></el-table-column>
          <el-table-column
            label="提交人"
            prop="createdDptName"
            show-overflow-tooltip
            sortable
          ></el-table-column>
          <el-table-column
            label="提交时间"
            prop="createdTime"
            show-overflow-tooltip
            sortable
          ></el-table-column>
        </el-table>

        <el-row class="tableBtn">
          <el-button type="primary" round @click="addSubClass">
            新增
          </el-button>
          <el-button type="primary" round @click="editSubClass">
            修改
          </el-button>
          <el-button round type="danger" plain @click="delSubClass">删除</el-button>
        </el-row>
      </template>
    </My-tabs>

    <My-dialog :title="titleDia" :className="'publicNDialog'" ref="addSubclassDia" :width="'40%'">
      <Add-Subclass
        :flag="flag"
        :rows="rows"
        :topName="topName"
        :topId="topId"
        @subClassReset="subClassReset"
      />
    </My-dialog>
  </div>
</template>

<script>
import AddSubclass from './AddSubclass.vue'
import { tableMix, addDiaMix } from '@/mixins'
import { delKnowledgeClass, getKnowledgeClass } from '@/api/user'
export default {
  name: 'Subclass',
  components: {
    AddSubclass
  },
  mixins: [tableMix, addDiaMix],
  props: {
    tableSub: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      topName: '',
      topId: ''
    }
  },
  mounted() {},
  watch: {
    tableSub() {
      this.tableData = this.tableSub.children
    }
  },
  methods: {
    // 新增
    addSubClass() {
      if (JSON.stringify(this.tableSub) === '{}') return this.$message.warning('请先选择一级分类')
      this.addPublic('addSubclassDia', '新增二级分类')
      this.topName = this.tableSub.name
      this.topId = this.tableSub.id
    },

    // 修改
    editSubClass() {
      this.editPublic('addSubclassDia', '修改二级分类')
      this.topName = this.tableSub.name
      this.topId = this.tableSub.id
    },

    // 删除
    delSubClass() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      const newArr = []
      this.selectedRows.forEach(item => {
        newArr.push({
          id: item.id
        })
      })
      this.$confirm('确定删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        closeOnClickModal: false
      })
        .then(async () => {
          const res = await delKnowledgeClass(newArr)
          if (res.data.status === 200) {
            this.$message.success(res.data.msg)
            this.subClassReset()
          } else {
            this.$message.error(res.data.msg)
          }
        })
        .catch(() => {})
    },

    // 重新获取二级表格数据
    async subClassReset(v, p) {
      if (!this.closePublic(v, p, 'addSubclassDia')) return
      const res = await getKnowledgeClass()
      if (res.data.status === 200) {
        const arr = res.data.obj.knowledgeMainList
        arr.forEach(item => {
          if (item.id === this.tableSub.id) {
            this.tableData = item.children
            this.$emit('topTableReset', item)
          }
        })
      } else {
        this.$message.error(res.data.msg)
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
