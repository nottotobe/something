<template>
  <el-form :model="filterForm" ref="formRef">
    <el-form-item label="审核" prop="examStatus">
      <el-select v-model="filterForm.examStatus" placeholder="请选择" clearable>
        <el-option
          v-for="item in examStatusList"
          :key="item.id"
          :label="item.name"
          :value="item.id"
        >
        </el-option>
      </el-select>
    </el-form-item>

    <el-row class="formBtn">
      <el-button @click="$emit('tagReset', true, true, 'auditTagDia')" round>
        取 消
      </el-button>
      <el-button type="primary" @click="confirmAuditTag" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { reviewTagData } from '@/api/user'

export default {
  name: 'AuditKnowledge',
  props: {
    auditId: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      filterForm: {
        examStatus: ''
      },
      examStatusList: [
        { id: '1', name: '审核通过' },
        { id: '2', name: '审核不通过' }
      ]
    }
  },
  mounted() {},
  methods: {
    async confirmAuditTag() {
      const newArr = []
      this.auditId.forEach(item => {
        newArr.push({
          id: item,
          examStatus: this.filterForm.examStatus
        })
      })
      const res = await reviewTagData(newArr)
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.$emit('tagReset', true, false, 'auditTagDia')
      } else {
        this.$message.error(res.data.msg)
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
