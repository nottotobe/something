<template>
  <el-form :model="filterForm" ref="formRef">
    <el-form-item label="审核" prop="examStatus">
      <el-select v-model="filterForm.examStatus" placeholder="请选择" clearable>
        <el-option
          v-for="item in examStatusList"
          :key="item.id"
          :label="item.name"
          :value="item.id"
        >
        </el-option>
      </el-select>
    </el-form-item>

    <el-form-item label="审核意见" prop="explain" v-if="filterForm.examStatus == '2'">
      <el-input
        type="textarea"
        placeholder="请输入内容"
        v-model="filterForm.explain"
        maxlength="20"
        show-word-limit
        :autosize="{ minRows: 2, maxRows: 2 }"
      >
      </el-input>
    </el-form-item>

    <el-row class="formBtn">
      <el-button @click="$emit('knowledgeReset', true, true, 'auditKnowledgeDia')" round>
        取 消
      </el-button>
      <el-button type="primary" @click="confirmAuditKnowledge" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { reviewKnowledgeData } from '@/api/user'

export default {
  name: 'AuditKnowledge',
  props: {
    auditId: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      filterForm: {
        examStatus: '',
        explain: ''
      },
      examStatusList: [
        { id: '1', name: '审核通过' },
        { id: '2', name: '审核不通过' }
      ]
    }
  },
  mounted() {},
  methods: {
    async confirmAuditKnowledge() {
      const newArr = []
      this.auditId.forEach(item => {
        newArr.push({
          id: item,
          examStatus: this.filterForm.examStatus,
          explain: this.filterForm.explain
        })
      })
      const res = await reviewKnowledgeData(newArr)
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.$emit('knowledgeReset', true, false, 'auditKnowledgeDia')
      } else {
        this.$message.error(res.data.msg)
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
