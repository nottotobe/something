<template>
  <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
    <el-form-item label="一级分类名称" prop="name">
      <el-input placeholder="请输入内容" v-model="filterForm.name"> </el-input>
    </el-form-item>

    <el-form-item label="描述" prop="explain">
      <el-input
        type="textarea"
        placeholder="请输入内容"
        v-model="filterForm.explain"
        maxlength="20"
        show-word-limit
        :autosize="{ minRows: 2, maxRows: 2 }"
      >
      </el-input>
    </el-form-item>

    <el-row class="formBtn">
      <el-button @click="$emit('knowledgeClassReset', true, true)" round>取 消</el-button>
      <el-button type="primary" @click="confirmknowledgeClass" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { addKnowledgeClass, editKnowledgeClass } from '@/api/user'
export default {
  name: 'AddTopclass',
  props: {
    flag: {
      type: String,
      default: 'add'
    },
    rows: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      filterForm: {
        name: '',
        explain: '',
        level: '1'
      },
      rulesForm: {
        name: [{ required: true, message: '一级分类不能为空', trigger: 'change' }]
      }
    }
  },
  mounted() {
    if (this.flag === 'edit') {
      this.filterForm = Object.assign({}, this.rows)
    }
  },
  methods: {
    // 确认按钮
    confirmknowledgeClass() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        let res
        if (this.flag === 'add') {
          res = await addKnowledgeClass(this.filterForm)
        } else {
          res = await editKnowledgeClass(this.filterForm)
        }
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('knowledgeClassReset', true)
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
