<template>
  <div>
    <My-tabs :tabTitle="'一级分类'">
      <template v-slot:collapseTab>
        <el-table
          ref="tableRef"
          :data="tableData"
          stripe
          style="width:100%"
          class="publicTable"
          highlight-current-row
          @current-change="currentTableChange"
          @sort-change="tableSortChange"
        >
          <el-table-column
            label="ID"
            prop="id"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column
            label="一级分类名称"
            prop="name"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column
            label="描述"
            prop="explain"
            show-overflow-tooltip
            width="300"
            sortable="custom"
          ></el-table-column>
          <el-table-column
            label="提交机构"
            prop="createdDptName"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column
            label="提交人"
            prop="createdByUserName"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column
            label="提交时间"
            prop="createdTime"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
        </el-table>

        <el-pagination
          :total="filterForm.pagTotal"
          layout="total, prev, pager, next, jumper"
          background
          :page-size="filterForm.size"
          :current-page="filterForm.page"
          @current-change="currentPageChange"
        >
        </el-pagination>

        <el-row class="tableBtn">
          <el-button type="primary" round @click="addTopClass">
            新增
          </el-button>
          <el-button type="primary" round @click="editTopClass">
            修改
          </el-button>
          <el-button round type="danger" plain @click="delTopClass">删除</el-button>
        </el-row>
      </template>
    </My-tabs>

    <Subclass :tableSub="tableSub" @topTableReset="topTableReset" />

    <My-dialog :title="titleDia" :className="'publicNDialog'" ref="addTopclassDia" :width="'40%'">
      <Add-topclass @knowledgeClassReset="knowledgeClassInit" :flag="flag" :rows="rows" />
    </My-dialog>
  </div>
</template>

<script>
import Subclass from './components/Subclass'
import AddTopclass from './components/AddTopclass'
import { addDiaMix } from '@/mixins'
import { getKnowledgeClass, delKnowledgeClass } from '@/api/user'
export default {
  name: 'Knowledge',
  components: {
    Subclass,
    AddTopclass
  },
  mixins: [addDiaMix],
  data() {
    return {
      tableData: [], // 表格数据
      tableSub: {},
      currentRow: {},
      filterForm: {
        page: 1,
        size: 5,
        pagTotal: 0
      }
    }
  },
  mounted() {
    this.knowledgeClassInit()
  },
  methods: {
    // 获取知识分类
    async knowledgeClassInit(v, p) {
      if (!this.closePublic(v, p, 'addTopclassDia')) return

      const res = await getKnowledgeClass(this.filterForm)

      if (res.data.status === 200) {
        this.tableData = res.data.obj.knowledgeMainList
        this.filterForm.pagTotal = res.data.obj.totle
        this.tableSub = {}
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 表格排序
    tableSortChange(par) {
      if (par.order === 'ascending') {
        this.filterForm.sortField = par.prop
        this.filterForm.sortType = '1'
        this.knowledgeClassInit()
      } else if (par.order === 'descending') {
        this.filterForm.sortField = par.prop
        this.filterForm.sortType = '0'
        this.knowledgeClassInit()
      } else {
        this.filterForm.sortField = ''
        this.filterForm.sortType = ''
        this.knowledgeClassInit()
      }
    },

    // 分页改变
    currentPageChange(currentPage) {
      this.filterForm.page = currentPage
      this.knowledgeClassInit()
    },

    // 单选改变事件 获取子类
    currentTableChange(currentRow) {
      this.currentRow = Object.assign({}, currentRow)
      this.tableSub = Object.assign({}, currentRow)
    },

    // 新增
    addTopClass() {
      this.addPublic('addTopclassDia', '新增一级分类')
    },

    // 修改
    editTopClass() {
      if (JSON.stringify(this.currentRow) === '{}') return this.$message.warning('请选择一条数据')
      this.$refs.addTopclassDia.dialogVisible = true
      this.titleDia = '修改一级分类'
      this.flag = 'edit'
      this.rows = Object.assign({}, this.currentRow)
    },

    // 删除
    delTopClass() {
      if (JSON.stringify(this.currentRow) === '{}') return this.$message.warning('请选择一条数据')

      this.$confirm('确定删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        closeOnClickModal: false
      })
        .then(async () => {
          const res = await delKnowledgeClass([{ id: this.currentRow.id }])
          if (res.data.status === 200) {
            this.$message.success(res.data.msg)
            this.knowledgeClassInit()
          } else {
            this.$message.error(res.data.msg)
          }
        })
        .catch(() => {})
    },

    // 子集发生变化时也重新赋值
    topTableReset(row) {
      this.tableData.forEach(item => {
        if (item.id === row.id) {
          item.children = row.children
        }
      })
      this.$refs.tableRef.setCurrentRow(row)
    }
  }
}
</script>

<style scoped lang="less"></style>
