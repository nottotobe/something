<template>
  <div>
    <My-tabs :tabTitle="'标签管理'">
      <template v-slot:collapseTab>
        <el-form :model="filterForm">
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="关键词" prop="name">
                <el-input v-model="filterForm.name" placeholder="请输入内容" clearable></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="提交日期" prop="dateRange">
                <el-date-picker
                  v-model="filterForm.dateRange"
                  type="daterange"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  unlink-panels
                  value-format="yyyy-MM-dd HH:mm:ss"
                  :default-time="['00:00:00', '23:59:59']"
                >
                  >
                </el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="审核状态" prop="examStatus">
                <el-select v-model="filterForm.examStatus" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in examStatusList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col class="formBtn">
              <el-button type="primary" round @click="tagDataInit(false, false, 'query')"
                >查询</el-button
              >
              <el-button round type="info" plain>重置</el-button>
            </el-col>
          </el-row>
        </el-form>
      </template>

      <el-table
        ref="tableRef"
        :data="tableData"
        stripe
        style="width:100%"
        class="publicTable"
        @row-click="rowClick"
        @selection-change="selectionChange"
        @sort-change="tableSortChange"
      >
        <el-table-column type="selection"> </el-table-column>
        <el-table-column label="标签ID" prop="id" show-overflow-tooltip sortable="custom">
        </el-table-column>
        <el-table-column
          label=" 标签名称"
          prop="name"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="提交机构"
          prop="createdDptName"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="提交人"
          prop="createdByUserName"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="提交时间"
          prop="createdTime"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="状态"
          prop="examStatus"
          show-overflow-tooltip
          sortable="custom"
          :formatter="tableFormatter"
        ></el-table-column>
      </el-table>

      <el-pagination
        :total="filterForm.pagTotal"
        layout="total, prev, pager, next, jumper"
        background
        :page-size="filterForm.size"
        :current-page="filterForm.page"
        @current-change="currentChange"
      >
      </el-pagination>

      <el-row class="tableBtn">
        <el-button type="primary" round @click="addTag">新增</el-button>
        <el-button type="primary" round @click="editTag">修改</el-button>
        <el-button type="warning" round @click="reviewTag" v-show="this.identity === 'admin'"
          >审核</el-button
        >
        <el-button round type="danger" plain @click="delTag">删除</el-button>
      </el-row>
    </My-tabs>

    <My-dialog :title="titleDia" :className="'publicNDialog'" ref="newTagDia" :width="'40%'">
      <New-tag :flag="flag" :identity="identity" :rows="rows" @tagDataReset="tagDataInit" />
    </My-dialog>

    <My-dialog :title="'标签审核'" :className="'publicNDialog'" ref="auditTagDia" :width="'40%'">
      <Audit-Tag :auditId="auditId" @tagReset="tagDataInit" />
    </My-dialog>
  </div>
</template>

<script>
import NewTag from './components/NewTag.vue'
import AuditTag from './components/AuditTag.vue'
import { getTagData, delTagData } from '@/api/user'
import { tableMix, addDiaMix } from '@/mixins'
export default {
  name: 'TagManage',
  components: {
    NewTag,
    AuditTag
  },
  mixins: [tableMix, addDiaMix],
  data() {
    return {
      filterForm: {
        name: '',
        startTime: '',
        endTime: '',
        dateRange: '',
        page: 1,
        size: 10,
        pagTotal: 0
      },
      titleDia: '',
      rows: {},
      examStatusList: [
        {
          id: '0',
          name: '待审批'
        },
        {
          id: '1',
          name: '审批通过'
        },
        {
          id: '2',
          name: '审批退回'
        }
      ],
      identity: '',
      auditId: []
    }
  },
  watch: {
    'filterForm.dateRange'(value) {
      if (value) {
        this.filterForm.startTime = value[0]
        this.filterForm.endTime = value[1]
      } else {
        this.filterForm.startTime = ''
        this.filterForm.endTime = ''
      }
    }
  },
  mounted() {
    this.tagDataInit()
    this.identity = this.$route.query.isAdmin
  },
  methods: {
    // 获取标签数据
    async tagDataInit(v, p, n) {
      if (!this.closePublic(v, p, n)) return
      if (n === 'query') {
        this.filterForm.page = 1
      }
      const res = await getTagData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.labelList
        this.filterForm.pagTotal = res.data.obj.totle
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 表格排序
    tableSortChange(par) {
      this.sortChange(par, this.tagDataInit)
    },

    // 分页改变
    currentChange(currentPage) {
      this.filterForm.page = currentPage
      this.tagDataInit()
    },

    // 新增
    addTag() {
      this.addPublic('newTagDia', '新增标签')
    },

    // 修改
    editTag() {
      this.editPublic('newTagDia', '修改标签')
    },

    // 删除
    delTag() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      const newArr = []
      this.selectedRows.forEach(item => {
        newArr.push({
          id: item.id
        })
      })
      this.$confirm('确定删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        closeOnClickModal: false
      })
        .then(async () => {
          const res = await delTagData(newArr)
          if (res.data.status === 200) {
            this.$message.success(res.data.msg)
            this.tagDataInit()
          } else {
            this.$message.error(res.data.msg)
          }
        })
        .catch(() => {})
    },

    // 表格数据格式化
    tableFormatter(row, column, cellValue, index) {
      let value = ''
      this[`${column.property}List`].forEach(item => {
        if (Number(cellValue) === Number(item.id)) {
          value = item.name
        }
      })
      return value
    },

    // 审核
    reviewTag() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      this.$refs.auditTagDia.dialogVisible = true
      this.auditId = []
      this.selectedRows.forEach(item => {
        this.auditId.push(item.id)
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
