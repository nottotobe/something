<template>
  <div>
    <My-collapse :title="'推送消息列表'">
      <el-table
        ref="tableRef"
        :data="tableData"
        stripe
        style="width:100%"
        class="publicTable"
        @row-click="rowClick"
        @selection-change="selectionChange"
      >
        <el-table-column type="selection"> </el-table-column>
        <el-table-column label="消息ID" prop="messageId" show-overflow-tooltip></el-table-column>
        <el-table-column
          label="消息内容"
          prop="content"
          show-overflow-tooltip
          min-width="300"
        ></el-table-column>
        <el-table-column label="可见范围" prop="range" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-button @click.native.stop="viewRange(scope.row.sysMsgRangeList)" type="text">
              {{ scope.row.sysMsgRangeList.length === 0 ? '全部可见' : '部分可见' }}
            </el-button>
          </template>
        </el-table-column>
        <el-table-column
          label="提交人"
          prop="createdByUserName"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          label="提交时间"
          prop="createdTime"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column label="启用" prop="status" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-switch
              v-model="scope.row.status"
              @click.native.stop
              @change="stateChange(scope.row.messageId, scope.row.status)"
              inactive-value="0"
              active-value="1"
            ></el-switch>
          </template>
        </el-table-column>
      </el-table>

      <el-row class="tableBtn">
        <el-button type="primary" round @click="addMessage">新增</el-button>
        <el-button type="primary" round @click="editMessage">修改</el-button>
        <el-button round type="danger" plain @click="delMessage">删除</el-button>
      </el-row>
    </My-collapse>

    <My-dialog :title="titleDia" :className="'publicNDialog'" :width="'40%'" ref="messageDia">
      <Message-add :flag="flag" :rows="rows" @messageDataReset="messageDataReset" />
    </My-dialog>

    <My-dialog :title="'可见人员'" :className="'publicNDialog'" :width="'40%'" ref="viewDia">
      <My-view :viewList="viewList" @closeView="closeView" />
    </My-dialog>
  </div>
</template>

<script>
import MessageAdd from './components/MessageAdd.vue'
import MyView from '@/components/MyView.vue'
import { getMessageData, getAllRoleData, delMessageData, messageReset } from '@/api/user'
import { tableMix, addDiaMix, viewMix } from '@/mixins'
import { mapActions } from 'vuex'
export default {
  name: 'Message',
  mixins: [tableMix, addDiaMix, viewMix],
  components: {
    MessageAdd,
    MyView
  },
  data() {
    return {
      roleList: []
    }
  },
  mounted() {
    this.messageDataInit()
  },
  methods: {
    // 轮播图数据
    ...mapActions(['getCarouselData']),

    // switch发生改变时候的回调
    async stateChange(messageId, status) {
      const res = await messageReset({
        messageId,
        status
      })
      if (res.data.status !== 200) {
        this.$message.error(res.data.msg)
        return
      }
      this.getCarouselData()
    },

    // 初始数据
    async messageDataInit() {
      const res = await getMessageData()
      this.tableData = res.data.obj

      const role = await getAllRoleData()
      this.roleList = role.data.obj
    },

    // 弹出框关闭
    async messageDataReset(name, flag) {
      if (flag) {
        const res = await getMessageData()
        this.tableData = res.data.obj
        this.getCarouselData()
      }

      if (name) {
        this.$refs[name].dialogVisible = false
      }
    },

    // 新增
    addMessage() {
      this.addPublic('messageDia', '新增消息')
    },

    // 修改
    editMessage() {
      this.editPublic('messageDia', '修改消息')
    },

    // 删除
    async delMessage() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      const newArr = []
      this.selectedRows.forEach(item => {
        newArr.push({
          messageId: item.messageId
        })
      })
      const res = await delMessageData(newArr)
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.messageDataReset('', true)
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 可见人员
    viewRange(v) {
      if (v.length === 0) {
        this.viewList = this.roleList
      } else {
        this.viewList = v
      }
      this.$refs.viewDia.dialogVisible = true
    }
  }
}
</script>

<style scoped lang="less"></style>
