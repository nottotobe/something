<template>
  <el-form :model="filterForm" ref="formRef">
    <el-form-item label="消息文本" prop="input">
      <el-input
        type="textarea"
        placeholder="请输入内容"
        v-model="filterForm.content"
        maxlength="20"
        show-word-limit
        :autosize="{ minRows: 2, maxRows: 2 }"
      >
      </el-input>
    </el-form-item>

    <el-form-item label="可见范围" prop="sysMsgRangeList">
      <el-select v-model="filterForm.sysMsgRangeList" multiple placeholder="请选择">
        <el-option
          v-for="item in sysMsgRangeListList"
          :key="item.roleId"
          :label="item.name"
          :value="item.roleId"
        >
        </el-option>
      </el-select>
    </el-form-item>

    <el-row class="formBtn">
      <el-button @click="$emit('messageDataReset', 'messageDia')" round>取 消</el-button>
      <el-button type="primary" @click="confirmMessage" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { getAllRoleData, addMessageData, editMessageData } from '@/api/user'
export default {
  name: 'MessageAdd',
  props: {
    flag: {
      type: String,
      default: 'add'
    },
    rows: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      filterForm: {
        content: '',
        sysMsgRangeList: []
      },
      sysMsgRangeListList: []
    }
  },
  mounted() {
    this.messageInit()
  },
  methods: {
    // 初始化
    async messageInit() {
      const res = await getAllRoleData()
      this.sysMsgRangeListList = res.data.obj

      if (this.flag === 'edit') {
        this.filterForm = Object.assign({}, this.rows)
        const newArr = []
        if (this.filterForm.sysMsgRangeList.length === 0) {
          this.sysMsgRangeListList.forEach(item => {
            newArr.push(item.roleId)
          })
        } else {
          this.filterForm.sysMsgRangeList.forEach(item => {
            newArr.push(item.roleId)
          })
        }
        this.filterForm.sysMsgRangeList = newArr
      }
    },

    // 确认
    async confirmMessage() {
      let res
      let newArr = []
      this.filterForm.sysMsgRangeList.forEach(item => {
        newArr.push({ roleId: item })
      })
      if (newArr.length === this.sysMsgRangeListList.length) {
        newArr = []
      }
      if (this.flag === 'add') {
        res = await addMessageData({
          content: this.filterForm.content,
          sysMsgRangeList: newArr
        })
      } else {
        res = await editMessageData({
          messageId: this.filterForm.messageId,
          content: this.filterForm.content,
          sysMsgRangeList: newArr
        })
      }
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.$emit('messageDataReset', 'messageDia', true)
      } else {
        this.$message.error(res.data.msg)
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
