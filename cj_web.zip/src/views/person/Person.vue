<template>
  <div>
    <div class="person_box">
      <el-image
        fit="cover"
        :src="filterForm.avatar"
        @click="$refs.editAvatarDia.dialogVisible = true"
      >
        <div slot="error" class="image-slot" @click="$refs.editAvatarDia.dialogVisible = true">
          加载失败
        </div>
      </el-image>
      <span class="person_name">{{ filterForm.username }}</span>
      <span class="person_other"> {{ filterForm.dptName }}</span>
    </div>

    <My-tabs :tabTitle="'基本信息'">
      <template v-slot:collapseTab>
        <el-form :model="filterForm" ref="formRef">
          <el-row>
            <el-col :span="12">
              <el-form-item label="用户ID" prop="userId">
                <el-input v-model="filterForm.userId" placeholder="请输入内容" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="用户名" prop="username">
                <el-input
                  v-model="filterForm.username"
                  placeholder="请输入内容"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="手机号" prop="mobile">
                <el-input v-model="filterForm.mobile" placeholder="请输入内容" disabled>
                  <el-button
                    slot="append"
                    type="primary"
                    @click="$refs.editMobileDia.dialogVisible = true"
                    >{{ filterForm.mobile ? '修改' : '添加' }}</el-button
                  >
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="机构" prop="dptName">
                <el-input v-model="filterForm.dptName" placeholder="请输入内容" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="密码" prop="password">
                <el-input v-model="filterForm.password" placeholder="请输入内容" disabled>
                  <el-button
                    slot="append"
                    type="primary"
                    @click="$refs.editPasswordDia.dialogVisible = true"
                    >修改</el-button
                  >
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="邮箱" prop="email">
                <el-input v-model="filterForm.email" placeholder="请输入内容" disabled>
                  <el-button
                    slot="append"
                    type="primary"
                    @click="$refs.editEmailDia.dialogVisible = true"
                    >{{ filterForm.email ? '修改' : '添加' }}</el-button
                  >
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="角色">
                <el-select v-model="filterForm.roles" multiple placeholder="请选择" disabled>
                  <el-option
                    v-for="item in rolesList"
                    :key="item.roleId"
                    :label="item.name"
                    :value="item.roleId"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </template>

      <el-row class="formBtn">
        <el-button round @click="logout" type="info" plain>退出登陆</el-button>
      </el-row>
    </My-tabs>

    <My-dialog
      :title="filterForm.mobile ? '修改手机号' : '添加手机号'"
      :className="'publicNDialog'"
      :width="'40%'"
      ref="editMobileDia"
    >
      <Edit-mobile @mobileReset="personDataInit" :title="filterForm.mobile" />
    </My-dialog>

    <My-dialog title="修改密码" :className="'publicNDialog'" :width="'40%'" ref="editPasswordDia">
      <Edit-password @passwordReset="personDataInit" />
    </My-dialog>

    <My-dialog
      :title="filterForm.email ? '修改邮箱' : '添加邮箱'"
      :className="'publicNDialog'"
      :width="'40%'"
      ref="editEmailDia"
    >
      <Edit-email @emailReset="personDataInit" />
    </My-dialog>

    <My-dialog title="修改头像" :className="'publicNDialog'" :width="'40%'" ref="editAvatarDia">
      <Edit-avatar :uploadList="avatarArr" @avatarReset="personDataInit" />
    </My-dialog>
  </div>
</template>

<script>
import EditAvatar from './components/EditAvatar.vue'
import EditEmail from './components/EditEmail.vue'
import EditMobile from './components/EditMobile.vue'
import EditPassword from './components/EditPassword.vue'
import { logout, getPersonData, getAllRoleData } from '@/api/user'
import { removeLocal, removeSession } from '@/utils/storage'
export default {
  name: 'Person',
  components: {
    EditMobile,
    EditPassword,
    EditEmail,
    EditAvatar
  },
  data() {
    return {
      filterForm: {
        userId: '',
        username: '',
        mobile: '',
        dptName: '',
        password: '',
        email: '',
        roles: []
      },
      uploadList: [],
      rolesList: [],
      avatarArr: []
    }
  },
  mounted() {
    this.roleDataInit()
    this.personDataInit()
  },
  methods: {
    // 初始化
    async personDataInit(v, p, n) {
      if (v) {
        this.$refs[n].dialogVisible = false
      }
      if (p) return

      const res = await getPersonData()
      if (res.data.status === 200) {
        this.filterForm = Object.assign({}, res.data.obj)
        if (!this.filterForm.avatar) {
          this.filterForm.avatar = require('@/assets/images/user_icon_img_default.png')
        }
        this.avatarArr = []
        this.avatarArr.push({
          name: this.filterForm.username,
          url: this.filterForm.avatar
        })
        if (this.filterForm.mobile) {
          this.filterForm.mobile = this.filterForm.mobile.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')
        }

        this.filterForm.password = '******'
        const newArr = []
        this.filterForm.roles.forEach(item => {
          newArr.push(item.roleId)
        })
        this.filterForm.roles = newArr
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 获取角色数据
    async roleDataInit() {
      const res = await getAllRoleData()
      if (res.data.status === 200) {
        this.rolesList = res.data.obj
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 退出
    logout() {
      this.$confirm('确定要退出吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'info',
        closeOnClickModal: false
      })
        .then(async () => {
          const res = await logout()
          if (res.data.status === 200) {
            this.$router.push('/login')
            removeSession('activePath')
            removeLocal('isUser')
            removeLocal('menuList')
            this.$message.success(res.data.msg)
            window.location.reload()
          } else {
            this.$message.error(res.data.msg)
          }
        })
        .catch(() => {})
    }
  }
}
</script>

<style scoped lang="less">
.person_box {
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: center;
  height: 300px;
  background: url('../../assets/images/BG/use_img_bg_default.png') no-repeat;
  background-size: 100% 150px;
  .el-image {
    border-radius: 50%;
    width: 150px;
    height: 150px;
    cursor: pointer;
    /deep/ .image-slot {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 100%;
      background: #f5f7fa;
      color: #909399;
      font-size: 14px;
    }
  }
  .person_name {
    font-weight: 900;
    font-size: 30px;
  }
  .person_other {
    color: #b6b6b6;
  }
}
.abc {
  display: none;
}
</style>
