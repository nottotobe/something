<template>
  <div v-loading="loading" class="upload_mask">
    <el-upload
      ref="uploadRef"
      class="upAvatar"
      action="#"
      list-type="picture-card"
      :on-change="uploadChange"
      :before-upload="uploadBefore"
      :on-remove="uploadRemove"
      :on-success="uploadSuccess"
      :on-error="uploadError"
      :file-list="uploadList"
      :http-request="goUpload"
      accept=".jpg,.png"
    >
      <el-button type="primary">重新选择</el-button>
      <div slot="file" slot-scope="{ file }">
        <el-image
          class="el-upload-list__item-thumbnail"
          :src="file.url"
          alt=""
          :preview-src-list="srcList"
          fit="cover"
          ref="previewImg"
        />
        <span class="el-upload-list__item-actions">
          <span class="el-upload-list__item-preview" @click="handlePictureCardPreview(file)">
            <i class="el-icon-zoom-in"></i>
          </span>
        </span>
      </div>
    </el-upload>

    <el-row class="upload_tip">
      只能上传jpg/png文件，且不超过2M
    </el-row>

    <el-row class="formBtn">
      <el-button @click="$emit('avatarReset', true, true, 'editAvatarDia')" round>取 消</el-button>
      <el-button type="primary" @click="confirmAvatar" round>确 定</el-button>
    </el-row>
  </div>
</template>

<script>
import { upload, editAvatar } from '@/api/user'
export default {
  name: 'EditAvatar',
  props: {
    uploadList: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      loading: false,
      srcList: [],
      avatarSrc: ''
    }
  },
  mounted() {
    this.srcList.push(this.uploadList[0].url)
    this.avatarSrc = this.uploadList[0].url
  },
  methods: {
    // 文件上传之前
    uploadBefore(file) {
      const isLt10M = file.size / 1024 / 1024 < 2
      if (!isLt10M) {
        this.$message.warning('上传图片大小不能超过2M')
        return false
      }
      this.loading = true
    },

    // 文件上传
    async goUpload(v) {
      const fd = new FormData()
      fd.append('name', v.file.name)
      fd.append('file', v.file)
      const res = await upload(fd)
      if (res.data.status === 200) {
        this.avatarSrc = res.data.obj.imageUri
      }
    },

    // 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
    uploadChange(file, fileList) {},

    // 文件列表移除文件时的钩子
    uploadRemove(file, fileList) {},

    // 文件上传成功时的钩子
    uploadSuccess(response, file, fileList) {
      this.$refs.uploadRef.handleRemove(fileList[0])
      this.srcList.splice(0, 1, file.url)
      setTimeout(() => {
        this.loading = false
      }, 1000)
    },
    // 文件上传失败时的钩子
    uploadError() {
      setTimeout(() => {
        this.loading = false
      }, 1000)
    },
    // 点击预览按钮
    handlePictureCardPreview(file) {
      this.$refs.previewImg.showViewer = true
    },
    // 确认
    async confirmAvatar() {
      const res = await editAvatar({ avatar: this.avatarSrc })
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.$emit('avatarReset', true, false, 'editAvatarDia')
      } else {
        this.$message.error(res.data.msg)
      }
    }
  }
}
</script>

<style scoped lang="less">
.upAvatar {
  display: flex;
  justify-content: space-around;
  align-items: center;

  /deep/ .el-upload-list__item,
  .el-image {
    width: 250px;
    height: 250px;
    border-radius: 50%;
  }
  /deep/ .el-upload--picture-card {
    width: unset;
    height: unset;
    line-height: unset;
    border: none;
  }
}

.upload_mask {
  padding-top: 40px;
  /deep/ .el-loading-mask {
    background: #fff;
  }
}

.upload_tip {
  text-align: center;
  margin: 15px 0;
  color: #a8a8a8;
}
</style>
