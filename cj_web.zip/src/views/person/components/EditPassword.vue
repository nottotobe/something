<template>
  <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
    <el-form-item label="原密码" prop="oldPassword">
      <el-input
        v-model="filterForm.oldPassword"
        placeholder="请输入内容"
        clearable
        type="password"
      ></el-input>
    </el-form-item>

    <el-form-item label="新密码" prop="newPassword">
      <el-input
        v-model="filterForm.newPassword"
        placeholder="请输入内容"
        clearable
        type="password"
      ></el-input>
    </el-form-item>

    <el-form-item label="确认新密码" prop="confirmPassword">
      <el-input
        v-model="filterForm.confirmPassword"
        placeholder="请输入内容"
        clearable
        type="password"
      ></el-input>
    </el-form-item>

    <el-row class="formBtn">
      <el-button @click="$emit('passwordReset', true, true, 'editPasswordDia')" round>
        取 消</el-button
      >
      <el-button type="primary" @click="confirmPassword" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { editPassword } from '@/api/user'
import { validPassword } from '@/utils/validate'
export default {
  name: 'EditPassword',
  data() {
    return {
      filterForm: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      },
      rulesForm: {
        oldPassword: [{ required: true, message: '原密码不能为空', trigger: 'change' }],
        newPassword: [
          { required: true, message: '新密码不能为空', trigger: 'change' },
          { validator: validPassword, trigger: 'blur' }
        ],
        confirmPassword: [
          { required: true, message: '确认新密码不能为空', trigger: 'change' },
          { validator: validPassword, trigger: 'blur' }
        ]
      }
    }
  },
  mounted() {},
  methods: {
    // 确定
    confirmPassword() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        if (this.filterForm.newPassword !== this.filterForm.confirmPassword) {
          this.$message.warning('两次密码输入的不一致')
          return
        }
        const res = await editPassword(this.filterForm)
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('passwordReset', true, false, 'editPasswordDia')
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
