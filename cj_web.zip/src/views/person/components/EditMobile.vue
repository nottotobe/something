<template>
  <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
    <el-form-item label="原手机号" prop="oldMobile" v-if="title">
      <el-input v-model="filterForm.oldMobile" placeholder="请输入内容" clearable></el-input>
    </el-form-item>

    <el-form-item label="新手机号" prop="newMobile">
      <el-input v-model="filterForm.newMobile" placeholder="请输入内容" clearable></el-input>
    </el-form-item>

    <el-form-item label="短信验证码" prop="code">
      <el-input v-model="filterForm.code" placeholder="请输入内容" clearable>
        <el-button slot="append" @click="sendCode" class="send_btn">{{ sendValue }}</el-button>
      </el-input>
    </el-form-item>

    <el-row class="formBtn">
      <el-button @click="$emit('mobileReset', true, true, 'editMobileDia')" round>取 消</el-button>
      <el-button type="primary" @click="confirmMobile" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { editMobile, getPersonCode } from '@/api/user'
import { validMobile } from '@/utils/validate'
export default {
  name: 'EditMobile',
  props: {
    title: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      filterForm: {
        oldMobile: '',
        newMobile: '',
        code: ''
      },
      sendValue: '发送验证码',
      sendTimer: null,
      sendCount: 60,
      rulesForm: {
        oldMobile: [
          { required: true, message: '原手机号不能为空', trigger: 'change' },
          { validator: validMobile, trigger: 'blur' }
        ],
        newMobile: [
          { required: true, message: '新手机号不能为空', trigger: 'change' },
          { validator: validMobile, trigger: 'blur' }
        ],
        code: [{ required: true, message: '验证码不能为空', trigger: 'change' }]
      }
    }
  },
  mounted() {},
  methods: {
    // 发送验证码
    async sendCode() {
      this.$refs.formRef.validateField('newMobile', async valid => {
        if (valid) return
        if (!this.sendTimer) {
          const res = await getPersonCode(this.filterForm.newMobile)
          this.$message.success(res.data.obj)
          const that = this
          const fun = function() {
            that.sendValue = that.sendCount + '秒后重新发送'
            that.sendCount--
            if (that.sendCount < 0) {
              that.sendValue = '发送验证码'
              that.sendCount = 60
              window.clearInterval(that.sendTimer)
              that.sendTimer = null
            }
          }
          fun()
          this.sendTimer = window.setInterval(fun, 1000)
        }
      })
    },

    // 确定
    confirmMobile() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        const res = await editMobile(this.filterForm)
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('mobileReset', true, false, 'editMobileDia')
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
