<template>
  <el-form :model="filterForm" ref="formRef" label-width="80px" :rules="rulesForm">
    <el-form-item label="邮箱账号" prop="email">
      <el-input v-model="filterForm.email" placeholder="请输入内容" clearable></el-input>
    </el-form-item>

    <el-row :gutter="24">
      <el-col :span="18">
        <el-form-item label="验证码" prop="code">
          <el-input v-model="filterForm.code" placeholder="请输入内容" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-image
          style="width:100%;height:40px;cursor:pointer"
          :src="codeImgSrc"
          @click="codeImgInit"
        ></el-image>
      </el-col>
    </el-row>

    <el-row class="formBtn">
      <el-button @click="$emit('emailReset', true, true, 'editEmailDia')" round>取 消</el-button>
      <el-button type="primary" @click="confirmEmail" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { getCodeImg, editEmail } from '@/api/user'
import { validEmail } from '@/utils/validate'
export default {
  name: 'EditEmail',
  data() {
    return {
      filterForm: {
        email: '',
        code: ''
      },
      codeImgSrc: '',
      rulesForm: {
        email: [
          { required: true, message: '邮箱账号不能为空', trigger: 'change' },
          { validator: validEmail, trigger: 'blur' }
        ],
        code: [{ required: true, message: '验证码不能为空', trigger: 'change' }]
      }
    }
  },
  mounted() {
    this.codeImgInit()
  },
  methods: {
    // 图片验证码
    async codeImgInit() {
      const res = await getCodeImg()
      this.codeImgSrc = window.URL.createObjectURL(res.data)

      // 也可以用下面的方法
      // this.codeImgSrc = 'oam/code?time=' + new Date().getTime()
    },

    // 确定
    confirmEmail() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        const res = await editEmail(this.filterForm)
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('emailReset', true, false, 'editEmailDia')
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
