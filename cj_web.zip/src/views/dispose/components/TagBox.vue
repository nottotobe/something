<template>
  <div>
    <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
      <el-form-item label="标签" prop="labelList">
        <el-select
          v-model="filterForm.labelList"
          multiple
          placeholder="请选择"
          clearable
          filterable
          default-first-option
          allow-create
        >
          <el-option v-for="item in labelList" :key="item.id" :label="item.name" :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>

      <el-row class="formBtn">
        <el-button type="primary" round @click="confirmTagbox">确定</el-button>
        <el-button round @click="$emit('closeDialog', 'tagBoxDia', true)">取消</el-button>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { getTagData, addWorkTag, batchAddWorkTag } from '@/api/user'
import { getLocal } from '@/utils/storage'
export default {
  name: 'TagBox',
  props: {
    ticketIdArr: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      filterForm: {
        labelList: []
      },
      labelList: [],
      rulesForm: {
        labelList: [{ required: true, message: '标签不能为空', trigger: 'change' }]
      }
    }
  },
  mounted() {
    this.tagBoxInit()
  },
  methods: {
    // 获取知识分类和标签
    async tagBoxInit() {
      const tag = await getTagData()
      this.labelList = tag.data.obj.labelList.filter(item => {
        return item.examStatus === '1'
      })
    },

    // 确认
    confirmTagbox() {
      this.$refs.formRef.validate(valid => {
        if (!valid) return
        this.beforeConfirmTagbox().then(async value => {
          if (value.length > 0) {
            const newArr = []
            const tagArr = []
            value.forEach(item => {
              tagArr.push({ id: item })
            })
            this.ticketIdArr.forEach(item => {
              newArr.push({
                ticketId: item,
                labelList: tagArr
              })
            })
            const res = await addWorkTag(newArr)
            if (res.data.status === 200) {
              this.$message.success(res.data.msg)
              this.$emit('closeDialog', 'tagBoxDia')
            } else {
              this.$message.error(res.data.msg)
            }
          }
        })
      })
    },

    // 确认前要做的操作
    async beforeConfirmTagbox() {
      const newTag = this.filterForm.labelList.filter(item => {
        return !this.labelList.some(value => {
          return Number(item) === Number(value.id)
        })
      })
      const oldTag = this.filterForm.labelList.filter(item => {
        return this.labelList.some(value => {
          return Number(item) === Number(value.id)
        })
      })
      const menuList = getLocal('menuList')
      let par = ''
      menuList.forEach(item => {
        if (item.name === '知识管理') {
          item.children.forEach(value => {
            if (value.name === '标签管理') {
              if (value.explain === 'admin') {
                par = '1'
              } else {
                par = '0'
              }
            }
          })
        }
      })
      const newArr = []
      newTag.forEach(item => {
        newArr.push({
          name: item,
          examStatus: par
        })
      })
      let flag = []
      const res = await batchAddWorkTag(newArr)
      if (res.data.status === 200) {
        flag = oldTag.concat(res.data.obj)
      } else {
        this.$message.error(res.data.msg)
      }
      return flag
    }
  }
}
</script>

<style scoped lang="less"></style>
