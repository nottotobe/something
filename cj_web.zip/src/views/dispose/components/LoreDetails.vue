<template>
  <div>
    <el-descriptions :title="'问题ID：' + filterForm.id" border>
      <el-descriptions-item label="一级分类">{{ filterForm.firstTypeName }}</el-descriptions-item>
      <el-descriptions-item label="子类">{{ filterForm.secondTypeName }}</el-descriptions-item>
      <el-descriptions-item label="状态">{{ examStatusDes }}</el-descriptions-item>
      <!-- <el-descriptions-item label="提交人">{{ filterForm.createdByUserName }}</el-descriptions-item>
      <el-descriptions-item label="提交机构">{{ filterForm.createdDptName }}</el-descriptions-item>
      <el-descriptions-item label="提交时间">{{ filterForm.createdTime }}</el-descriptions-item> -->
      <el-descriptions-item label="标签" :span="3" v-if="filterForm.labelList.length !== 0">
        <el-tag
          size="small"
          v-for="(item, index) in filterForm.labelList"
          :key="index"
          style="margin-right:10px"
        >
          {{ item.name }}</el-tag
        >
      </el-descriptions-item>
      <el-descriptions-item label="知识标题" :span="3">{{ filterForm.title }}</el-descriptions-item>
      <el-descriptions-item label="知识内容" :span="3">{{
        filterForm.content
      }}</el-descriptions-item>
      <el-descriptions-item label="图片/视频" :span="3" v-if="picList.length !== 0">
        <MyUpload ref="myUpload" :uploadList="picList" :unloadDis="true" />
      </el-descriptions-item>
      <el-descriptions-item label="其他附件" :span="3" v-if="otherList.length !== 0">
        <ATT-upload ref="attUpload" :uploadList="otherList" :unloadDis="true" />
      </el-descriptions-item>
    </el-descriptions>
    <el-row class="iconStyle">
      <div :class="'dianzan ' + dianzanStyle" @click="knowledgeEval('1')">
        <span class="iconfont icon-dianzan"></span>
        <span>{{ '有用 (' + filterForm.useFulCount + ')' }}</span>
      </div>
      <div :class="'cai ' + caiStyle" @click="knowledgeEval('0')">
        <span class="iconfont icon-cai"></span>
        <span>{{ '没用 (' + filterForm.useLessCount + ')' }}</span>
      </div>
    </el-row>
    <el-row class="tableBtn">
      <el-button round @click="$emit('loreDetailsClose', true, true, 'loreDetailsDia')"
        >关闭</el-button
      >
    </el-row>
  </div>
</template>

<script>
import { getKnowledgeData, evalKnowledge } from '@/api/user'
import MyUpload from '@/components/MyUpload'
import ATTUpload from '@/components/ATTUpload'
export default {
  name: 'LoreDetails',
  props: {
    loreDetailsRows: {
      type: Object,
      default: () => {}
    }
  },
  components: {
    MyUpload,
    ATTUpload
  },
  data() {
    return {
      filterForm: {
        imageDataList: [],
        labelList: []
      },
      dianzanStyle: '',
      caiStyle: '',
      examStatusList: [
        {
          id: '0',
          name: '待审核'
        },
        {
          id: '1',
          name: '审核通过'
        },
        {
          id: '2',
          name: '不通过'
        }
      ]
    }
  },
  computed: {
    picList() {
      return this.filterForm.imageDataList.filter(item => {
        return (
          item.imageType === '.jpg' ||
          item.imageType === '.mp4' ||
          item.imageType === '.png' ||
          item.imageType === '.jpeg'
        )
      })
    },
    otherList() {
      const arr = []
      this.filterForm.imageDataList.forEach(item => {
        if (
          item.imageType !== '.jpg' &&
          item.imageType !== '.mp4' &&
          item.imageType !== '.png' &&
          item.imageType !== '.jpeg'
        ) {
          arr.push({ name: item.imageName, url: item.imageUri })
        }
      })
      return arr
    },
    examStatusDes() {
      const arr = this.examStatusList.filter(item => {
        return item.id === this.filterForm.examStatus
      })
      if (arr.length > 0) {
        return arr[0].name
      } else {
        return ''
      }
    }
  },
  mounted() {
    this.getKnowledgeData()
  },
  methods: {
    // 获取知识详情
    async getKnowledgeData(v) {
      const res = await getKnowledgeData({
        id: this.loreDetailsRows.id
      })

      if (v) {
        this.filterForm.useFulCount = res.data.obj.knowledgeDetailList[0].useFulCount
        this.filterForm.useLessCount = res.data.obj.knowledgeDetailList[0].useLessCount
        return
      }

      this.filterForm = Object.assign({}, res.data.obj.knowledgeDetailList[0])
    },

    // 评价
    async knowledgeEval(v) {
      let evalStatus = ''
      if (v === '1') {
        if (this.dianzanStyle) {
          evalStatus = '0'
          this.dianzanStyle = ''
        } else {
          evalStatus = '1'
          this.dianzanStyle = 'successClass'
          this.caiStyle = ''
        }
      }
      if (v === '0') {
        if (this.caiStyle) {
          evalStatus = '0'
          this.caiStyle = ''
        } else {
          evalStatus = '1'
          this.dianzanStyle = ''
          this.caiStyle = 'successClass'
        }
      }
      const res = await evalKnowledge({
        relationId: this.filterForm.id, // 知识id
        type: v, // 1有用 0没用
        status: evalStatus // 1确定  0 取消
      })
      if (res.data.status === 200) {
        this.getKnowledgeData(true)
        this.$emit('loreDetailsClose')
      } else {
        this.$message.error(res.data.msg)
      }
    }
  }
}
</script>

<style scoped lang="less">
.iconStyle {
  margin-top: 20px;
  display: flex;
  .dianzan,
  .cai {
    display: flex;
    align-items: center;
    margin-right: 25px;
    color: #a0a6b9;
    &:hover {
      color: #5980ff;
    }
    span {
      margin-right: 10px;
      cursor: pointer;
    }
  }
}

.successClass {
  color: #5980ff !important;
}
</style>
