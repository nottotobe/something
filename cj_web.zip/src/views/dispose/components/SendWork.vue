<template>
  <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
    <el-form-item label="机构" prop="updatedDpt">
      <el-cascader
        v-model="filterForm.updatedDpt"
        :props="dptCodeProps"
        :options="dptCodeList"
        :show-all-levels="false"
        clearable
        ref="checkStrictlyRef"
        popper-class="checkStrictlyStyle ignore"
      ></el-cascader>
    </el-form-item>

    <el-form-item label="人员" prop="updatedBy">
      <el-select v-model="filterForm.updatedBy" placeholder="请选择" clearable>
        <el-option
          v-for="item in updatedByList"
          :key="item.userId"
          :label="item.username"
          :value="item.userId"
        >
        </el-option>
      </el-select>
    </el-form-item>

    <el-form-item label="备注" prop="explain">
      <el-input
        type="textarea"
        placeholder="请输入内容"
        v-model="filterForm.explain"
        maxlength="20"
        show-word-limit
        :autosize="{ minRows: 2, maxRows: 2 }"
      >
      </el-input>
    </el-form-item>

    <el-row class="formBtn">
      <el-button @click="$emit('closeDialog', 'sendWorkDia', true)" round>取 消</el-button>
      <el-button type="primary" @click="confirmDeliverWork" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { deliverData, getUserData } from '@/api/user'
import { dptMix } from '@/mixins'
export default {
  name: 'SendWork',
  props: {
    ticketIdArr: {
      type: Array,
      required: true
    }
  },
  mixins: [dptMix],
  data() {
    return {
      filterForm: {
        updatedDpt: '',
        updatedBy: '',
        explain: ''
      },
      updatedByList: [],
      rulesForm: {
        updatedDpt: [{ required: true, message: '机构不能为空', trigger: 'change' }],
        updatedBy: [{ required: true, message: '人员不能为空', trigger: 'change' }]
      }
    }
  },
  watch: {
    'filterForm.updatedDpt'(newVlaue, oldValue) {
      if (this.$refs.checkStrictlyRef) {
        this.$refs.checkStrictlyRef.dropDownVisible = false
        this.updatedDptChange(newVlaue)
      }
    }
  },
  mounted() {},
  methods: {
    // 根据机构查询用户
    async updatedDptChange(v) {
      this.filterForm.updatedBy = ''
      this.updatedByList = []
      if (v) {
        const newObj = {}
        newObj.dptCode = this.filterForm.updatedDpt
        const res = await getUserData(newObj)
        if (res.data.status === 200) {
          this.updatedByList = res.data.obj.userList
        } else {
          this.$message.error(res.data.msg)
        }
      }
    },

    // 确定按钮
    confirmDeliverWork() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        const parArr = []
        this.ticketIdArr.forEach(item => {
          parArr.push({
            ticketId: item,
            updatedDpt: this.filterForm.updatedDpt,
            updatedBy: this.filterForm.updatedBy,
            explain: this.filterForm.explain
          })
        })
        const res = await deliverData(parArr)
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('closeDialog', 'sendWorkDia')
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
