<template>
  <div>
    <el-row class="topTitle">
      <el-col :span="24">跟踪该条数据，可到数据跟踪记录查看</el-col>
    </el-row>
    <el-form :model="filterForm" ref="formRef">
      <el-form-item label="备注" prop="remark">
        <el-input
          type="textarea"
          placeholder="请输入内容"
          v-model="filterForm.remark"
          maxlength="20"
          show-word-limit
          :autosize="{ minRows: 2, maxRows: 2 }"
        >
        </el-input>
      </el-form-item>

      <el-row class="formBtn">
        <el-button @click="$emit('closeDialog', 'trackWorkDia', true)" round>取 消</el-button>
        <el-button type="primary" @click="confirmTrackWork" round>确 定</el-button>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { trackData } from '@/api/user'
export default {
  name: 'TrackWork',
  props: {
    ticketIdArr: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      filterForm: {
        remark: ''
      }
    }
  },
  mounted() {},
  methods: {
    // 确定按钮
    async confirmTrackWork() {
      const parArr = []
      this.ticketIdArr.forEach(item => {
        parArr.push({
          ticketId: item,
          remark: this.filterForm.remark
        })
      })
      const res = await trackData(parArr)
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.$emit('closeDialog', 'trackWorkDia')
      } else {
        this.$message.error(res.data.msg)
      }
    }
  }
}
</script>

<style scoped lang="less">
.topTitle {
  margin-bottom: 20px;
}
</style>
