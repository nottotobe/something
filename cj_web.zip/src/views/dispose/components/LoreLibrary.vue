<template>
  <div>
    <el-row class="topTitle">
      <el-col :span="24">{{ rows.title }}</el-col>
      <el-col :span="24">{{
        rows.platformName + '/' + rows.typeName + '/' + rows.urgentName
      }}</el-col>
    </el-row>

    <el-form :model="filterForm" label-width="100px" ref="formRef">
      <el-row :gutter="24">
        <el-col :span="12">
          <el-form-item label="查询关键词" prop="title">
            <el-input v-model="filterForm.title" placeholder="请输入内容" clearable></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-button type="primary" round @click="knowledgeDataInit(false, false, 'query')"
            >查询</el-button
          >
        </el-col>
      </el-row>
    </el-form>

    <el-table
      ref="tableRef"
      :data="tableData"
      stripe
      style="width:100%"
      class="publicTable"
      highlight-current-row
      @current-change="currentTableChange"
      @row-dblclick="rowDblclick"
      @sort-change="tableSortChange"
    >
      <el-table-column
        label="知识ID"
        prop="id"
        show-overflow-tooltip
        sortable="custom"
      ></el-table-column>
      <el-table-column
        label="知识标题"
        prop="title"
        show-overflow-tooltip
        width="500"
        sortable="custom"
      ></el-table-column>
      <el-table-column
        label="一级分类"
        prop="firstTypeName"
        show-overflow-tooltip
        sortable="custom"
      ></el-table-column>
      <el-table-column
        label="子类"
        prop="secondTypeName"
        show-overflow-tooltip
        sortable="custom"
      ></el-table-column>
      <el-table-column label="标签" prop="labelList" show-overflow-tooltip>
        <template slot-scope="scope">
          <el-button @click.native.stop="viewTag(scope.row.labelList)" type="text">
            查看
          </el-button>
        </template>
      </el-table-column>
      <el-table-column
        label="有用"
        prop="useFulCount"
        show-overflow-tooltip
        sortable="custom"
      ></el-table-column>
    </el-table>

    <el-pagination
      layout="total, prev, pager, next, jumper"
      :total="filterForm.pagTotal"
      :page-size="filterForm.size"
      :current-page="filterForm.page"
      background
      @current-change="currentPageChange"
    >
    </el-pagination>

    <el-row class="tableBtn">
      <el-button type="primary" round @click="confirmLoreLibrary">确定</el-button>
      <el-button round @click="$emit('loreLibraryMatch', false)">取消</el-button>
    </el-row>

    <My-dialog
      :title="'知识详情'"
      :className="'publicNDialog'"
      ref="loreDetailsDia"
      :width="'80%'"
      :appendBody="true"
    >
      <Lore-details :loreDetailsRows="loreDetailsRows" @loreDetailsClose="knowledgeDataInit" />
    </My-dialog>

    <My-dialog
      :title="'查看标签'"
      :className="'publicNDialog'"
      :width="'40%'"
      ref="viewDia"
      :appendBody="true"
    >
      <My-view :viewList="viewList" @closeView="closeView" />
    </My-dialog>
  </div>
</template>

<script>
import LoreDetails from './LoreDetails'
import MyView from '@/components/MyView'
import { viewMix } from '@/mixins'
import { matchKnowledgeData } from '@/api/user'
export default {
  name: 'LoreLibrary',
  components: {
    LoreDetails,
    MyView
  },
  mixins: [viewMix],
  props: {
    rows: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      filterForm: {
        title: '',
        page: 1,
        size: 5,
        pagTotal: 0
      },
      tableData: [], // 表格数据
      currentRow: {},
      platform: '',
      type: '',
      urgent: '',
      firstTypeList: [],
      loreDetailsRows: {}
    }
  },
  mounted() {
    this.knowledgeDataInit()
  },
  methods: {
    // 双击查看详情
    rowDblclick(row, column, event) {
      this.$refs.loreDetailsDia.dialogVisible = true
      this.loreDetailsRows = Object.assign({}, row)
    },

    // 获取知识数据
    async knowledgeDataInit(v, p, n) {
      if (v) {
        this.$refs[n].dialogVisible = false
      }
      if (p) return

      if (n === 'query') {
        this.filterForm.page = 1
      }

      const res = await matchKnowledgeData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.knowledgeDetailList
        this.filterForm.pagTotal = res.data.obj.totle
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 表格排序
    tableSortChange(par) {
      if (par.order === 'ascending') {
        this.filterForm.sortField = par.prop
        this.filterForm.sortType = '1'
        this.knowledgeDataInit()
      } else if (par.order === 'descending') {
        this.filterForm.sortField = par.prop
        this.filterForm.sortType = '0'
        this.knowledgeDataInit()
      } else {
        this.filterForm.sortField = ''
        this.filterForm.sortType = ''
        this.knowledgeDataInit()
      }
    },

    // 分页改变
    currentPageChange(currentPage) {
      this.filterForm.page = currentPage
      this.knowledgeDataInit()
    },

    // 表格数据格式化
    tableFormatter(row, column, cellValue, index) {
      let value = ''
      this[`${column.property}List`].forEach(item => {
        if (Number(cellValue) === Number(item.id)) {
          value = item.name
        }
      })
      return value
    },

    // 确认
    confirmLoreLibrary() {
      if (JSON.stringify(this.currentRow) === '{}') return this.$message.warning('请选择一条数据')
      this.$emit('loreLibraryMatch', true, this.currentRow)
    },

    // 单选改变事件
    currentTableChange(currentRow) {
      this.currentRow = Object.assign({}, currentRow)
    }
  }
}
</script>

<style scoped lang="less">
.topTitle {
  padding-bottom: 20px;
  margin-bottom: 30px;
  border-bottom: 1px solid #e5e5e6;
  .el-col:nth-child(1) {
    font-weight: 900;
    font-size: 20px;
    margin-bottom: 20px;
  }
}
</style>
