<template>
  <div>
    <My-tabs
      ref="myTabs"
      :tabTitle="'工单数据处理'"
      :editableTabs="disposeTabs"
      @filterEditableTabs="filterEditableTabs"
      :editableTabsFlag="'dispose'"
      :exportDomainFlag="true"
    >
      <template v-slot:collapseTab>
        <Work-form ref="workForm" />
      </template>
      <Work-other ref="workOther" />
      <el-row class="tableBtn">
        <el-button type="primary" round @click="showDeliver">转交</el-button>
        <el-button type="primary" round @click="showTrack">跟踪</el-button>
        <el-button type="primary" round @click="showKnowledge">生成知识</el-button>
        <el-button type="primary" round @click="showTagBox">添加标签</el-button>
        <el-button type="primary" round @click="showLocusCircle">轨迹图</el-button>
        <el-button type="primary" round @click="exportExcel">导出</el-button>
      </el-row>

      <template v-slot:customTab>
        <el-tab-pane
          v-for="item in disposeTabs"
          :key="item.name"
          :label="item.title"
          :name="item.name"
          closable
        >
          <div>
            <component
              :is="item.type"
              :flag="item.flag ? item.flag : ''"
              :rows="item.rows ? item.rows : {}"
              @closeTab="closeTab"
            ></component>
          </div>
        </el-tab-pane>
      </template>
    </My-tabs>

    <My-dialog :title="'转交工单'" :className="'publicNDialog'" ref="sendWorkDia" :width="'40%'">
      <Send-Work @closeDialog="closeDialog" :ticketIdArr="ticketIdArr" />
    </My-dialog>

    <My-dialog :title="'跟踪工单'" :className="'publicNDialog'" ref="trackWorkDia" :width="'40%'">
      <Track-Work @closeDialog="closeDialog" :ticketIdArr="ticketIdArr" />
    </My-dialog>

    <My-dialog :title="'添加标签'" :className="'publicNDialog'" ref="tagBoxDia" :width="'40%'">
      <Tag-box @closeDialog="closeDialog" :ticketIdArr="ticketIdArr" />
    </My-dialog>

    <My-dialog :title="'轨迹图'" :className="'publicFDialog'" ref="locusCircleDia">
      <Locus-circle :ticketId="ticketId" />
    </My-dialog>
  </div>
</template>

<script>
import WorkForm from '../workPublic/WorkForm'
import WorkOther from '../workPublic/WorkOther'
import CKnowledge from '../workPublic/CKnowledge'
import SendWork from './components/SendWork'
import TrackWork from './components/TrackWork'
import TagBox from './components/TagBox'
import LocusCircle from '../query/components/LocusCircle'
import { mapState, mapMutations } from 'vuex'
export default {
  name: 'Dispose',
  components: {
    WorkForm, // 公共部分
    WorkOther, // 公共部分
    CKnowledge, // 生成知识
    SendWork, // 转交
    TrackWork, // 跟踪
    TagBox, // 添加标签
    LocusCircle // 轨迹圈
  },
  data() {
    return {
      ticketIdArr: [], // 选中数据的ticketId数组
      rows: {},
      ticketId: ''
    }
  },
  provide: function() {
    return {
      rootapp: this
    }
  },
  mounted() {},
  computed: {
    ...mapState({
      disposeTabs: state => state.CKnowledge.disposeTabs
    })
  },
  methods: {
    // 生成知识标签  关闭标签
    ...mapMutations('CKnowledge', ['createKnowledgeTab', 'delKnowledgeTab']),

    // 轨迹图
    showLocusCircle() {
      const selectedRows = this.$refs.workOther.selectedRows
      if (selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      if (selectedRows.length > 1) return this.$message.warning('只能勾选一条数据')
      this.ticketId = selectedRows[0].ticketId
      this.$refs.locusCircleDia.dialogVisible = true
    },

    // 关闭dialog (根据情况选择是否重新查询表格数据)
    closeDialog(dia, close) {
      this.$refs[dia].dialogVisible = false
      if (close) return
      this.$refs.workOther.dataInit()
    },

    // show跟踪页面
    showTrack() {
      const selectedRows = this.$refs.workOther.selectedRows
      if (selectedRows.length === 0) return this.$message.warning('请选择一条数据')

      this.ticketIdArr = []
      selectedRows.forEach(item => {
        this.ticketIdArr.push(item.ticketId)
      })

      this.$refs.trackWorkDia.dialogVisible = true
    },

    // show转交页面
    showDeliver() {
      const selectedRows = this.$refs.workOther.selectedRows
      if (selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      this.ticketIdArr = []
      for (var i = 0; i < selectedRows.length; i++) {
        if (selectedRows[i].execStatus !== '0') {
          this.$message.warning('包含已处理或中止的工单，请重新选择！')
          return
        } else {
          this.ticketIdArr.push(selectedRows[i].ticketId)
        }
      }
      this.$refs.sendWorkDia.dialogVisible = true
    },

    // show生成知识
    showKnowledge() {
      const selectedRows = this.$refs.workOther.selectedRows
      if (selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      if (selectedRows.length > 1) return this.$message.warning('只能勾选一条数据')
      if (selectedRows[0].execStatus === '0' || selectedRows[0].execStatus === '2') {
        this.$message.warning('该工单暂未处理或已中止，请重新选择！')
        return
      }
      if (selectedRows[0].knowledgeId) {
        this.$confirm('该工单已生成过知识，确定重新生成吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          closeOnClickModal: false
        })
          .then(async () => {
            this.rows = Object.assign({}, selectedRows[0])
            this.createKnowledgeTab({
              flag: 'work',
              rows: this.rows
            })
          })
          .catch(() => {})
      } else {
        this.rows = Object.assign({}, selectedRows[0])
        this.createKnowledgeTab({
          flag: 'work',
          rows: this.rows
        })
      }
    },

    // 过滤关闭的tab
    filterEditableTabs(a, b) {
      const knowledgeTab = a.filter(tab => tab.name !== b)
      this.delKnowledgeTab(knowledgeTab)
    },

    // 导出
    exportExcel() {
      const obj = this.$refs.workForm.filterForm
      let pars = ''
      for (var k in obj) {
        const par = k + '=' + obj[k] + '&'
        pars = pars + par
      }
      pars = pars.substring(0, pars.length - 1)
      window.open('/oam/ticket/export/excel?' + pars, '_parent')
    },

    // show添加标签
    showTagBox() {
      const selectedRows = this.$refs.workOther.selectedRows
      if (selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      this.ticketIdArr = []
      selectedRows.forEach(item => {
        this.ticketIdArr.push(item.ticketId)
      })
      this.$refs.tagBoxDia.dialogVisible = true
    },

    // 关闭标签
    closeTab(num, v) {
      this.$refs.myTabs.removeWorkTab(num)
      if (v) return
      this.$refs.workOther.dataInit()
    }
  }
}
</script>

<style scoped lang="less"></style>
