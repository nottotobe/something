<template>
  <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
    <el-form-item label="角色" prop="roles">
      <el-select v-model="filterForm.roles" multiple placeholder="请选择" clearable>
        <el-option
          v-for="item in rolesList"
          :key="item.roleId"
          :label="item.name"
          :value="item.roleId"
        >
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="导入用户表单数据" prop="formData">
      <el-input v-model="filterForm.formData" placeholder="请输入内容" disabled>
        <el-upload
          slot="append"
          action="#"
          accept=".xls"
          :http-request="ExcelImport"
          :show-file-list="false"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
      </el-input>
    </el-form-item>

    <el-row>
      <el-button type="info" round plain @click="ExcelDown">下载Excel模块</el-button>
      <el-button
        type="info"
        round
        plain
        v-if="previewFlag"
        @click="$refs.previewImportDia.dialogVisible = true"
        >预览数据</el-button
      >
      <!-- <el-upload action="#" accept=".xls" :http-request="ExcelUp" :show-file-list="false">
        <el-button round plain>上传Excel模块</el-button>
      </el-upload> -->
    </el-row>

    <el-row class="formBtn">
      <el-button round @click="$emit('userDataReset', true, true, 'batchImportDia')"
        >取 消</el-button
      >
      <el-button type="primary" round @click="confirmImport">确 定</el-button>
    </el-row>

    <My-dialog
      :title="'导入数据预览'"
      :className="'publicNDialog'"
      :width="'70%'"
      ref="previewImportDia"
      appendBody
    >
      <Preview-import
        :importList="importList"
        @closeDia="$refs.previewImportDia.dialogVisible = false"
      />
    </My-dialog>
  </el-form>
</template>

<script>
import PreviewImport from './PreviewImport'
import { getAllRoleData, templateDownload, ExcelImport, batchNewUsers } from '@/api/user'
export default {
  name: 'BatchImport',
  components: {
    PreviewImport
  },
  data() {
    return {
      filterForm: {
        roles: [],
        formData: ''
      },
      rolesList: [],
      rulesForm: {
        roles: [{ required: true, message: '角色不能为空', trigger: 'change' }],
        formData: [{ required: true, message: '导入的数据不能为空', trigger: 'change' }]
      },
      importList: [],
      previewFlag: false
    }
  },
  mounted() {
    this.roleDataInit()
  },
  methods: {
    // 获取角色数据
    async roleDataInit() {
      const res = await getAllRoleData()
      if (res.data.status === 200) {
        this.rolesList = res.data.obj
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 下载模板
    async ExcelDown() {
      const res = await templateDownload()
      if (res.data.status === 200) {
        window.open(res.data.obj, '_parent')
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 上传模板
    // async ExcelUp(v) {
    //   const fd = new FormData()
    //   fd.append('name', v.file.name)
    //   fd.append('file', v.file)
    //   const res = await templateUpload(fd)
    //   if (res.data.status === 200) {
    //     this.$message.success(res.data.msg)
    //   } else {
    //     this.$message.error(res.data.msg)
    //   }
    // },

    // Excel导入
    async ExcelImport(v) {
      const fd = new FormData()
      fd.append('name', v.file.name)
      fd.append('file', v.file)
      const res = await ExcelImport(fd)
      if (res.data.status === 200) {
        this.filterForm.formData = v.file.name
        this.importList = res.data.obj
        this.previewFlag = true
      } else {
        this.$message.error(res.data.msg)
        this.filterForm.formData = ''
        this.importList = []
        this.previewFlag = false
      }
    },

    // 确认
    confirmImport() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        const newRoles = []
        const newImport = []
        this.filterForm.roles.forEach(item => {
          newRoles.push({
            roleId: item
          })
        })
        this.importList.forEach(item => {
          newImport.push({
            userId: item.userId,
            username: item.username,
            password: item.password,
            dptCode: item.dptCode,
            status: '1',
            roles: newRoles
          })
        })

        const res = await batchNewUsers(newImport)
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('userDataReset', true, false, 'batchImportDia')
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
