<template>
  <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
    <div v-if="flag !== 'approveMore'">
      <el-form-item label="用户ID" prop="userId">
        <el-input placeholder="请输入内容" v-model="filterForm.userId" :disabled="flag !== 'add'">
        </el-input>
      </el-form-item>

      <el-form-item label="用户名" prop="username">
        <el-input placeholder="请输入内容" v-model="filterForm.username" :disabled="flag !== 'add'">
        </el-input>
      </el-form-item>

      <el-form-item label="密码" prop="password" v-if="flag === 'add'">
        <el-input placeholder="请输入内容" v-model="filterForm.password" type="password">
        </el-input>
      </el-form-item>

      <el-form-item label="电话" prop="mobile" v-else>
        <el-input placeholder="请输入内容" v-model="filterForm.mobile" :disabled="flag !== 'add'">
        </el-input>
      </el-form-item>

      <el-form-item label="机构" prop="dptCode">
        <el-cascader
          v-model="filterForm.dptCode"
          :props="dptCodeProps"
          :options="dptCodeList"
          :show-all-levels="false"
          clearable
          ref="checkStrictlyRef"
          popper-class="checkStrictlyStyle ignore"
        ></el-cascader>
      </el-form-item>

      <el-form-item
        label="角色权限"
        :prop="flag === 'approveOne' && filterForm.examStatus === '1' ? 'roles' : ''"
      >
        <el-select v-model="filterForm.roles" multiple placeholder="请选择" clearable>
          <el-option
            v-for="item in rolesList"
            :key="item.roleId"
            :label="item.name"
            :value="item.roleId"
          >
          </el-option>
        </el-select>
      </el-form-item>
    </div>

    <el-form-item
      label="审批结果"
      prop="examStatus"
      v-if="flag === 'approveMore' || flag === 'approveOne'"
    >
      <el-select v-model="filterForm.examStatus" placeholder="请选择" clearable>
        <el-option
          v-for="item in examStatusList"
          :key="item.id"
          :label="item.name"
          :value="item.id"
        >
        </el-option>
      </el-select>
    </el-form-item>

    <el-row class="formBtn">
      <el-button round @click="$emit('userDataReset', true, true, 'addUserDia')">取 消</el-button>
      <el-button type="primary" round @click="confirmUser">确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { getAllRoleData, addUserData, editUserData, userApprove } from '@/api/user'
import { dptMix } from '@/mixins'
import { validPassword, validChinese } from '@/utils/validate'
export default {
  name: 'AddUser',
  props: {
    flag: {
      type: String,
      default: 'add'
    },
    rows: {
      type: [Object, Array],
      default: () => {}
    }
  },
  mixins: [dptMix],
  data() {
    return {
      filterForm: {
        userId: '', // 用户ID
        username: '', // 用户名
        password: '', // 密码
        mobile: '', // 手机号
        dptCode: '', // 机构代码
        roles: [],
        examStatus: ''
      },
      examStatusList: [
        { id: '1', name: '审批通过' },
        { id: '2', name: '退回' }
      ],
      rolesList: [],
      rulesForm: {
        userId: [
          { required: true, message: '用户ID不能为空', trigger: 'change' },
          { validator: validChinese, trigger: 'blur' }
        ],
        username: [{ required: true, message: '用户名不能为空', trigger: 'change' }],
        password: [
          { required: true, message: '密码不能为空', trigger: 'change' },
          { validator: validPassword, trigger: 'blur' }
        ],
        dptCode: [{ required: true, message: '机构不能为空', trigger: 'change' }],
        roles: [{ required: true, message: '角色权限不能为空', trigger: 'change' }],
        examStatus: [{ required: true, message: '审批结果不能为空', trigger: 'change' }]
      }
    }
  },
  mounted() {
    this.roleDataInit()
    this.addUserInit()
  },
  methods: {
    // 初始化
    addUserInit() {
      if (this.flag === 'edit') {
        this.filterForm = Object.assign({}, this.rows)
        const rolesArr = []
        this.filterForm.roles.forEach(item => {
          rolesArr.push(item.roleId)
        })
        this.filterForm.roles = rolesArr
      }

      if (this.flag === 'approveOne') {
        this.filterForm.userId = this.rows.userId
        this.filterForm.status = this.rows.status
        this.filterForm.username = this.rows.username
        this.filterForm.mobile = this.rows.mobile
        this.filterForm.dptCode = this.rows.dptCode
        this.filterForm.roles = this.rows.roles
        const rolesArr = []
        this.filterForm.roles.forEach(item => {
          rolesArr.push(item.roleId)
        })
        this.filterForm.roles = rolesArr
      }
    },

    // 获取角色数据
    async roleDataInit() {
      const res = await getAllRoleData()
      if (res.data.status === 200) {
        this.rolesList = res.data.obj
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 确认
    confirmUser() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        const roleArr = []
        this.filterForm.roles.forEach(item => {
          roleArr.push({ roleId: item })
        })
        let res
        if (this.flag === 'add') {
          res = await addUserData({
            userId: this.filterForm.userId,
            username: this.filterForm.username,
            password: this.filterForm.password,
            mobile: this.filterForm.mobile,
            email: '',
            avatar: '',
            dptCode: this.filterForm.dptCode,
            status: '1',
            examStatus: '0',
            roles: roleArr
          })
        } else if (this.flag === 'edit') {
          res = await editUserData({
            userId: this.filterForm.userId,
            dptCode: this.filterForm.dptCode,
            status: this.filterForm.status,
            roles: roleArr
          })
        } else if (this.flag === 'approveOne') {
          res = await userApprove([
            {
              userId: this.filterForm.userId,
              dptCode: this.filterForm.dptCode,
              status: this.filterForm.status,
              examStatus: this.filterForm.examStatus,
              roles: roleArr
            }
          ])
        } else {
          const newArr = []
          this.rows.forEach(item => {
            newArr.push({
              userId: item.userId,
              dptCode: item.dptCode,
              status: item.status,
              examStatus: this.filterForm.examStatus,
              roles: item.roles
            })
          })
          res = await userApprove(newArr)
        }

        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('userDataReset', true, false, 'addUserDia')
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
