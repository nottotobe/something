<template>
  <div>
    <My-tabs :tabTitle="'复制用户'">
      <template v-slot:collapseTab>
        <el-form :model="filterForm" ref="formRef">
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="用户名" prop="username">
                <el-input
                  v-model="filterForm.username"
                  placeholder="请输入内容"
                  clearable
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="机构" prop="dptCode">
                <el-cascader
                  v-model="filterForm.dptCode"
                  :props="dptCodeProps"
                  :options="dptCodeList"
                  :show-all-levels="false"
                  clearable
                  ref="checkStrictlyRef"
                  popper-class="checkStrictlyStyle ignore"
                ></el-cascader>
              </el-form-item>
            </el-col>
            <el-col class="formBtn">
              <el-button type="primary" round @click="userDataInit('query')">查询</el-button>
              <el-button round type="info" plain @click="resetForm('formRef')">重置</el-button>
            </el-col>
          </el-row>
        </el-form>
      </template>

      <el-table
        ref="tableRef"
        :data="tableData"
        stripe
        style="width:100%"
        class="publicTable"
        @row-click="rowClick"
        @selection-change="selectionChange"
        @sort-change="tableSortChange"
      >
        <el-table-column type="selection"> </el-table-column>
        <el-table-column
          label="用户ID"
          prop="userId"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="用户名"
          prop="username"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="机构"
          prop="dptName"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column label="角色" prop="role" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-button @click.native.stop="viewTag(scope.row.roles)" type="text">
              查看
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        layout="total, prev, pager, next, jumper"
        :total="filterForm.pagTotal"
        :page-size="filterForm.size"
        :current-page="filterForm.page"
        background
        @current-change="currentPageChange"
      >
      </el-pagination>
    </My-tabs>

    <My-dialog :title="'查看角色'" :className="'publicNDialog'" :width="'40%'" ref="viewDia">
      <My-view :viewList="viewList" @closeView="closeView" />
    </My-dialog>
  </div>
</template>

<script>
import MyView from '@/components/MyView'
import { getUserData } from '@/api/user'
import { tableMix, viewMix, dptMix } from '@/mixins'
export default {
  name: 'UserCopy',
  components: {
    MyView
  },
  mixins: [tableMix, viewMix, dptMix],
  data() {
    return {
      filterForm: {
        username: '',
        dptCode: '',
        status: '1',
        page: 1,
        size: 5,
        pagTotal: 0
      }
    }
  },
  mounted() {
    this.userDataInit()
  },
  methods: {
    // 获取用户数据
    async userDataInit(n) {
      if (n === 'query') {
        this.filterForm.page = 1
      }
      const res = await getUserData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.userList
        this.filterForm.pagTotal = res.data.obj.totle
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 分页改变
    currentPageChange(currentPage) {
      this.filterForm.page = currentPage
      this.userDataInit()
    },

    // 表格排序
    tableSortChange(par) {
      this.sortChange(par, this.userDataInit)
    }
  }
}
</script>

<style scoped lang="less"></style>
