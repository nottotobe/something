<template>
  <div>
    <el-table ref="tableRef" :data="importList" stripe style="width:100%" class="publicTable">
      <el-table-column label="用户ID" prop="userId" show-overflow-tooltip></el-table-column>
      <el-table-column label="用户名" prop="username" show-overflow-tooltip></el-table-column>
      <el-table-column label="密码" prop="password" show-overflow-tooltip></el-table-column>
      <el-table-column label="机构ID" prop="dptCode" show-overflow-tooltip></el-table-column>
    </el-table>

    <el-row class="tableBtn">
      <el-button round @click="$emit('closeDia')">返回</el-button>
    </el-row>
  </div>
</template>

<script>
export default {
  name: 'PreviewImport',
  props: {
    importList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
