<template>
  <div>
    <My-tabs :tabTitle="'用户数据'">
      <template v-slot:collapseTab>
        <el-form :model="filterForm" ref="formRef">
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="机构" prop="dptCode">
                <el-cascader
                  v-model="filterForm.dptCode"
                  :props="dptCodeProps"
                  :options="dptCodeList"
                  :show-all-levels="false"
                  clearable
                  ref="checkStrictlyRef"
                  popper-class="checkStrictlyStyle ignore"
                ></el-cascader>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="角色" prop="roleId">
                <el-select v-model="filterForm.roleId" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in roleIdList"
                    :key="item.roleId"
                    :label="item.name"
                    :value="item.roleId"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="用户名" prop="username">
                <el-input
                  v-model="filterForm.username"
                  placeholder="请输入内容"
                  clearable
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="账号状态" prop="status">
                <el-select v-model="filterForm.status" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in statusList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="审批状态" prop="examStatus">
                <el-select v-model="filterForm.examStatus" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in examStatusList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col class="formBtn">
              <el-button type="primary" round @click="userDataInit(false, false, 'query')"
                >查询</el-button
              >
              <el-button round type="info" plain @click="resetForm('formRef')">重置</el-button>
            </el-col>
          </el-row>
        </el-form>
      </template>

      <el-table
        ref="tableRef"
        :data="tableData"
        stripe
        style="width:100%"
        class="publicTable"
        @row-click="rowClick"
        @selection-change="selectionChange"
        @sort-change="tableSortChange"
      >
        <el-table-column type="selection"> </el-table-column>
        <el-table-column
          label="用户ID"
          prop="userId"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="用户名"
          prop="username"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column label="电话" prop="mobile" show-overflow-tooltip sortable="custom">
          <template slot-scope="scope">
            {{ scope.row.mobile ? scope.row.mobile : '-' }}
          </template>
        </el-table-column>
        <el-table-column
          label="机构"
          prop="dptName"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column label="角色" prop="roles" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-button @click.native.stop="viewTag(scope.row.roles)" type="text">
              查看
            </el-button>
          </template>
        </el-table-column>
        <el-table-column
          label="账号状态"
          prop="status"
          show-overflow-tooltip
          :formatter="tableFormatter"
          sortable="custom"
        >
        </el-table-column>
        <el-table-column
          label="审批"
          prop="examStatus"
          show-overflow-tooltip
          :formatter="tableFormatter"
          sortable="custom"
        ></el-table-column>
      </el-table>

      <el-pagination
        layout="total, prev, pager, next, jumper"
        :total="filterForm.pagTotal"
        :page-size="filterForm.size"
        :current-page="filterForm.page"
        background
        @current-change="currentChange"
      >
      </el-pagination>

      <el-row class="tableBtn">
        <el-button type="primary" round @click="addUser">新建用户</el-button>
        <el-button type="primary" round @click="editUser">修改用户</el-button>
        <el-button type="warning" round @click="approveUser">审批</el-button>
        <el-button type="primary" round @click="batchImport">批量导入</el-button>
        <el-button round type="primary" @click="resetUser">启用 / 停用</el-button>
      </el-row>
    </My-tabs>

    <My-dialog :title="'查看角色'" :className="'publicNDialog'" :width="'40%'" ref="viewDia">
      <My-view :viewList="viewList" @closeView="closeView" />
    </My-dialog>

    <My-dialog :title="titleDia" :className="'publicNDialog'" :width="'40%'" ref="addUserDia">
      <Add-user @userDataReset="userDataInit" :flag="flag" :rows="rows" />
    </My-dialog>

    <My-dialog
      :title="'导入用户数据'"
      :className="'publicNDialog'"
      :width="'40%'"
      ref="batchImportDia"
    >
      <Batch-import @userDataReset="userDataInit" />
    </My-dialog>
  </div>
</template>

<script>
import { getUserData, getAllRoleData, userReset } from '@/api/user'
import AddUser from './components/AddUser'
import BatchImport from './components/BatchImport'
import MyView from '@/components/MyView'
import { tableMix, addDiaMix, viewMix, dptMix } from '@/mixins'
import EventBus from '@/utils/eventBus'
export default {
  name: 'User',
  components: {
    MyView,
    AddUser,
    BatchImport
  },
  mixins: [tableMix, addDiaMix, viewMix, dptMix],
  data() {
    return {
      filterForm: {
        dptCode: '',
        roleId: '',
        username: '',
        examStatus: '',
        status: '',
        page: 1,
        size: 10,
        pagTotal: 0
      },
      roleIdList: [],
      statusList: [
        {
          id: '0',
          name: '停用'
        },
        {
          id: '1',
          name: '正常'
        }
      ],
      examStatusList: [
        {
          id: '0',
          name: '已申请'
        },
        {
          id: '1',
          name: '已审批'
        },
        {
          id: '2',
          name: '退回'
        }
      ]
    }
  },
  mounted() {
    this.userDataInit()
    this.roleDataInit()
    EventBus.$on('userEnter', (v, n) => {
      if (v === 'batchImport') {
        this.batchImport()
      } else if (v === 'addUser') {
        this.addUser()
      } else {
        this.filterForm[v] = '0'
        this.userDataInit()
      }
    })
  },
  destroyed() {
    EventBus.$off('userEnter')
  },
  methods: {
    // 新增
    addUser() {
      this.addPublic('addUserDia', '新建用户')
    },

    // 修改
    editUser() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      if (this.selectedRows.length > 1) return this.$message.warning('只能勾选一条数据')
      if (this.selectedRows[0].examStatus === '2') {
        this.$message.warning('不可以操作退回的数据')
        return
      }

      this.$refs.addUserDia.dialogVisible = true
      this.titleDia = '修改用户'
      this.flag = 'edit'
      this.rows = Object.assign({}, this.selectedRows[0])
    },

    // 获取用户数据
    async userDataInit(v, p, n) {
      if (v) {
        this.$refs[n].dialogVisible = false
      }
      if (p) return

      if (n === 'query') {
        this.filterForm.page = 1
      }

      const res = await getUserData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.userList
        this.filterForm.pagTotal = res.data.obj.totle
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 获取角色数据
    async roleDataInit() {
      const res = await getAllRoleData()
      if (res.data.status === 200) {
        this.roleIdList = res.data.obj
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 表格排序
    tableSortChange(par) {
      this.sortChange(par, this.userDataInit)
    },

    // 分页改变
    currentChange(currentPage) {
      this.filterForm.page = currentPage
      this.userDataInit()
    },

    // 表格数据格式化
    tableFormatter(row, column, cellValue, index) {
      let value = ''
      this[`${column.property}List`].forEach(item => {
        if (Number(cellValue) === Number(item.id)) {
          value = item.name
        }
      })
      return value
    },

    // 启用/停用
    async resetUser() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      const newArr = []
      const legArr = []
      for (var i = 0; i < this.selectedRows.length; i++) {
        if (this.selectedRows[i].examStatus === '2') {
          this.$message.warning('不可以操作退回的数据')
          return
        }
        if (this.selectedRows.length > 1) {
          legArr.push(this.selectedRows[0].status)
          if (legArr.indexOf(this.selectedRows[i].status) === -1) {
            this.$message.warning('请选择账号状态一致的数据')
            return
          }
        }
        let flag = ''
        if (this.selectedRows[0].status === '1') {
          flag = '0'
        } else {
          flag = '1'
        }
        newArr.push({
          userId: this.selectedRows[i].userId,
          status: flag
        })
      }

      const res = await userReset(newArr)
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.userDataInit()
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 审批
    approveUser() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      for (var i = 0; i < this.selectedRows.length; i++) {
        if (this.selectedRows[i].examStatus !== '0') {
          this.$message.warning('请选择审批状态为已申请的账号')
          return
        }
      }

      if (this.selectedRows.length > 1) {
        this.flag = 'approveMore'
        this.rows = this.selectedRows
        this.titleDia = '批量审批'
      } else {
        this.flag = 'approveOne'
        this.rows = Object.assign({}, this.selectedRows[0])
        this.titleDia = '审批用户'
      }
      this.$refs.addUserDia.dialogVisible = true
    },

    // 批量导入
    batchImport() {
      this.$refs.batchImportDia.dialogVisible = true
    }
  }
}
</script>

<style scoped lang="less"></style>
