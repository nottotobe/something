<template>
  <div>
    <My-tabs :tabTitle="'被复制用户'">
      <template v-slot:collapseTab>
        <el-form :model="filterForm" ref="formRef">
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="用户名" prop="username">
                <el-input
                  v-model="filterForm.username"
                  placeholder="请输入内容"
                  clearable
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="机构" prop="dptCode">
                <el-cascader
                  v-model="filterForm.dptCode"
                  :props="dptCodeProps"
                  :options="dptCodeList"
                  :show-all-levels="false"
                  clearable
                  ref="checkStrictlyRef"
                  popper-class="checkStrictlyStyle ignore"
                ></el-cascader>
              </el-form-item>
            </el-col>
            <el-col class="formBtn">
              <el-button type="primary" round @click="userDataInit('query')">查询</el-button>
              <el-button round type="info" plain @click="$refs.formRef.resetFields()"
                >重置</el-button
              >
            </el-col>
          </el-row>
        </el-form>

        <el-table
          ref="tableRef"
          :data="tableData"
          stripe
          style="width:100%"
          class="publicTable"
          highlight-current-row
          @current-change="currentTableChange"
          @sort-change="tableSortChange"
        >
          <el-table-column
            label="用户ID"
            prop="userId"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column
            label="用户名"
            prop="username"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column
            label="机构"
            prop="dptName"
            show-overflow-tooltip
            sortable="custom"
          ></el-table-column>
          <el-table-column label="角色" prop="role" show-overflow-tooltip>
            <template slot-scope="scope">
              <el-button @click.native.stop="viewTag(scope.row.roles)" type="text">
                查看
              </el-button>
            </template>
          </el-table-column>
        </el-table>

        <el-pagination
          layout="total, prev, pager, next, jumper"
          :total="filterForm.pagTotal"
          :page-size="filterForm.size"
          :current-page="filterForm.page"
          background
          @current-change="currentPageChange"
        >
        </el-pagination>
      </template>
    </My-tabs>

    <User-copy ref="userCopy" />

    <el-row class="tableBtn">
      <el-button type="primary" round @click="copyRights">权限复制</el-button>
    </el-row>

    <My-dialog :title="'查看角色'" :className="'publicNDialog'" :width="'40%'" ref="viewDia">
      <My-view :viewList="viewList" @closeView="closeView" />
    </My-dialog>
  </div>
</template>

<script>
import UserCopy from './components/UserCopy'
import MyView from '@/components/MyView'
import { getUserData, rightsCopy } from '@/api/user'
import { viewMix, dptMix } from '@/mixins'
export default {
  name: 'Rights',
  components: {
    UserCopy,
    MyView
  },
  mixins: [viewMix, dptMix],
  data() {
    return {
      filterForm: {
        username: '',
        dptCode: '',
        status: '1',
        examStatus: '1',
        page: 1,
        size: 5,
        pagTotal: 0
      },
      tableData: [],
      currentRow: {}
    }
  },
  mounted() {
    this.userDataInit()
  },
  methods: {
    // 获取用户数据
    async userDataInit(n) {
      if (n === 'query') {
        this.filterForm.page = 1
      }
      const res = await getUserData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.userList
        this.filterForm.pagTotal = res.data.obj.totle
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 单选改变事件 获取子类
    currentTableChange(currentRow) {
      this.currentRow = Object.assign({}, currentRow)
    },

    // 分页改变
    currentPageChange(currentPage) {
      this.filterForm.page = currentPage
      this.userDataInit()
    },

    // 表格排序
    tableSortChange(par) {
      if (par.order === 'ascending') {
        this.filterForm.sortField = par.prop
        this.filterForm.sortType = '1'
        this.userDataInit()
      } else if (par.order === 'descending') {
        this.filterForm.sortField = par.prop
        this.filterForm.sortType = '0'
        this.userDataInit()
      } else {
        this.filterForm.sortField = ''
        this.filterForm.sortType = ''
        this.userDataInit()
      }
    },

    // 复制
    async copyRights() {
      if (JSON.stringify(this.currentRow) === '{}') return this.$message.warning('请选择被复制用户')
      const selectedRows = this.$refs.userCopy.selectedRows
      if (selectedRows.length === 0) return this.$message.warning('请选择复制用户')
      const newArr = []
      selectedRows.forEach(item => {
        newArr.push({
          userId: item.userId,
          roles: this.currentRow.roles
        })
      })
      const res = await rightsCopy(newArr)
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.$refs.userCopy.userDataInit()
        this.userDataInit()
      } else {
        this.$message.error(res.data.msg)
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
