<template>
  <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
    <el-row :gutter="20">
      <el-col :span="12">
        <el-form-item label="机构ID" prop="dptId">
          <el-input
            v-model="filterForm.dptId"
            placeholder="请输入内容"
            clearable
            :disabled="flag === 'edit'"
          ></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="机构名称" prop="name">
          <el-input v-model="filterForm.name" placeholder="请输入内容" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="上级机构" prop="parentId">
          <el-cascader
            v-model="filterForm.parentId"
            :props="dptCodeProps"
            :options="dptCodeList"
            :show-all-levels="false"
            clearable
            ref="checkStrictlyRef"
            popper-class="checkStrictlyStyle ignore"
          ></el-cascader>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="机构电话" prop="telNo">
          <el-input v-model="filterForm.telNo" placeholder="请输入内容" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="机构手机" prop="mobile">
          <el-input v-model="filterForm.mobile" placeholder="请输入内容" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="机构邮箱" prop="email">
          <el-input v-model="filterForm.email" placeholder="请输入内容" clearable></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="机构地址" prop="address">
          <el-input v-model="filterForm.address" placeholder="请输入内容" clearable></el-input>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row class="formBtn">
      <el-button @click="$emit('dptDataReset', true, true, 'dptDetailsDia')" round>取 消</el-button>
      <el-button type="primary" @click="confirmDpt" round>确 定</el-button>
    </el-row>
  </el-form>
</template>

<script>
import { addDptData, editDptData } from '@/api/user'
import { dptMix } from '@/mixins'
export default {
  name: 'DptDetails',
  props: {
    flag: {
      type: String,
      default: 'add'
    },
    rows: {
      type: Object,
      default: () => {}
    }
  },
  mixins: [dptMix],
  data() {
    return {
      filterForm: {
        dptId: '',
        name: '',
        parentId: '',
        status: '1',
        address: '',
        telNo: '',
        mobile: '',
        email: ''
      },
      rulesForm: {
        dptId: [{ required: true, message: '机构ID不能为空', trigger: 'change' }],
        name: [{ required: true, message: '机构名称不能为空', trigger: 'change' }]
        // parentId: [{ required: true, message: '上级机构不能为空', trigger: 'change' }]
      }
    }
  },
  watch: {
    'filterForm.parentId'(newVlaue, oldValue) {
      if (this.$refs.checkStrictlyRef) {
        this.$refs.checkStrictlyRef.dropDownVisible = false
      }
    }
  },
  mounted() {
    if (this.flag === 'edit') {
      this.filterForm = Object.assign({}, this.rows)
    }
  },
  methods: {
    // 确认
    confirmDpt() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        let res
        if (this.flag === 'add') {
          res = await addDptData(this.filterForm)
        } else {
          res = await editDptData(this.filterForm)
        }
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('dptDataReset', true, false, 'dptDetailsDia')
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
