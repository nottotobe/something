<template>
  <div>
    <div class="dialog_box">
      <My-collapse :title="'角色详情'">
        <el-form :model="filterForm" ref="formRef">
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="角色名称" prop="name">
                <el-input v-model="filterForm.name" placeholder="请输入内容" clearable></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-row class="problemID">
          <span>角色权限</span>
        </el-row>

        <el-checkbox class="checkedAll" v-model="checkedAll" @change="checkedAllChange">
          全选
        </el-checkbox>

        <el-tree
          ref="treeRef"
          :data="treeData"
          :props="defaultProps"
          show-checkbox
          default-expand-all
          node-key="id"
          class="treeBox"
          @check="handleNodeCheck"
          :default-checked-keys="defaultCheckedKeys"
        >
        </el-tree>

        <el-row class="formBtn">
          <el-button @click="$emit('roleDataReset', true, true, 'roleDetailsDia')" round>
            取 消
          </el-button>
          <el-button type="primary" @click="confirmRole" round>确 定</el-button>
        </el-row>
      </My-collapse>
    </div>

    <el-backtop target=".el-dialog">
      <div class="publicBacktop ignore">UP</div>
    </el-backtop>
  </div>
</template>

<script>
import { getAllMenuList, addRoleData, editRoleData } from '@/api/user'
export default {
  name: 'RoleDetails',
  props: {
    flag: {
      type: String,
      default: 'add'
    },
    rows: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      defaultProps: {
        children: 'children',
        label: (data, node) => {
          if (data.explain === 'admin') {
            return data.name + ' - 管理员'
          } else if (data.explain === 'common') {
            return data.name + ' - 运维'
          } else {
            return data.name
          }
        }
      },
      treeData: [],
      filterForm: {
        name: ''
      },
      checkedKeys: [],
      defaultCheckedKeys: [],
      checkedAll: false,
      allLength: 0
    }
  },
  mounted() {
    this.allMenuListInit()
  },
  methods: {
    // 获取全部菜单
    async allMenuListInit() {
      const res = await getAllMenuList()
      this.treeData = res.data.obj

      this.editInit()
    },

    // 修改状态初始化
    editInit() {
      if (this.flag === 'edit') {
        this.filterForm.roleId = this.rows.roleId
        this.filterForm.name = this.rows.name
        this.filterForm.status = this.rows.status
        this.rows.menuList.forEach(item => {
          this.checkedKeys.push(item.id)
          if (item.parentId) {
            this.defaultCheckedKeys.push(item.id)
          }
        })
        for (var i = 0; i < this.treeData.length; i++) {
          this.allLength += 1
          if (this.treeData[i].children.length > 0) {
            for (var j = 0; j < this.treeData[i].children.length; j++) {
              this.allLength += 1
            }
          }
        }
        if (this.allLength === this.checkedKeys.length) {
          this.checkedAll = true
        }
      }
    },

    // 选中
    handleNodeCheck(v, p) {
      if (p.checkedKeys.length + p.halfCheckedKeys.length === this.allLength) {
        this.checkedAll = true
      } else {
        this.checkedAll = false
      }
      if (p.halfCheckedKeys.length > 0) {
        this.checkedKeys = p.checkedKeys.concat(p.halfCheckedKeys)
      } else {
        this.checkedKeys = p.checkedKeys
      }
    },

    // 确认
    async confirmRole() {
      const newArr = []
      this.checkedKeys.forEach(item => {
        newArr.push({
          menuId: item
        })
      })
      let res
      if (this.flag === 'add') {
        res = await addRoleData({
          name: this.filterForm.name,
          status: '1',
          roleMenuList: newArr
        })
      } else {
        res = await editRoleData({
          roleId: this.filterForm.roleId,
          name: this.filterForm.name,
          status: this.filterForm.status,
          roleMenuList: newArr
        })
      }
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.$emit('roleDataReset', true, false, 'roleDetailsDia')
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 全选/反选
    checkedAllChange() {
      if (this.checkedAll) {
        this.$refs.treeRef.setCheckedNodes(this.treeData)
        this.checkedKeys = this.$refs.treeRef.getCheckedKeys()
      } else {
        this.$refs.treeRef.setCheckedNodes([])
        this.checkedKeys = []
      }
    }
  }
}
</script>

<style scoped lang="less">
.treeBox {
  /deep/ .el-tree-node__content {
    margin-bottom: 20px;
  }
}

.checkedAll {
  margin-bottom: 20px;
}
</style>
