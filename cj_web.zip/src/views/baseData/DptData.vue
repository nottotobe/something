<template>
  <div>
    <My-tabs :tabTitle="'机构数据'">
      <template v-slot:collapseTab>
        <el-table
          ref="tableRef"
          :data="tableData"
          stripe
          style="width:100%"
          class="publicTable"
          @row-click="rowClick"
          @selection-change="selectionChange"
          row-key="dptId"
          default-expand-all
        >
          >
          <el-table-column type="selection"> </el-table-column>
          <el-table-column label="机构ID" prop="dptId" show-overflow-tooltip> </el-table-column>
          <el-table-column label="机构名称" prop="name" show-overflow-tooltip></el-table-column>
          <el-table-column label="机构层级" prop="level" show-overflow-tooltip></el-table-column>
          <el-table-column label="上级机构" prop="parentId" show-overflow-tooltip></el-table-column>
          <el-table-column label="机构电话" prop="telNo" show-overflow-tooltip></el-table-column>
          <el-table-column
            label="机构手机号码"
            prop="mobile"
            show-overflow-tooltip
          ></el-table-column>
          <el-table-column label="机构邮箱" prop="email" show-overflow-tooltip></el-table-column>
          <el-table-column label="联系地址" prop="address" show-overflow-tooltip></el-table-column>
          <el-table-column label="启用" prop="status" show-overflow-tooltip>
            <template slot-scope="scope">
              <el-switch
                v-model="scope.row.status"
                @click.native.stop
                @change="stateChange(scope.row.dptId, scope.row.status)"
                inactive-value="0"
                active-value="1"
              ></el-switch>
            </template>
          </el-table-column>
        </el-table>

        <el-row class="tableBtn">
          <el-button type="primary" round @click="addDpt">新建</el-button>
          <el-button type="primary" round @click="editDpt">修改</el-button>
          <el-button round type="danger" plain @click="delDpt">删除 </el-button>
        </el-row>
      </template>
    </My-tabs>

    <My-dialog :title="titleDia" :className="'publicNDialog'" :width="'70%'" ref="dptDetailsDia">
      <Dpt-details :flag="flag" :rows="rows" @dptDataReset="dptDataInit" />
    </My-dialog>
  </div>
</template>

<script>
import DptDetails from './components/DptDetails'
import { getDptData, dptReset, delDptData } from '@/api/user'
import { tableMix, addDiaMix } from '@/mixins'
export default {
  name: 'DptData',
  components: {
    DptDetails
  },
  mixins: [tableMix, addDiaMix],
  data() {
    return {}
  },
  mounted() {
    this.dptDataInit()
  },
  methods: {
    // 初始化
    async dptDataInit(v, p, n) {
      if (!this.closePublic(v, p, n)) return

      const res = await getDptData()
      if (res.data.status === 200) {
        this.tableData = res.data.obj
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // switch发生改变时候的回调
    async stateChange(dptId, status) {
      const res = await dptReset({
        dptId,
        status
      })
      if (res.data.status !== 200) {
        this.$message.error(res.data.msg)
        return
      }
      this.dptDataInit()
    },

    // 新增
    addDpt() {
      this.addPublic('dptDetailsDia', '新增机构')
    },

    // 修改
    editDpt() {
      this.editPublic('dptDetailsDia', '修改机构')
    },

    // 删除
    delDpt() {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      const newArr = []
      this.selectedRows.forEach(item => {
        newArr.push({
          dptId: item.dptId
        })
      })
      this.$confirm('确定删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        closeOnClickModal: false
      })
        .then(async () => {
          const res = await delDptData(newArr)
          if (res.data.status === 200) {
            this.$message.success(res.data.msg)
            this.dptDataInit()
          } else {
            this.$message.error(res.data.msg)
          }
        })
        .catch(() => {})
    }
  }
}
</script>

<style scoped lang="less"></style>
