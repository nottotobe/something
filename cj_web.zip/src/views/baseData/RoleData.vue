<template>
  <div>
    <My-tabs :tabTitle="'角色数据'">
      <template v-slot:collapseTab>
        <el-form :model="filterForm" ref="formRef">
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="角色名称" prop="name">
                <el-input v-model="filterForm.name" placeholder="请输入内容" clearable></el-input>
              </el-form-item>
            </el-col>
            <el-col class="formBtn">
              <el-button type="primary" round @click="roleDataInit(false, false, 'query')"
                >查询</el-button
              >
              <el-button round type="info" plain @click="resetForm('formRef')">重置</el-button>
            </el-col>
          </el-row>
        </el-form>
      </template>

      <el-table
        ref="tableRef"
        :data="tableData"
        stripe
        style="width:100%"
        class="publicTable"
        @row-click="rowClick"
        @selection-change="selectionChange"
        @sort-change="tableSortChange"
      >
        <el-table-column type="selection"> </el-table-column>
        <el-table-column label="角色ID" prop="roleId" show-overflow-tooltip sortable="custom">
        </el-table-column>
        <el-table-column
          label="角色"
          prop="name"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="提交人"
          prop="createdByUserName"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="提交机构"
          prop="createdDptName"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column
          label="提交时间"
          prop="createdTime"
          show-overflow-tooltip
          sortable="custom"
        ></el-table-column>
        <el-table-column label="启用" prop="status" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-switch
              v-model="scope.row.status"
              @click.native.stop
              inactive-value="0"
              active-value="1"
              @change="stateChange(scope.row.roleId, scope.row.status)"
            ></el-switch>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        layout="total, prev, pager, next, jumper"
        :total="filterForm.pagTotal"
        :page-size="filterForm.size"
        :current-page="filterForm.page"
        background
        @current-change="currentChange"
      >
      </el-pagination>

      <el-row class="tableBtn">
        <el-button type="primary" round @click="addRole">新建</el-button>
        <el-button type="primary" round @click="editRole">修改</el-button>
      </el-row>
    </My-tabs>

    <My-dialog :title="titleDia" :className="'publicFDialog'" ref="roleDetailsDia">
      <Role-details :flag="flag" :rows="rows" @roleDataReset="roleDataInit" />
    </My-dialog>
  </div>
</template>

<script>
import RoleDetails from './components/RoleDetails'
import { getRoleData, roleReset } from '@/api/user'
import { tableMix, addDiaMix } from '@/mixins'
export default {
  name: 'RoleData',
  components: {
    RoleDetails
  },
  mixins: [tableMix, addDiaMix],
  data() {
    return {
      filterForm: {
        name: '',
        page: 1,
        size: 10,
        pagTotal: 0
      }
    }
  },
  mounted() {
    this.roleDataInit()
  },
  methods: {
    // 初始化
    async roleDataInit(v, p, n) {
      if (!this.closePublic(v, p, n)) return
      if (n === 'query') {
        this.filterForm.page = 1
      }
      const res = await getRoleData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.roleList
        this.filterForm.pagTotal = res.data.obj.totle
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 表格排序
    tableSortChange(par) {
      this.sortChange(par, this.roleDataInit)
    },

    // 分页改变
    currentChange(currentPage) {
      this.filterForm.page = currentPage
      this.roleDataInit()
    },

    // 新增
    addRole() {
      this.addPublic('roleDetailsDia', '新增角色')
    },

    // 修改
    editRole() {
      this.editPublic('roleDetailsDia', '修改角色')
    },

    // switch发生改变时候的回调
    async stateChange(roleId, status) {
      const res = await roleReset({
        roleId,
        status
      })
      if (res.data.status !== 200) {
        this.$message.error(res.data.msg)
        return
      }
      this.roleDataInit()
    }
  }
}
</script>

<style scoped lang="less"></style>
