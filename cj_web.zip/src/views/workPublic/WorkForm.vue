<template>
  <el-form :model="filterForm" ref="formRef">
    <el-row :gutter="20">
      <el-col :span="6" v-if="!filterForm.createdBy && $route.query.isAdmin !== 'issue'">
        <el-form-item label="提交人" prop="createdByUserName">
          <el-input
            v-model="filterForm.createdByUserName"
            placeholder="请输入内容"
            clearable
          ></el-input>
        </el-form-item>
      </el-col>

      <el-col :span="6" v-if="!filterForm.createdBy && $route.query.isAdmin !== 'issue'">
        <el-form-item label="提交机构" prop="createdDpt">
          <el-cascader
            v-model="filterForm.createdDpt"
            :props="dptCodeProps"
            :options="dptCodeList"
            :show-all-levels="false"
            clearable
            ref="checkStrictlyRef"
            popper-class="checkStrictlyStyle ignore"
          ></el-cascader>
        </el-form-item>
      </el-col>

      <el-col :span="6">
        <el-form-item label="问题平台" prop="platform">
          <el-select v-model="filterForm.platform" placeholder="请选择" clearable>
            <el-option
              v-for="item in newPlatformList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>

      <el-col :span="6">
        <el-form-item label="问题类型" prop="type">
          <el-select v-model="filterForm.type" placeholder="请选择" clearable>
            <el-option
              v-for="item in newTypeList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>

      <el-col :span="6">
        <el-form-item label="紧急程度" prop="urgent">
          <el-select v-model="filterForm.urgent" placeholder="请选择" clearable>
            <el-option
              v-for="item in newUrgentList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>

      <el-col :span="6" v-if="!filterForm.updatedBy && $route.query.isAdmin !== 'issue'">
        <el-form-item label="经办人" prop="updatedByUserName">
          <el-input
            v-model="filterForm.updatedByUserName"
            placeholder="请输入内容"
            clearable
          ></el-input>
        </el-form-item>
      </el-col>

      <el-col :span="6">
        <el-form-item label="处理进度" prop="execStatus">
          <el-select v-model="filterForm.execStatus" placeholder="请选择" clearable>
            <el-option
              v-for="item in execStatusList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>

      <el-col :span="6">
        <el-form-item label="标题关键字" prop="title">
          <el-input v-model="filterForm.title" placeholder="请输入内容" clearable></el-input>
        </el-form-item>
      </el-col>

      <el-col :span="6" v-if="$route.query.isAdmin !== 'issue'">
        <el-form-item label="提交日期" prop="dateRange">
          <el-date-picker
            v-model="filterForm.dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            unlink-panels
            value-format="yyyy-MM-dd HH:mm:ss"
            :default-time="['00:00:00', '23:59:59']"
          >
            >
          </el-date-picker>
        </el-form-item>
      </el-col>

      <el-col :span="6" v-if="$route.path === '/ticketDataExcute'">
        <el-form-item label="是否超时" prop="isOverTime">
          <el-select v-model="filterForm.isOverTime" placeholder="请选择" clearable>
            <el-option
              v-for="item in isOverTimeList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
      </el-col>

      <el-col class="formBtn">
        <el-button type="primary" round @click="queryData">查询</el-button>
        <el-button round type="info" plain @click="resetForm">重置</el-button>
      </el-col>
    </el-row>
  </el-form>
</template>

<script>
import { selectMix, dptMix } from '@/mixins'
import { getLocal } from '@/utils/storage'
import EventBus from '@/utils/eventBus'
export default {
  name: 'WorkForm',
  mixins: [selectMix, dptMix],
  data() {
    return {
      value1: '',
      // 表单数据
      filterForm: {
        createdByUserName: '',
        createdDpt: '',
        platform: '',
        type: '',
        urgent: '',
        updatedByUserName: '',
        execStatus: '',
        title: '',
        startTime: '',
        endTime: '',
        dateRange: [],
        isOverTime: '',
        page: 1,
        size: 10,
        pagTotal: 0
      },
      // 下拉框数据
      execStatusList: [
        {
          id: '0',
          name: '处理中'
        },
        {
          id: '1',
          name: '已处理'
        },
        {
          id: '3',
          name: '已完成'
        },
        {
          id: '2',
          name: '中止'
        }
      ],
      isOverTimeList: [
        {
          id: '1',
          name: '是'
        },
        {
          id: '0',
          name: '否'
        }
      ]
    }
  },
  watch: {
    'filterForm.dateRange'(value) {
      if (value) {
        this.filterForm.startTime = value[0]
        this.filterForm.endTime = value[1]
      } else {
        this.filterForm.startTime = ''
        this.filterForm.endTime = ''
      }
    },
    'filterForm.createdDpt'(newVlaue, oldValue) {
      if (this.$refs.checkStrictlyRef) {
        this.$refs.checkStrictlyRef.dropDownVisible = false
      }
    }
  },
  created() {
    if (this.$route.query.isAdmin !== 'admin') {
      if (this.$route.path === '/ticketDataQuery') {
        this.filterForm.createdBy = getLocal('isUser').userId
      } else if (this.$route.path === '/ticketDataExcute') {
        this.filterForm.updatedBy = getLocal('isUser').userId
      }
    }
  },
  inject: {
    rootapp: {
      default: null
    }
  },
  activated() {
    this.getPTUData()
    this.dashboardEnter()
    this.satisticsEnter()
  },
  deactivated() {
    EventBus.$off('dashboardEnter')
    EventBus.$off('satisticsEnter')
  },
  methods: {
    // 查询
    queryData() {
      this.rootapp.$refs.workOther.dataInit('query')
    },

    // 重置
    resetForm() {
      this.$refs.formRef.resetFields()
    },

    // 从工作台进入
    dashboardEnter() {
      EventBus.$on('dashboardEnter', (v, n) => {
        for (var k in this.filterForm) {
          if (k !== 'size' && k !== 'pagTotal') {
            this.filterForm[k] = ''
          }
        }
        if (v === 'isOverTime') {
          this.filterForm.isOverTime = '1'
          this.filterForm.execStatus = '0'
        } else {
          this.filterForm[v] = n
        }

        this.queryData()
      })
    },

    // 从统计表进入
    satisticsEnter() {
      EventBus.$on('satisticsEnter', (v, n, t) => {
        for (var k in this.filterForm) {
          if (k !== 'size' && k !== 'pagTotal') {
            this.filterForm[k] = ''
          }
        }
        if (n === '数量') {
          this.deepTime(v)
          this.queryData()
          return
        }

        this.filterForm.dateRange = t
        this.filterForm.startTime = t[0]
        this.filterForm.endTime = t[1]
        if (n === '平台') {
          const arr = this.platformList.filter(item => {
            return item.name === v
          })
          this.filterForm.platform = arr[0].id
        }
        if (n === '类型') {
          const arr = this.typeList.filter(item => {
            return item.name === v
          })
          this.filterForm.type = arr[0].id
        }
        if (n === '处理中' || n === '超时') {
          this.filterForm.updatedByUserName = v
        }
        if (n === '机构') {
          this.filterForm.createdDpt = this.deepDpt(this.dptCodeList, v)
        }
        this.queryData()
      })
    },

    // 处理机构
    deepDpt(data, v) {
      let str = ''
      for (var i = 0; i < data.length; i++) {
        if (data[i].name === v) {
          str = data[i].dptId
          break
        } else {
          if (Array.isArray(data[i].children)) {
            str = this.deepDpt(data[i].children, v)
          }
        }
      }
      return str
    },

    // 处理时间
    deepTime(v) {
      let start
      let end
      if (v.length === 8) {
        const a = v.slice(0, 4) + '-' + v.slice(4, 6) + '-' + v.slice(6)
        start = a + ' 00:00:00'
        end = a + ' 23:59:59'
      } else {
        const year = v.slice(0, 4)
        const month = v.slice(4, 6)
        const date = new Date(year, month, 0).getDate()
        start = year + '-' + month + '-01 00:00:00'
        end = year + '-' + month + '-' + date + ' 23:59:59'
      }
      this.filterForm.dateRange = []
      this.filterForm.dateRange.push(start)
      this.filterForm.dateRange.push(end)
      this.filterForm.startTime = start
      this.filterForm.endTime = end
    }
  }
}
</script>

<style scoped lang="less"></style>
