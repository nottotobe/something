<template>
  <My-collapse :title="'历史回复'" :unfold="unfoldFlag">
    <div v-if="newReplyList.length === 0">
      <el-empty :image-size="100"></el-empty>
    </div>
    <div v-else>
      <div v-for="(item, index) in newReplyList" :key="index">
        <el-row :gutter="24">
          <el-col :span="18">
            <el-descriptions border>
              <el-descriptions-item label="问题回复" :span="3">{{
                item.explain
              }}</el-descriptions-item>
              <el-descriptions-item label="图片/视频" :span="3" v-if="picList(item).length !== 0">
                <MyUpload ref="myUpload" :uploadList="picList(item)" :unloadDis="true" />
              </el-descriptions-item>
              <el-descriptions-item label="其他附件" :span="3" v-if="otherList(item).length !== 0">
                <ATT-upload ref="attUpload" :uploadList="otherList(item)" :unloadDis="true" />
              </el-descriptions-item>
            </el-descriptions>
          </el-col>
          <el-col :span="6">
            <el-descriptions border :column="1">
              <el-descriptions-item label="经办人">{{
                item.updatedByUserName
              }}</el-descriptions-item>
              <el-descriptions-item label="经办机构">{{
                item.updatedByDptName
              }}</el-descriptions-item>
              <el-descriptions-item label="经办时间">{{ item.updatedTime }}</el-descriptions-item>
            </el-descriptions>
          </el-col>
        </el-row>
        <el-divider></el-divider>
      </div>
    </div>
  </My-collapse>
</template>

<script>
import MyUpload from '@/components/MyUpload'
import ATTUpload from '@/components/ATTUpload'
export default {
  name: 'ReplyList',
  components: {
    MyUpload,
    ATTUpload
  },
  data() {
    return {
      replyList: []
    }
  },
  computed: {
    unfoldFlag() {
      if (this.replyList.length === 0) {
        return ['2']
      } else {
        return ['1']
      }
    },
    picList() {
      return function(v) {
        return v.imageDataList.filter(item => {
          return (
            item.imageType === '.jpg' ||
            item.imageType === '.mp4' ||
            item.imageType === '.png' ||
            item.imageType === '.jpeg'
          )
        })
      }
    },
    otherList() {
      return function(v) {
        const arr = []
        v.imageDataList.forEach(item => {
          if (
            item.imageType !== '.jpg' &&
            item.imageType !== '.mp4' &&
            item.imageType !== '.png' &&
            item.imageType !== '.jpeg'
          ) {
            arr.push({ name: item.imageName, url: item.imageUri })
          }
        })
        return arr
      }
    },
    newReplyList() {
      return this.replyList.filter(item => {
        return item.type === 'reply'
      })
    }
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang=""></style>
