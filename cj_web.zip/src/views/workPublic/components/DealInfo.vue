<template>
  <My-collapse :title="'工单办理信息'" :unfold="['2']">
    <el-table :data="tableData" stripe style="width:100%" class="publicTable">
      <el-table-column
        label="操作名称"
        prop="type"
        show-overflow-tooltip
        :formatter="tableFormatter"
      ></el-table-column>
      <el-table-column
        label="操作人"
        prop="createdByUserName"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column
        label="操作机构"
        prop="createdByDptName"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column label="开始时间" prop="createdTime" show-overflow-tooltip></el-table-column>
      <el-table-column label="结束时间" prop="updatedTime" show-overflow-tooltip></el-table-column>
      <el-table-column label="备注信息" prop="explain" show-overflow-tooltip></el-table-column>
    </el-table>
  </My-collapse>
</template>

<script>
export default {
  name: 'DealInfo',
  data() {
    return {
      tableData: []
    }
  },
  mounted() {},
  methods: {
    // 表格数据格式化
    tableFormatter(row, column, cellValue, index) {
      if (cellValue === 'submit') {
        return '提交'
      }
      if (cellValue === 'transfer') {
        return '转发'
      }
      if (cellValue === 'retrieve') {
        return '取回'
      }
      if (cellValue === 'reply') {
        return '回复'
      }
      if (cellValue === 'resubmit') {
        return '反馈'
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
