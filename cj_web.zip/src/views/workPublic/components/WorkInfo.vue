<template>
  <My-collapse :title="'工单信息'">
    <el-row :gutter="24">
      <el-col :span="18">
        <el-descriptions border>
          <el-descriptions-item label="问题ID" :span="3">{{
            filterForm.ticketId
          }}</el-descriptions-item>
          <el-descriptions-item label="问题平台">{{
            filterForm.platformName
          }}</el-descriptions-item>
          <el-descriptions-item label="问题类型">{{ filterForm.typeName }}</el-descriptions-item>
          <el-descriptions-item label="紧急程度">{{ filterForm.urgentName }}</el-descriptions-item>
          <el-descriptions-item label="关联单号" :span="3" v-if="filterForm.policyNo">{{
            filterForm.policyNo
          }}</el-descriptions-item>
          <el-descriptions-item label="问题标签" :span="3" v-if="filterForm.labelList.length > 0">
            <el-tag
              v-for="(item, index) in filterForm.labelList"
              :key="index"
              style="margin-right:10px"
              >{{ item.name }}</el-tag
            >
          </el-descriptions-item>
          <el-descriptions-item label="问题标题" :span="3">{{
            filterForm.title
          }}</el-descriptions-item>
          <el-descriptions-item label="问题描述" :span="3">{{
            filterForm.explain
          }}</el-descriptions-item>
          <el-descriptions-item label="图片/视频" :span="3" v-if="picList.length !== 0">
            <MyUpload ref="myUpload" :uploadList="picList" :unloadDis="true" />
          </el-descriptions-item>
          <el-descriptions-item label="其他附件" :span="3" v-if="otherList.length !== 0">
            <ATT-upload ref="attUpload" :uploadList="otherList" :unloadDis="true" />
          </el-descriptions-item>
        </el-descriptions>
      </el-col>
      <el-col :span="6">
        <el-descriptions border :column="1">
          <el-descriptions-item label="上报机构" v-if="filterForm.sourceDptName">{{
            filterForm.sourceDptName
          }}</el-descriptions-item>
          <el-descriptions-item label="上报人" v-if="filterForm.source">{{
            filterForm.source
          }}</el-descriptions-item>
          <el-descriptions-item label="提交机构">{{
            filterForm.createdByDptName
          }}</el-descriptions-item>
          <el-descriptions-item label="提交人">{{
            filterForm.createdByUserName
          }}</el-descriptions-item>
          <el-descriptions-item label="提交时间">{{ filterForm.createdTime }}</el-descriptions-item>
          <el-descriptions-item label="期望处理时间" :span="3" v-if="filterForm.urgent === '14'">{{
            filterForm.expectTime
          }}</el-descriptions-item>
          <el-descriptions-item label="经办人">{{
            filterForm.updatedByUserName
          }}</el-descriptions-item>
          <el-descriptions-item
            label="状态"
            :contentClassName="'execStatus' + filterForm.execStatus"
            >{{ execStatusDes }}</el-descriptions-item
          >
          <el-descriptions-item
            label="超时时间"
            :contentStyle="{ color: '#f30000' }"
            v-if="filterForm.overTime"
            >{{ filterForm.overTime }}</el-descriptions-item
          >
        </el-descriptions>
      </el-col>
    </el-row>

    <div v-for="(item, index) in newFeedbackList" :key="index">
      <el-divider></el-divider>
      <el-row :gutter="24">
        <el-col :span="18">
          <el-descriptions border :column="4">
            <el-descriptions-item label="紧急程度" :span="item.urgent === '14' ? 2 : 4">{{
              newUrgent(item)
            }}</el-descriptions-item>
            <el-descriptions-item label="期望处理时间" v-if="item.urgent === '14'" :span="2">{{
              item.expectTime
            }}</el-descriptions-item>
            <el-descriptions-item label="再次反馈" :span="4">{{
              item.explain
            }}</el-descriptions-item>
            <el-descriptions-item label="图片/视频" :span="4" v-if="newPicList(item).length !== 0">
              <MyUpload ref="myUpload" :uploadList="newPicList(item)" :unloadDis="true" />
            </el-descriptions-item>
            <el-descriptions-item label="其他附件" :span="4" v-if="newOtherList(item).length !== 0">
              <ATT-upload ref="attUpload" :uploadList="newOtherList(item)" :unloadDis="true" />
            </el-descriptions-item>
          </el-descriptions>
        </el-col>
        <el-col :span="6">
          <el-descriptions border :column="1">
            <el-descriptions-item label="提交人">{{ item.createdByUserName }}</el-descriptions-item>
            <el-descriptions-item label="提交机构">{{
              item.createdByDptName
            }}</el-descriptions-item>
            <el-descriptions-item label="提交时间">{{ item.createdTime }}</el-descriptions-item>
          </el-descriptions>
        </el-col>
      </el-row>
    </div>
  </My-collapse>
</template>

<script>
import MyUpload from '@/components/MyUpload'
import ATTUpload from '@/components/ATTUpload'
export default {
  name: 'WorkInfo',
  components: {
    MyUpload,
    ATTUpload
  },
  data() {
    return {
      filterForm: {
        imageDataList: [],
        labelList: []
      },
      execStatusList: [
        {
          id: '2',
          name: '中止'
        },
        {
          id: '1',
          name: '已处理'
        },
        {
          id: '0',
          name: '处理中'
        },
        {
          id: '3',
          name: '已完成'
        }
      ],
      feedbackList: [],
      urgentList: []
    }
  },
  computed: {
    picList() {
      return this.filterForm.imageDataList.filter(item => {
        return (
          item.imageType === '.jpg' ||
          item.imageType === '.mp4' ||
          item.imageType === '.png' ||
          item.imageType === '.jpeg'
        )
      })
    },
    otherList() {
      const arr = []
      this.filterForm.imageDataList.forEach(item => {
        if (
          item.imageType !== '.jpg' &&
          item.imageType !== '.mp4' &&
          item.imageType !== '.png' &&
          item.imageType !== '.jpeg'
        ) {
          arr.push({ name: item.imageName, url: item.imageUri })
        }
      })
      return arr
    },
    newPicList() {
      return function(v) {
        return v.imageDataList.filter(item => {
          return (
            item.imageType === '.jpg' ||
            item.imageType === '.mp4' ||
            item.imageType === '.png' ||
            item.imageType === '.jpeg'
          )
        })
      }
    },
    newOtherList() {
      return function(v) {
        const arr = []
        v.imageDataList.forEach(item => {
          if (
            item.imageType !== '.jpg' &&
            item.imageType !== '.mp4' &&
            item.imageType !== '.png' &&
            item.imageType !== '.jpeg'
          ) {
            arr.push({ name: item.imageName, url: item.imageUri })
          }
        })
        return arr
      }
    },
    execStatusDes() {
      const arr = this.execStatusList.filter(item => {
        return item.id === this.filterForm.execStatus
      })
      if (arr.length > 0) {
        return arr[0].name
      } else {
        return ''
      }
    },
    newUrgent() {
      return function(v) {
        const arr = this.urgentList.filter(item => {
          return item.id === v.urgent
        })
        if (arr.length > 0) {
          return arr[0].name
        }
      }
    },
    newFeedbackList() {
      return this.feedbackList.filter(item => {
        return item.type === 'resubmit'
      })
    }
  },
  mounted() {},
  updated() {},
  methods: {}
}
</script>

<style scoped lang="less">
/deep/ .execStatus0 {
  color: #5980ff !important;
}

/deep/ .execStatus1 {
  color: #00d5be !important;
}

/deep/ .execStatus2 {
  color: #ffb400 !important;
}

/deep/ .execStatus3 {
  color: #59eb1f !important;
}
</style>
