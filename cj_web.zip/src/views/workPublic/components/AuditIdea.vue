<template>
  <My-collapse :title="'审核意见'">
    <el-form :model="filterForm" ref="formRef">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-form-item label="审核时间" prop="updatedTime">
            <el-input v-model="filterForm.updatedTime" placeholder="请输入内容" disabled></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="审核意见" prop="examExplain">
            <el-input
              type="textarea"
              :autosize="{ minRows: 4, maxRows: 4 }"
              placeholder="请输入内容"
              v-model="filterForm.examExplain"
              disabled
            >
            </el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </My-collapse>
</template>

<script>
export default {
  name: 'AuditIdea',
  props: {
    auditObj: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      filterForm: {
        updatedTime: '',
        examExplain: ''
      }
    }
  },
  mounted() {
    this.filterForm = Object.assign({}, this.auditObj)
  },
  methods: {}
}
</script>

<style scoped lang="less"></style>
