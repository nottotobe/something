<template>
  <div>
    <el-form :model="filterForm" ref="formRef" class="specialTabForm">
      <el-row :gutter="20">
        <el-col :span="6" v-if="!filterForm.createdBy">
          <el-form-item label="提交人" prop="createdByUserName">
            <el-input
              v-model="filterForm.createdByUserName"
              placeholder="请输入内容"
              clearable
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="问题平台" prop="platform">
            <el-select v-model="filterForm.platform" placeholder="请选择" clearable>
              <el-option
                v-for="item in newPlatformList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="问题类型" prop="type">
            <el-select v-model="filterForm.type" placeholder="请选择" clearable>
              <el-option
                v-for="item in newTypeList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="紧急程度" prop="urgent">
            <el-select v-model="filterForm.urgent" placeholder="请选择" clearable>
              <el-option
                v-for="item in newUrgentList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6" v-if="!filterForm.updatedBy">
          <el-form-item label="经办人" prop="updatedByUserName">
            <el-input
              v-model="filterForm.updatedByUserName"
              placeholder="请输入内容"
              clearable
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="处理进度" prop="execStatus">
            <el-select v-model="filterForm.execStatus" placeholder="请选择" clearable>
              <el-option
                v-for="item in execStatusList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="开始时间" prop="startTime">
            <el-date-picker
              v-model="filterForm.startTime"
              type="datetime"
              placeholder="请选择时间"
              value-format="yyyy-MM-dd HH:mm:ss"
              @change="timeChange"
            >
            </el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="结束时间" prop="endTime">
            <el-date-picker
              v-model="filterForm.endTime"
              type="datetime"
              placeholder="请选择时间"
              value-format="yyyy-MM-dd HH:mm:ss"
              @change="timeChange"
            >
            </el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="标题关键字" prop="title">
            <el-input v-model="filterForm.title" placeholder="请输入内容" clearable></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6" v-show="$route.path === '/ticketDataExcute'">
          <el-form-item label="是否超时" prop="isOverTime">
            <el-select v-model="filterForm.isOverTime" placeholder="请选择" clearable>
              <el-option
                v-for="item in isOverTimeList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col class="formBtn">
          <el-button type="primary" round @click="dataInit">查询</el-button>
          <el-button round type="info" plain @click="resetForm('formRef')">重置</el-button>
        </el-col>
      </el-row>
    </el-form>

    <el-table
      ref="tableRef"
      :data="tableData"
      stripe
      style="width:100%"
      class="publicTable"
      @row-click="(row, column, e) => rowClick(row, column, e, true)"
      @row-dblclick="rowDblclick"
      @selection-change="selectionChange"
    >
      <el-table-column type="selection"> </el-table-column>
      <el-table-column label="问题ID" show-overflow-tooltip prop="ticketId"> </el-table-column>
      <el-table-column
        label="问题标题"
        prop="title"
        show-overflow-tooltip
        width="300"
      ></el-table-column>
      <el-table-column label="问题平台" prop="platformName" show-overflow-tooltip></el-table-column>
      <el-table-column label="问题类型" prop="typeName" show-overflow-tooltip></el-table-column>
      <el-table-column label="紧急程度" prop="urgentName" show-overflow-tooltip></el-table-column>
      <el-table-column
        label="提交机构"
        prop="createdByDptName"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column
        label="提交人"
        prop="createdByUserName"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column
        label="提交时间"
        prop="createdTime"
        show-overflow-tooltip
        width="200"
      ></el-table-column>
      <el-table-column label="期望处理时间" prop="expectTime" show-overflow-tooltip width="200">
        <template slot-scope="scope">
          <span v-if="scope.row.expectTime">{{ scope.row.expectTime }}</span>
          <span v-else>{{ '-' }}</span>
        </template>
      </el-table-column>
      <el-table-column label="处理时长" prop="threshold" show-overflow-tooltip></el-table-column>
      <el-table-column label="超时预紧" prop="overTime" show-overflow-tooltip>
        <template slot-scope="scope">
          <span v-if="scope.row.overTime" style="color: #f56c6c">{{ '超时' }}</span>
          <span v-else>{{ '-' }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="经办人"
        prop="updatedByUserName"
        show-overflow-tooltip
      ></el-table-column>
      <el-table-column
        label="进度"
        prop="execStatus"
        show-overflow-tooltip
        :formatter="tableFormatter"
      ></el-table-column>
    </el-table>

    <el-pagination
      layout="total, prev, pager, next, jumper"
      :total="filterForm.pagTotal"
      :page-size="filterForm.size"
      background
      @current-change="currentChange"
    >
    </el-pagination>

    <My-dialog :title="'工单详情'" :className="'publicFDialog'" ref="workDetailsDia">
      <Work-details @closeDialog="closeDialog" :rows="rows" />
    </My-dialog>
  </div>
</template>

<script>
import WorkDetails from './WorkDetails.vue'
import { getWorkData, getTrackData, getDeliverData } from '@/api/user'
import { tableMix, selectMix } from '@/mixins'
import { getLocal } from '@/utils/storage'
export default {
  name: 'PublicWork',
  components: {
    WorkDetails // 工单详情
  },
  mixins: [tableMix, selectMix],
  data() {
    return {
      // 表单数据
      filterForm: {
        createdByUserName: '',
        platform: '',
        type: '',
        urgent: '',
        updatedByUserName: '',
        execStatus: '',
        title: '',
        startTime: '',
        endTime: '',
        isOverTime: '',
        page: 1,
        size: 10,
        pagTotal: 0
      },
      // 下拉框数据
      execStatusList: [
        {
          id: '2',
          name: '中止'
        },
        {
          id: '1',
          name: '已处理'
        },
        {
          id: '0',
          name: '处理中'
        }
      ],
      isOverTimeList: [
        {
          id: '1',
          name: '是'
        },
        {
          id: '0',
          name: '否'
        }
      ],
      rows: {} // 选中行的数据
    }
  },
  created() {
    if (this.$route.query.isAdmin !== 'admin') {
      if (this.$route.path === '/ticketDataQuery') {
        this.filterForm.createdBy = getLocal('isUser').userId
      } else if (this.$route.path === '/ticketDataExcute') {
        this.filterForm.updatedBy = getLocal('isUser').userId
      }
    }
  },
  mounted() {
    this.dataInit()
  },
  methods: {
    // 初始化数据
    dataInit() {
      if (this.$route.path === '/dataTrackRecord') return this.trackDataInit()
      if (this.$route.path === '/dataTransRecord') return this.deliverDataInit()
      this.workDataInit()
    },

    // 获取工单数据
    async workDataInit() {
      const res = await getWorkData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.ticketList
        this.filterForm.pagTotal = res.data.obj.total
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 获取跟踪数据
    async trackDataInit() {
      const res = await getTrackData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.ticketList
        this.filterForm.pagTotal = res.data.obj.total
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 获取转交数据
    async deliverDataInit() {
      const res = await getDeliverData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.ticketList
        this.filterForm.pagTotal = res.data.obj.total
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 表格数据格式化
    tableFormatter(row, column, cellValue, index) {
      let value = ''
      this[`${column.property}List`].forEach(item => {
        if (Number(cellValue) === Number(item.id)) {
          value = item.name
        }
      })
      return value
    },

    // 分页改变
    currentChange(currentPage) {
      this.filterForm.page = currentPage
      this.dataInit()
    },

    // 时间发生改变
    timeChange(value) {
      const startTime = new Date(this.filterForm.startTime).getTime()
      const endTime = new Date(this.filterForm.endTime).getTime()
      if (startTime && endTime) {
        if (startTime > endTime) {
          this.$message.warning('开始时间不能大于结束时间')
          this.filterForm.startTime = ''
          this.filterForm.endTime = ''
        }
      }
    },

    // 双击查看详情
    rowDblclick(row, column, event) {
      if (this.clickFlag) {
        // 取消上次延时未执行的方法
        this.clickFlag = clearTimeout(this.clickFlag)
      }
      this.$refs.workDetailsDia.dialogVisible = true
      this.rows = row
    },

    // 关闭工单详情
    closeDialog(v, p) {
      if (!v) {
        this.$refs.workDetailsDia.dialogVisible = false
      }
      if (p) {
        this.dataInit()
      }
    }
  }
}
</script>

<style scoped lang="less">
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s;
}
.fade-enter,
.fade-leave-active {
  opacity: 0;
}
</style>
