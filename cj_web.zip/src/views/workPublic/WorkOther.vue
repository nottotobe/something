<template>
  <div>
    <el-table
      ref="tableRef"
      :data="tableData"
      stripe
      style="width:100%"
      class="publicTable"
      @row-click="(row, column, e) => rowClick(row, column, e, true)"
      @row-dblclick="rowDblclick"
      @selection-change="selectionChange"
      @sort-change="tableSortChange"
      :cell-class-name="knowledgeMark"
    >
      <el-table-column type="selection"></el-table-column>
      <el-table-column
        label="问题ID"
        prop="ticketId"
        sortable="custom"
        show-overflow-tooltip
        width="100"
      >
      </el-table-column>
      <el-table-column
        label="问题标题"
        prop="title"
        sortable="custom"
        show-overflow-tooltip
        width="300"
      ></el-table-column>
      <el-table-column
        label="问题平台"
        prop="platformName"
        sortable="custom"
        show-overflow-tooltip
        width="100"
      ></el-table-column>
      <el-table-column
        label="问题类型"
        prop="typeName"
        show-overflow-tooltip
        sortable="custom"
        width="100"
      ></el-table-column>
      <el-table-column
        label="紧急程度"
        prop="urgentName"
        show-overflow-tooltip
        sortable="custom"
        width="100"
      ></el-table-column>
      <el-table-column
        label="提交机构"
        prop="createdByDptName"
        show-overflow-tooltip
        sortable="custom"
        width="100"
      ></el-table-column>
      <el-table-column
        label="提交人"
        prop="createdByUserName"
        show-overflow-tooltip
        sortable="custom"
        width="100"
      ></el-table-column>
      <el-table-column
        label="提交时间"
        prop="createdTime"
        show-overflow-tooltip
        width="200"
        sortable="custom"
      ></el-table-column>
      <el-table-column
        label="期望处理时间"
        prop="expectTime"
        show-overflow-tooltip
        width="200"
        sortable="custom"
      >
        <template slot-scope="scope">
          <span v-if="scope.row.expectTime">{{ scope.row.expectTime }}</span>
          <span v-else>{{ '-' }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="处理时长"
        prop="execTimes"
        show-overflow-tooltip
        sortable="custom"
        width="150"
      ></el-table-column>
      <el-table-column
        label="超时预警"
        prop="overTime"
        show-overflow-tooltip
        sortable="custom"
        width="100"
      >
        <template slot-scope="scope">
          <span v-if="scope.row.overTime" style="color: #f56c6c">{{ '超时' }}</span>
          <span v-else>{{ '-' }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="经办人"
        prop="updatedByUserName"
        show-overflow-tooltip
        sortable="custom"
        width="100"
      ></el-table-column>
      <el-table-column
        label="进度"
        prop="execStatus"
        show-overflow-tooltip
        :formatter="tableFormatter"
        sortable="custom"
        width="100"
      ></el-table-column>
    </el-table>

    <el-pagination
      layout="total, prev, pager, next, jumper"
      :total="filterForm.pagTotal"
      :page-size="filterForm.size"
      :current-page="filterForm.page"
      background
      @current-change="currentChange"
    >
    </el-pagination>

    <My-dialog :title="'工单详情'" :className="'publicFDialog'" ref="workDetailsDia">
      <Work-details @closeDialog="closeDialog" :rows="rows" />
    </My-dialog>
  </div>
</template>

<script>
import WorkDetails from './WorkDetails.vue'
import { getWorkData, getTrackData, getDeliverData } from '@/api/user'
import { tableMix } from '@/mixins'
export default {
  name: 'WorkOther',
  components: {
    WorkDetails // 工单详情
  },
  mixins: [tableMix],
  data() {
    return {
      execStatusList: [
        {
          id: '0',
          name: '处理中'
        },
        {
          id: '1',
          name: '已处理'
        },
        {
          id: '3',
          name: '已完成'
        },
        {
          id: '2',
          name: '中止'
        }
      ],
      rows: {}
    }
  },
  mounted() {
    this.dataInit()
  },
  inject: {
    rootapp: {
      default: null
    }
  },
  computed: {
    filterForm() {
      return this.rootapp.$refs.workForm.filterForm
    }
  },
  activated() {
    this.dataInit()
  },
  methods: {
    // 知识标记
    knowledgeMark({ row, column, rowIndex, columnIndex }) {
      if (column.type === 'selection' && row.knowledgeId) {
        return 'markStyle ignore'
      }
    },

    // 表格排序
    tableSortChange(par) {
      this.sortChange(par, this.dataInit)
    },

    // 初始化数据
    dataInit(v) {
      if (v === 'query') {
        this.filterForm.page = 1
      }

      if (this.$route.path === '/dataTrackRecord') return this.trackDataInit()
      if (this.$route.path === '/dataTransRecord') return this.deliverDataInit()
      this.workDataInit()
    },

    // 获取工单数据
    async workDataInit() {
      const res = await getWorkData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.ticketList
        this.filterForm.pagTotal = res.data.obj.total
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 获取跟踪数据
    async trackDataInit() {
      const res = await getTrackData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.ticketList
        this.filterForm.pagTotal = res.data.obj.total
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 获取转交数据
    async deliverDataInit() {
      const res = await getDeliverData(this.filterForm)
      if (res.data.status === 200) {
        this.tableData = res.data.obj.ticketList
        this.filterForm.pagTotal = res.data.obj.total
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 表格数据格式化
    tableFormatter(row, column, cellValue, index) {
      let value = ''
      this[`${column.property}List`].forEach(item => {
        if (Number(cellValue) === Number(item.id)) {
          value = item.name
        }
      })
      return value
    },

    // 分页改变
    currentChange(currentPage) {
      this.rootapp.$refs.workForm.filterForm.page = currentPage
      this.dataInit()
    },

    // 双击查看详情
    rowDblclick(row, column, event) {
      if (this.clickFlag) {
        // 取消上次延时未执行的方法
        this.clickFlag = clearTimeout(this.clickFlag)
      }
      this.$refs.workDetailsDia.dialogVisible = true
      this.rows = row
    },

    // 关闭工单详情
    closeDialog(v, p) {
      if (!v) {
        this.$refs.workDetailsDia.dialogVisible = false
      }
      if (p) {
        this.dataInit()
      }
    }
  }
}
</script>

<style scoped lang="less">
/deep/ .markStyle.ignore::before {
  content: '';
  position: absolute;
  top: -7px;
  left: 0;
  width: 0;
  height: 0;
  border-top: 10px solid transparent;
  border-right: 10px solid #1a9bff;
  border-bottom: 10px solid transparent;
  transform: rotate(45deg);
}
</style>
