<template>
  <div>
    <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-form-item label="一级分类" prop="firstType">
            <el-select
              v-model="filterForm.firstType"
              placeholder="请选择"
              clearable
              @change="firstTypeChange"
            >
              <el-option
                v-for="item in firstTypeList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="子类" prop="secondType">
            <el-select v-model="filterForm.secondType" placeholder="请选择" clearable>
              <el-option
                v-for="item in secondTypeList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="审核状态" prop="examStatus">
            <el-select v-model="filterForm.examStatus" placeholder="请选择" disabled>
              <el-option
                v-for="item in examStatusList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="标签" prop="labelList">
            <el-select
              v-model="filterForm.labelList"
              filterable
              multiple
              placeholder="请选择"
              clearable
            >
              <el-option
                v-for="item in labelList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="知识标题" prop="title">
            <el-input v-model="filterForm.title" placeholder="请输入内容" clearable></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="知识解答" prop="content">
            <el-input
              type="textarea"
              :autosize="{ minRows: 4, maxRows: 4 }"
              placeholder="请输入内容"
              v-model="filterForm.content"
            >
            </el-input>
          </el-form-item>
        </el-col>
        <el-col :span="24" class="picStyle">
          <el-form-item label="图片"></el-form-item>
          <My-upload ref="myUpload" :uploadList="picList" />
        </el-col>
        <el-col :span="8" class="picStyle" style="margin-top:20px">
          <el-form-item label="其他附件"> </el-form-item>
          <ATT-upload ref="attUpload" :uploadList="otherList" />
        </el-col>
        <el-col :span="24" class="formBtn">
          <el-button type="primary" round @click="confirmCKnowledge">确定</el-button>
          <el-button round @click="$emit('closeTab', closeTab, true)">取消</el-button>
        </el-col>
      </el-row>
    </el-form>

    <Audit-idea :auditObj="filterForm" v-if="filterForm.examStatus === '2'" />
  </div>
</template>

<script>
import MyUpload from '@/components/MyUpload'
import ATTUpload from '@/components/ATTUpload'
import AuditIdea from './components/AuditIdea'
import { getTagData, getKnowledgeClass, addKnowledgeData, editKnowledgeData } from '@/api/user'
export default {
  name: 'CKnowledge',
  components: {
    MyUpload,
    ATTUpload,
    AuditIdea
  },
  props: {
    flag: {
      type: String,
      default: 'add'
    },
    rows: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      filterForm: {
        firstType: '',
        secondType: '',
        title: '',
        content: '',
        labelList: [],
        imageDataList: [],
        examStatus: '0'
      },
      labelList: [],
      firstTypeList: [],
      secondTypeList: [],
      examStatusList: [
        {
          id: '0',
          name: '待审核'
        },
        {
          id: '1',
          name: '审核通过'
        },
        {
          id: '2',
          name: '不通过'
        }
      ],
      rulesForm: {
        firstType: [{ required: true, message: '一级分类不能为空', trigger: 'change' }],
        title: [{ required: true, message: '知识标题不能为空', trigger: 'change' }],
        content: [{ required: true, message: '知识解答不能为空', trigger: 'change' }]
      },
      closeTab: '2'
    }
  },
  mounted() {
    this.getClassLabel()
  },
  activated() {
    this.getClassLabel()
  },
  computed: {
    picList() {
      return this.filterForm.imageDataList.filter(item => {
        return (
          item.imageType === '.jpg' ||
          item.imageType === '.mp4' ||
          item.imageType === '.png' ||
          item.imageType === '.jpeg'
        )
      })
    },
    otherList() {
      const arr = []
      this.filterForm.imageDataList.forEach(item => {
        if (
          item.imageType !== '.jpg' &&
          item.imageType !== '.mp4' &&
          item.imageType !== '.png' &&
          item.imageType !== '.jpeg'
        ) {
          item.name = item.imageName
          item.url = item.imageUri
          arr.push(item)
        }
      })
      return arr
    }
  },
  methods: {
    // 修改状态初始化
    CKnowledgeInit() {
      if (this.flag === 'edit') {
        this.closeTab = '3'
        this.filterForm = Object.assign({}, this.rows)
        const tagArr = []
        this.filterForm.labelList.forEach(item => {
          tagArr.push(item.id)
        })
        this.filterForm.labelList = tagArr
        this.firstTypeList.forEach(item => {
          if (this.filterForm.firstType === item.id) {
            this.secondTypeList = item.children
          }
        })
      }

      if (this.flag === 'work' || this.flag === 'details') {
        // 赋值工单id
        this.filterForm.ticketId = this.rows.ticketId
        // 赋值知识id
        this.filterForm.knowledgeId = this.rows.knowledgeId
        // 赋值标题
        this.filterForm.title = this.rows.title
        // 赋值标签
        const tagArr = []
        this.rows.labelList.forEach(item => {
          tagArr.push(item.id)
        })
        this.filterForm.labelList = tagArr

        const newTicketReplyList = this.rows.ticketReplyList.filter(item => {
          return item.type === 'reply'
        })

        // 赋值图片
        let imgArr = []
        newTicketReplyList.forEach(item => {
          imgArr = imgArr.concat(item.imageDataList)
        })
        this.filterForm.imageDataList = imgArr
        // 赋值回复
        let messageStr = ''
        newTicketReplyList.forEach((item, index) => {
          messageStr = messageStr + (Number(index) + 1) + '、' + item.explain + '\n'
        })
        this.filterForm.content = messageStr
      }
    },

    // 获取知识分类和标签
    async getClassLabel() {
      const tag = await getTagData()
      const knowledgeClass = await getKnowledgeClass()
      this.labelList = tag.data.obj.labelList.filter(item => {
        return item.examStatus === '1'
      })
      this.firstTypeList = knowledgeClass.data.obj.knowledgeMainList

      this.CKnowledgeInit()
    },

    // 一级分类发生变化
    firstTypeChange() {
      this.secondTypeList = []
      this.filterForm.secondType = ''
      this.firstTypeList.forEach(item => {
        if (item.id === this.filterForm.firstType) {
          this.secondTypeList = item.children
        }
      })
    },

    // 确定
    confirmCKnowledge() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        let res
        const mySuccessUpList = this.$refs.myUpload.successUpList
        const attSuccessUpList = this.$refs.attUpload.successUpList
        const upArr = mySuccessUpList.concat(attSuccessUpList)
        const tagArr = []
        this.filterForm.labelList.forEach(item => {
          tagArr.push({ id: item })
        })
        if (this.flag === 'add') {
          res = await addKnowledgeData({
            firstType: this.filterForm.firstType,
            secondType: this.filterForm.secondType,
            title: this.filterForm.title,
            content: this.filterForm.content,
            labelList: tagArr,
            imageDataList: upArr
          })
        } else if (this.flag === 'work' || this.flag === 'details') {
          if (this.filterForm.knowledgeId) {
            res = await editKnowledgeData({
              id: this.filterForm.knowledgeId,
              ticketId: this.filterForm.ticketId,
              firstType: this.filterForm.firstType,
              secondType: this.filterForm.secondType,
              title: this.filterForm.title,
              content: this.filterForm.content,
              labelList: tagArr,
              imageDataList: upArr
            })
          } else {
            res = await addKnowledgeData({
              ticketId: this.filterForm.ticketId,
              firstType: this.filterForm.firstType,
              secondType: this.filterForm.secondType,
              title: this.filterForm.title,
              content: this.filterForm.content,
              labelList: tagArr,
              imageDataList: upArr
            })
          }
        } else {
          res = await editKnowledgeData({
            id: this.filterForm.id,
            firstType: this.filterForm.firstType,
            secondType: this.filterForm.secondType,
            title: this.filterForm.title,
            content: this.filterForm.content,
            labelList: tagArr,
            imageDataList: upArr
          })
        }
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          this.$emit('closeTab', this.closeTab)
        } else {
          this.$message.error(res.data.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
