<template>
  <div>
    <div class="dialog_box">
      <Work-info ref="workInfo" />
    </div>
    <div class="dialog_box">
      <Deal-info ref="dealInfo" />
    </div>
    <div class="dialog_box">
      <Reply-list ref="replyList" />
      <el-row style="text-align: right;">
        <el-button round v-if="suspendJudge" type="danger" plain @click="suspend('2')"
          >中止</el-button
        >
        <el-button round v-if="enableJudge" type="primary" plain @click="suspend('0')"
          >启用
        </el-button>
        <el-button type="primary" v-if="knowledgeJudge" round @click="createKnowledge"
          >生成知识</el-button
        >
        <el-button round @click="$emit('closeDialog')" v-if="!replyJudge && !feedbackJudge"
          >关闭</el-button
        >
      </el-row>
    </div>
    <div class="dialog_box" v-if="replyJudge">
      <My-collapse :title="'问题回复'">
        <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="经办人" prop="updatedByUserName">
                <el-input
                  v-model="filterForm.updatedByUserName"
                  placeholder="请输入内容"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="问题回复" prop="explain">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 4, maxRows: 4 }"
                  placeholder="请输入内容"
                  v-model="filterForm.explain"
                >
                </el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24" class="picStyle">
              <el-form-item label="图片/视频"> </el-form-item>
              <My-upload ref="myUpload" />
            </el-col>
            <el-col :span="8" class="picStyle" style="margin-top:20px">
              <el-form-item label="其他附件"> </el-form-item>
              <ATT-upload ref="attUpload" />
            </el-col>
            <el-col :span="24" class="formBtn">
              <el-button type="primary" round @click="reply" :disabled="replyDis">回复</el-button>
              <el-button
                type="primary"
                round
                @click="$refs.loreLibraryDia.dialogVisible = true"
                :disabled="replyDis"
              >
                匹配知识库
              </el-button>
              <el-button round @click="$emit('closeDialog')">关闭</el-button>
            </el-col>
          </el-row>
        </el-form>
      </My-collapse>
    </div>
    <div class="dialog_box" v-if="feedbackJudge">
      <My-collapse :title="'问题反馈'">
        <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="提交人" prop="updatedByUserName">
                <el-input
                  v-model="filterForm.updatedByUserName"
                  placeholder="请输入内容"
                  disabled
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="紧急程度" prop="urgent">
                <el-select v-model="filterForm.urgent" placeholder="请选择" clearable>
                  <el-option
                    v-for="item in newUrgentList"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="6" v-if="filterForm.urgent === '14'">
              <el-form-item label="期望处理时间" prop="expectTime">
                <el-date-picker
                  v-model="filterForm.expectTime"
                  type="date"
                  placeholder="请选择时间"
                  value-format="yyyy-MM-dd"
                >
                </el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="问题反馈" prop="explain">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 4, maxRows: 4 }"
                  placeholder="请输入内容"
                  v-model="filterForm.explain"
                >
                </el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24" class="picStyle">
              <el-form-item label="图片/视频"> </el-form-item>
              <My-upload ref="myUpload" />
            </el-col>
            <el-col :span="8" class="picStyle" style="margin-top:20px">
              <el-form-item label="其他附件"> </el-form-item>
              <ATT-upload ref="attUpload" />
            </el-col>
            <el-col :span="24" class="formBtn">
              <el-button type="primary" round @click="feedback" :disabled="feedbackDis"
                >反馈</el-button
              >
              <el-button round @click="$emit('closeDialog')">关闭</el-button>
            </el-col>
          </el-row>
        </el-form>
      </My-collapse>
    </div>
    <div class="dialog_box" v-if="feedbackJudge">
      <My-collapse :title="'评价'">
        <el-row class="iconStyle">
          <div class="dianzan">
            <span class="iconfont icon-dianzan" @click="workEval('1')"></span>
          </div>
          <div class="cai">
            <span class="iconfont icon-cai" @click="workEval('0')"></span>
          </div>
        </el-row>
      </My-collapse>
    </div>

    <div class="evalStyle ignore" v-if="evalJudge">
      <span :class="'iconfont ' + evalJudge"></span>
    </div>
    <el-backtop target=".el-dialog">
      <div class="publicBacktop ignore">UP</div>
    </el-backtop>

    <My-dialog
      :title="'匹配知识库'"
      :className="'publicNDialog'"
      ref="loreLibraryDia"
      :width="'80%'"
      :appendBody="true"
    >
      <Lore-library :rows="rows" @loreLibraryMatch="loreLibraryMatch" />
    </My-dialog>
  </div>
</template>

<script>
import WorkInfo from './components/WorkInfo.vue'
import DealInfo from './components/DealInfo.vue'
import ReplyList from './components/ReplyList.vue'
import LoreLibrary from '../dispose/components/LoreLibrary'
import MyUpload from '@/components/MyUpload'
import ATTUpload from '@/components/ATTUpload'
import {
  getWorkData,
  replyWork,
  suspendWork,
  feedbackWork,
  getClassifyData,
  evalWork
} from '@/api/user'
import { getLocal } from '@/utils/storage'
import { mapMutations } from 'vuex'
export default {
  name: 'MyDetails',
  components: {
    WorkInfo, // 工单信息
    DealInfo, // 工单办理信息
    ReplyList, // 回复列表
    LoreLibrary, // 匹配知识库
    MyUpload, // 上传组件
    ATTUpload
  },
  props: {
    rows: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      filterForm: {
        updatedByUserName: '',
        explain: '',
        imageDataList: [],
        urgent: '',
        expectTime: ''
      },
      workRows: {},
      replyDis: false,
      feedbackDis: false,
      urgentList: [], // 紧急程度
      rulesForm: {
        explain: [{ required: true, message: '问题回复不能为空', trigger: 'change' }],
        urgent: [{ required: true, message: '紧急程度不能为空', trigger: 'change' }],
        expectTime: [{ required: true, message: '期望处理时间不能为空', trigger: 'change' }]
      },
      caiStyle: ''
    }
  },
  created() {
    this.init()
    this.getPTUData()
  },
  mounted() {},
  computed: {
    // 查询页面 状态为未处理  提交人为登录账号  展示中止
    suspendJudge() {
      return (
        this.$route.path === '/ticketDataQuery' &&
        this.workRows.execStatus === '0' &&
        this.workRows.createdBy === getLocal('isUser').userId
      )
    },
    // 查询页面 状态为中止  提交人为登录账号  展示启用
    enableJudge() {
      return (
        this.$route.path === '/ticketDataQuery' &&
        this.workRows.execStatus === '2' &&
        this.workRows.createdBy === getLocal('isUser').userId
      )
    },
    // 处理页面  状态为已处理  展示生成知识
    knowledgeJudge() {
      return (
        this.$route.path === '/ticketDataExcute' &&
        (this.workRows.execStatus === '1' || this.workRows.execStatus === '3')
      )
    },
    // 状态为已完成  展示评价（仅展示，操作评价与反馈条件一致）
    evalJudge() {
      if (this.workRows.execStatus === '3') {
        if (this.workRows.evalType === '1') {
          return 'icon-dianzan successClass'
        } else {
          return 'icon-cai successClass'
        }
      } else {
        return false
      }
    },
    // 查询页面 状态为已处理  提交人为登录账号  展示反馈
    feedbackJudge() {
      return (
        this.$route.path === '/ticketDataQuery' &&
        this.workRows.execStatus === '1' &&
        this.workRows.createdBy === getLocal('isUser').userId
      )
    },
    // 处理页面或者工作台的表格数据 状态为未处理  经办人为登录账号 或者账号是管理员  展示回复
    replyJudge() {
      return (
        (this.$route.path === '/ticketDataExcute' || this.$route.path === '/dashboard') &&
        this.workRows.execStatus === '0'
      )
    },
    // 过滤紧急程度
    newUrgentList() {
      return this.urgentList.filter(item => {
        return item.status === '1'
      })
    }
  },
  methods: {
    // 生成知识标签
    ...mapMutations('CKnowledge', ['createKnowledgeTab']),

    // 反馈时需要紧急程度下拉数据
    async getPTUData() {
      const urgent = await getClassifyData({
        item: 'urgent'
      })
      this.urgentList = urgent.data.obj.typesList
      this.$refs.workInfo.urgentList = this.urgentList
      this.$refs.replyList.urgentList = this.urgentList
    },

    // 初始化
    async init() {
      const res = await getWorkData({
        ticketId: this.rows.ticketId
      })
      console.log(res)
      const ticketObj = res.data.obj.ticketList[0]
      this.workRows = Object.assign({}, ticketObj)
      this.$refs.workInfo.filterForm = Object.assign({}, ticketObj)
      this.$refs.workInfo.feedbackList = ticketObj.ticketReplyList
      this.$refs.dealInfo.tableData = ticketObj.ticketTrailList
      this.$refs.replyList.replyList = ticketObj.ticketReplyList
      if (this.replyJudge) {
        this.filterForm.updatedByUserName = ticketObj.updatedByUserName
      } else {
        this.filterForm.updatedByUserName = ticketObj.createdByUserName
      }
    },

    // 回复
    async reply() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        const mySuccessUpList = this.$refs.myUpload.successUpList
        const attSuccessUpList = this.$refs.attUpload.successUpList
        const imgArr = mySuccessUpList.concat(attSuccessUpList)
        const res = await replyWork({
          ticketId: this.$refs.workInfo.filterForm.ticketId,
          explain: this.filterForm.explain,
          imageDataList: imgArr
        })
        if (res.data.status === 200) {
          this.loading()
          this.$message.success('回复成功')
          this.init()
          this.$emit('closeDialog', true, true)
          this.$refs.formRef.resetFields()
          this.$refs.myUpload.clear()
          this.$refs.attUpload.clear()
          this.replyDis = true
        } else {
          this.$message.error(res.data.msg)
        }
      })
    },

    // 生成知识
    createKnowledge() {
      if (this.$refs.workInfo.filterForm.execStatus === '0') {
        this.$message.warning('该工单处理中')
        return
      }

      if (this.$refs.workInfo.filterForm.knowledgeId) {
        this.$confirm('该工单已生成过知识，确定重新生成吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          closeOnClickModal: false
        })
          .then(async () => {
            this.createKnowledgeTab({
              flag: 'details',
              rows: this.workRows
            })
            this.$emit('closeDialog', false, false)
          })
          .catch(() => {})
      } else {
        this.createKnowledgeTab({
          flag: 'details',
          rows: this.workRows
        })
        this.$emit('closeDialog', false, false)
      }
    },

    // 匹配知识库回调数据
    loreLibraryMatch(f, v) {
      this.$refs.loreLibraryDia.dialogVisible = false
      if (!f) return
      this.filterForm.explain = v.content
      this.filterForm.imageDataList = v.imageDataList
    },

    // 中止
    async suspend(num) {
      const res = await suspendWork({
        ticketId: this.rows.ticketId,
        execStatus: num
      })
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.$emit('closeDialog', false, true)
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 反馈
    async feedback() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        const mySuccessUpList = this.$refs.myUpload.successUpList
        const attSuccessUpList = this.$refs.attUpload.successUpList
        const imgArr = mySuccessUpList.concat(attSuccessUpList)
        const res = await feedbackWork({
          ticketId: this.$refs.workInfo.filterForm.ticketId,
          explain: this.filterForm.explain,
          imageDataList: imgArr,
          urgent: this.filterForm.urgent,
          expectTime: this.filterForm.expectTime
        })

        if (res.data.status === 200) {
          this.loading()
          this.$message.success('反馈成功')
          this.init()
          this.$emit('closeDialog', true, true)
          this.$refs.formRef.resetFields()
          this.$refs.myUpload.clear()
          this.$refs.attUpload.clear()
          this.feedbackDis = true
        } else {
          this.$message.error(res.data.msg)
        }
      })
    },

    // 评价
    async workEval(v) {
      this.$confirm('确定提交评价完成工单吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        closeOnClickModal: false
      })
        .then(async () => {
          const res = await evalWork({
            relationId: this.rows.ticketId,
            type: v,
            status: '1'
          })
          if (res.data.status === 200) {
            this.$message.success(res.data.msg)
            this.$emit('closeDialog', false, true)
          } else {
            this.$message.error(res.data.msg)
          }
        })
        .catch(() => {})
    },

    // 加载
    loading() {
      const loading = this.$loading({
        background: '#fff',
        text: '加载中'
      })
      setTimeout(() => {
        loading.close()
      }, 2000)
    }
  }
}
</script>

<style scoped lang="less">
.iconStyle {
  margin-top: 20px;
  display: flex;
  .dianzan,
  .cai {
    display: flex;
    align-items: center;
    margin-right: 25px;
    color: #a0a6b9;
    &:hover {
      color: #5980ff;
    }
    span {
      margin-right: 10px;
      cursor: pointer;
      font-size: 40px;
    }
  }
}
.successClass {
  color: #5980ff !important;
}
.evalStyle.ignore {
  position: fixed;
  bottom: 100px;
  right: 40px;
  .iconfont {
    font-size: 40px;
  }
}
</style>
