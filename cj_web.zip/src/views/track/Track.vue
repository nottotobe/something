<template>
  <My-tabs :tabTitle="'数据跟踪查询'">
    <template v-slot:collapseTab>
      <Work-form ref="workForm" />
    </template>
    <Work-other ref="workOther" />
    <el-row class="tableBtn">
      <el-button type="primary" round @click="goCancel">取消跟踪</el-button>
      <el-button type="primary" round @click="exportExcel">导出</el-button>
    </el-row>
  </My-tabs>
</template>

<script>
import WorkForm from '../workPublic/WorkForm'
import WorkOther from '../workPublic/WorkOther'
import { trackCancel } from '@/api/user'
export default {
  name: 'Track',
  components: {
    WorkForm, // 公共部分
    WorkOther // 公共部分
  },
  data() {
    return {}
  },
  provide: function() {
    return {
      rootapp: this
    }
  },
  mounted() {},
  methods: {
    // 取消跟踪
    async goCancel() {
      const selectedRows = this.$refs.workOther.selectedRows
      if (selectedRows.length === 0) return this.$message.warning('请选择一条数据')

      const parArr = []
      selectedRows.forEach(item => {
        parArr.push({
          ticketId: item.ticketId
        })
      })
      const res = await trackCancel(parArr)
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.$refs.workOther.dataInit()
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 导出
    exportExcel() {
      const obj = this.$refs.workForm.filterForm
      let pars = ''
      for (var k in obj) {
        const par = k + '=' + obj[k] + '&'
        pars = pars + par
      }
      pars = pars.substring(0, pars.length - 1)
      window.open('/oam/ticket/track/export/excel?' + pars, '_parent')
    }
  }
}
</script>

<style scoped lang="less"></style>
