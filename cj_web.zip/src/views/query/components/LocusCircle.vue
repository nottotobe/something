<template>
  <div class="dialog_box">
    <My-collapse :title="'工单ID：' + ticketId">
      <div v-if="LocusList.length === 0">
        <el-empty :image-size="100"> </el-empty>
      </div>
      <el-steps
        v-else
        direction="vertical"
        :active="LocusList.length"
        :space="300"
        :finish-status="'process'"
      >
        <el-step v-for="(item, index) in LocusList" :key="index">
          <el-row slot="title" class="step_box">
            <div class="step_title">
              <span v-if="item.type === 'submit'">
                提交问题
              </span>
              <span v-if="item.type === 'transfer'">
                转交问题
              </span>
              <span v-if="item.type === 'retrieve'">
                取回问题
              </span>
              <span v-if="item.type === 'reply'">
                回复问题
              </span>
              <span v-if="item.type === 'resubmit'">
                反馈问题
              </span>
              {{ item.createdTime.split(' ')[0] }}
            </div>
            <el-col :span="6">
              提交人：{{ item.createdByUserName ? item.createdByUserName : '-' }}
            </el-col>
            <el-col :span="6">
              提交机构：{{ item.createdByDptName ? item.createdByDptName : '-' }}
            </el-col>
            <el-col :span="6"> 提交时间：{{ item.createdTime ? item.createdTime : '-' }} </el-col>
            <el-col :span="6">
              经办人：{{ item.updatedByUserName ? item.updatedByUserName : '-' }}
            </el-col>
            <el-col :span="6">
              处理机构：{{ item.updatedByDptName ? item.updatedByDptName : '-' }}
            </el-col>
            <el-col :span="6"> 处理时间：{{ item.updatedTime ? item.updatedTime : '-' }} </el-col>
            <el-col :span="6">
              状态：{{ item.status ? (item.status === '1' ? '已处理' : '未处理') : '-' }}
            </el-col>
          </el-row>
        </el-step>
      </el-steps>
    </My-collapse>
  </div>
</template>

<script>
import { getLocusCircleData } from '@/api/user'
export default {
  name: 'LocusCircle',
  props: {
    ticketId: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      LocusList: []
    }
  },
  mounted() {
    this.locusCircleDataInit()
  },
  methods: {
    async locusCircleDataInit() {
      const res = await getLocusCircleData(this.ticketId)
      this.LocusList = res.data.obj
    }
  }
}
</script>

<style scoped lang="less">
.step_box {
  background: #f5f5f5;
  border-radius: 20px;
  padding: 20px 20px;
  .el-col {
    background: #fff;
    margin: 10px;
    padding: 10px;
    border: 1px solid #e5e5e5;
  }
  .step_title {
    margin: 10px;
    font-weight: 900;
    span {
      margin-right: 10px;
    }
  }
}

/deep/ .publicTitle .el-collapse-item__header {
  color: unset;
}
</style>
