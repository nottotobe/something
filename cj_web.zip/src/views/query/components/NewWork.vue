<template>
  <div>
    <el-form :model="filterForm" ref="formRef" :rules="rulesForm">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-form-item label="问题平台" prop="platform">
            <el-select v-model="filterForm.platform" placeholder="请选择" clearable>
              <el-option
                v-for="item in newPlatformList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="问题类型" prop="type">
            <el-select v-model="filterForm.type" placeholder="请选择" clearable>
              <el-option
                v-for="item in newTypeList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="紧急程度" prop="urgent">
            <el-select v-model="filterForm.urgent" placeholder="请选择" clearable>
              <el-option
                v-for="item in newUrgentList"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6" v-if="filterForm.urgent === '14'">
          <el-form-item label="期望处理时间" prop="expectTime">
            <el-date-picker
              v-model="filterForm.expectTime"
              type="date"
              placeholder="请选择时间"
              value-format="yyyy-MM-dd"
            >
            </el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6">
          <el-form-item label="问题上报机构" prop="sourceDpt">
            <el-cascader
              v-model="filterForm.sourceDpt"
              :props="dptCodeProps"
              :options="dptCodeList"
              :show-all-levels="false"
              clearable
              ref="checkStrictlyRef"
              popper-class="checkStrictlyStyle ignore"
            ></el-cascader>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="问题上报人" prop="source">
            <el-input v-model="filterForm.source" placeholder="请输入内容" clearable></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="工单经办人" prop="updatedBy">
            <el-select v-model="filterForm.updatedBy" placeholder="请选择" clearable>
              <el-option
                v-for="item in updatedByList"
                :key="item.userId"
                :label="item.username"
                :value="item.userId"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="关联单号" prop="policyNo">
            <el-input v-model="filterForm.policyNo" placeholder="请输入内容" clearable></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="问题标题" prop="title">
            <el-input v-model="filterForm.title" placeholder="请输入内容" clearable></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-form-item label="问题描述" prop="explain">
            <el-input
              type="textarea"
              :autosize="{ minRows: 4, maxRows: 4 }"
              placeholder="请输入内容"
              v-model="filterForm.explain"
            >
            </el-input>
          </el-form-item>
        </el-col>
        <el-col :span="24" class="picStyle">
          <el-form-item label="图片/视频"></el-form-item>
          <My-upload ref="myUpload" />
        </el-col>
        <el-col :span="8" class="picStyle" style="margin-top:20px">
          <el-form-item label="其他附件"> </el-form-item>
          <ATT-upload ref="attUpload" />
        </el-col>
        <el-col :span="24" class="formBtn">
          <el-button type="primary" round @click="submitWork">提交</el-button>
          <el-button
            round
            type="info"
            plain
            @click="resetForm"
            v-if="$route.path === '/ticketDataAdd'"
            >重置</el-button
          >

          <el-button round @click="$emit('closeWorkTab', true)" v-else>关闭</el-button>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import MyUpload from '@/components/MyUpload'
import ATTUpload from '@/components/ATTUpload'
import { addWorkData, getHandlerData } from '@/api/user'
import { selectMix, dptMix } from '@/mixins'
import { setSession, getLocal } from '@/utils/storage'
import { mapMutations } from 'vuex'
export default {
  name: 'NewWork',
  components: {
    MyUpload,
    ATTUpload
  },
  mixins: [selectMix, dptMix],
  activated() {
    this.getPTUData()
    this.dptDataInit()
    this.userDataInit()
  },
  mounted() {
    this.userDataInit()
  },
  watch: {
    'filterForm.sourceDpt'(newVlaue, oldValue) {
      if (this.$refs.checkStrictlyRef) {
        this.$refs.checkStrictlyRef.dropDownVisible = false
      }
    }
  },
  data() {
    return {
      filterForm: {
        platform: '',
        type: '',
        urgent: '',
        expectTime: '',
        title: '',
        explain: '',
        imageDataList: [],
        source: '',
        sourceDpt: '',
        policyNo: ''
      },
      rulesForm: {
        platform: [{ required: true, message: '问题平台不能为空', trigger: 'change' }],
        type: [{ required: true, message: '问题类型不能为空', trigger: 'change' }],
        urgent: [{ required: true, message: '紧急程度不能为空', trigger: 'change' }],
        expectTime: [{ required: true, message: '期望处理时间不能为空', trigger: 'change' }],
        title: [{ required: true, message: '问题标题不能为空', trigger: 'change' }],
        explain: [{ required: true, message: '问题描述不能为空', trigger: 'change' }]
      },
      updatedByList: []
    }
  },
  methods: {
    ...mapMutations(['saveNavState']),

    submitWork() {
      this.$refs.formRef.validate(async valid => {
        if (!valid) return
        const mySuccessUpList = this.$refs.myUpload.successUpList
        const attSuccessUpList = this.$refs.attUpload.successUpList
        this.filterForm.imageDataList = mySuccessUpList.concat(attSuccessUpList)
        const res = await addWorkData(this.filterForm)
        if (res.data.status === 200) {
          this.$message.success(res.data.msg)
          if (this.$route.path === '/ticketDataAdd') {
            const menuList = getLocal('menuList')
            let par
            menuList.forEach(item => {
              if (item.name === '工单查询') {
                par = item.children[0].explain
              }
            })
            this.$router.push({
              path: '/ticketDataQuery',
              query: par ? { isAdmin: par } : {}
            })
            this.saveNavState('/ticketDataQuery')
            setSession('subMenuIndex', 1)
            this.resetForm()
          } else {
            this.$emit('closeWorkTab')
          }
        } else {
          this.$message.error(res.data.msg)
        }
      })
    },

    // 重置
    resetForm() {
      this.$refs.formRef.resetFields()
      this.$refs.myUpload.clear()
      this.$refs.attUpload.clear()
    },

    // 获取用户数据
    async userDataInit() {
      const res = await getHandlerData()
      if (res.data.status === 200) {
        this.updatedByList = res.data.obj
      } else {
        this.$message.error(res.data.msg)
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
