<template>
  <div>
    <el-checkbox
      :indeterminate="isIndeterminate"
      v-model="checkAll"
      @change="handleCheckAllChange"
      style=" margin-bottom: 20px;"
      >全选</el-checkbox
    >
    <el-checkbox-group v-model="checkedLists" @change="handleCheckedListsChange">
      <el-checkbox v-for="item in exportDomainList" :label="item.id" :key="item.id">{{
        item.name
      }}</el-checkbox>
    </el-checkbox-group>

    <el-row class="formBtn">
      <el-button type="primary" round @click="editUserDomainData">确定</el-button>
      <el-button round @click="$emit('closeDialog')">取消</el-button>
    </el-row>
  </div>
</template>

<script>
import { getExportDomain, getUserDomain, editUserDomain } from '@/api/user'
export default {
  name: 'exportDomain',
  data() {
    return {
      checkAll: false,
      checkedLists: [],
      exportDomainList: [],
      isIndeterminate: false
    }
  },
  created() {
    this.getExportDomainData()
  },
  mounted() {},
  methods: {
    // 获取全部配置
    async getExportDomainData() {
      const res = await getExportDomain('ticket')
      if (res.data.status === 200) {
        this.exportDomainList = res.data.obj
        this.getUserDomainData()
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 获取用户配置
    async getUserDomainData() {
      const res = await getUserDomain('ticket')
      if (res.data.status === 200) {
        const newArr = []
        res.data.obj.forEach(item => {
          newArr.push(item.id)
        })
        this.checkedLists = newArr
        const checkedCount = this.checkedLists.length
        this.checkAll = checkedCount === this.exportDomainList.length
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.exportDomainList.length
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 修改用户配置
    async editUserDomainData() {
      const res = await editUserDomain({
        type: 'ticket', // ticket 表示类型为工单    目前只弄了工单的
        ids: this.checkedLists // 勾到数据的id
      })
      if (res.data.status === 200) {
        this.$message.success(res.data.msg)
        this.$emit('closeDialog')
      } else {
        this.$message.error(res.data.msg)
      }
    },

    // 全选发生改变
    handleCheckAllChange(val) {
      const newArr = []
      this.exportDomainList.forEach(item => {
        newArr.push(item.id)
      })
      this.checkedLists = val ? newArr : []
      this.isIndeterminate = false
    },

    // 选项发生改变
    handleCheckedListsChange(value) {
      const checkedCount = value.length
      this.checkAll = checkedCount === this.exportDomainList.length
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.exportDomainList.length
    }
  }
}
</script>

<style scoped lang="less">
.el-checkbox-group {
  .el-checkbox {
    width: 150px;
    margin-bottom: 20px;
  }
}
</style>
