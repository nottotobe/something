<template>
  <div>
    <My-tabs
      ref="myTabs"
      :tabTitle="'工单数据查询'"
      :editableTabs="queryTabs"
      @filterEditableTabs="filterEditableTabs"
      :editableTabsFlag="'query'"
      :exportDomainFlag="true"
    >
      <template v-slot:collapseTab>
        <Work-form ref="workForm" />
      </template>
      <Work-other ref="workOther" />
      <el-row class="tableBtn">
        <el-button type="primary" round @click="createWorkTab">
          新建工单
        </el-button>
        <el-button type="primary" round @click="showLocusCircle">轨迹图</el-button>
        <el-button type="primary" round @click="exportExcel">导出</el-button>
      </el-row>

      <template v-slot:customTab>
        <el-tab-pane
          v-for="item in queryTabs"
          :key="item.name"
          :label="item.title"
          :name="item.name"
          closable
        >
          <div>
            <component :is="item.type" @closeWorkTab="closeWorkTab"></component>
          </div>
        </el-tab-pane>
      </template>
    </My-tabs>

    <My-dialog :title="'轨迹图'" :className="'publicFDialog'" ref="locusCircleDia">
      <Locus-circle :ticketId="ticketId" />
    </My-dialog>
  </div>
</template>

<script>
import WorkForm from '../workPublic/WorkForm'
import WorkOther from '../workPublic/WorkOther'
import NewWork from './components/NewWork'
import LocusCircle from './components/LocusCircle'
import MyTabs from '@/components/MyTabs'
import { mapState, mapMutations } from 'vuex'
export default {
  name: 'Query',
  components: {
    WorkForm, // 公共部分
    WorkOther, // 公共部分
    NewWork, // 新建工单
    LocusCircle, // 轨迹圈
    MyTabs // 标签栏
  },
  data() {
    return {
      ticketId: '',
      rows: {}
    }
  },
  provide: function() {
    return {
      rootapp: this
    }
  },
  mounted() {},
  computed: {
    ...mapState({
      queryTabs: state => state.CWork.queryTabs
    })
  },
  methods: {
    // 新建工单标签 关闭标签
    ...mapMutations('CWork', ['createWorkTab', 'delWorkTab']),

    // 轨迹图
    showLocusCircle() {
      const selectedRows = this.$refs.workOther.selectedRows
      if (selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      if (selectedRows.length > 1) return this.$message.warning('只能勾选一条数据')
      this.ticketId = selectedRows[0].ticketId
      this.$refs.locusCircleDia.dialogVisible = true
    },

    // 导出
    exportExcel() {
      const obj = this.$refs.workForm.filterForm
      let pars = ''
      for (var k in obj) {
        const par = k + '=' + obj[k] + '&'
        pars = pars + par
      }
      pars = pars.substring(0, pars.length - 1)
      window.open('/oam/ticket/export/excel?' + pars, '_parent')
    },

    // 关闭tab
    closeWorkTab(v) {
      this.$refs.myTabs.removeWorkTab('2')
      if (v) return
      this.$refs.workOther.dataInit()
    },

    // 过滤关闭的tab
    filterEditableTabs(a, b) {
      const queryTabs = a.filter(tab => tab.name !== b)
      this.delWorkTab(queryTabs)
    }
  }
}
</script>

<style scoped lang="less"></style>
