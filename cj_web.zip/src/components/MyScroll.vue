<template>
  <vuescroll :ops="newOps">
    <slot></slot>
  </vuescroll>
</template>

<script>
import vuescroll from 'vuescroll/dist/vuescroll-native'
import _ from 'lodash'
const defaultOps = {
  vuescroll: {
    mode: 'native'
    // sizeStrategy: 'number'
  },
  scrollPanel: {
    scrollingX: false
  },
  rail: {
    gutterOfSide: '0'
  },
  bar: {
    background: '#ccc',
    size: '3px'
  }
} // 默认的一些简单配置
export default {
  name: 'MyScroll',
  components: {
    vuescroll
  },
  props: {
    ops: {
      type: Object,
      default: null
    }
  },
  data() {
    return {}
  },
  computed: {
    newOps() {
      let res = null
      if (this.ops) {
        res = _.merge({}, defaultOps, this.ops)
      } else {
        res = defaultOps
      }
      return res
    }
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
