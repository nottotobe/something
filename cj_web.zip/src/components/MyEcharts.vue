<template>
  <div :class="`my_echarts ${uuid}`" ref="uuid"></div>
</template>

<script>
import * as echarts from 'echarts'
import ResizeListener from 'element-resize-detector'
import EventBus from '@/utils/eventBus'
import { setSession, getLocal } from '@/utils/storage'
import { mapMutations } from 'vuex'
export default {
  name: 'MyEcharts',
  props: {
    uuid: {
      type: String,
      required: true
    },
    uuoptions: {
      type: Object,
      required: true
    },
    timeRang: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      myChart: null
    }
  },
  watch: {
    uuoptions() {
      this.myChart.setOption(this.uuoptions)
    }
  },
  mounted() {
    // 基于准备好的dom，初始化echarts实例
    this.myChart = echarts.init(this.$refs.uuid)
    // 绘制图表
    this.myChart.setOption(this.uuoptions)

    this.myChart.on('click', params => {
      const menuList = getLocal('menuList')
      let par
      menuList.forEach(item => {
        if (item.name === '工单处理') {
          par = item.children[0].explain
        }
      })
      this.$router.push({
        path: '/ticketDataExcute',
        query: par ? { isAdmin: par } : {}
      })
      this.saveNavState('/ticketDataExcute')
      setSession('subMenuIndex', 3)
      setTimeout(() => {
        EventBus.$emit('satisticsEnter', params.name, params.seriesName, this.timeRang)
      }, 800)
    })

    window.addEventListener('resize', this.handleWindowResize)
    this.addChartResizeListener()
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleWindowResize)
  },
  methods: {
    ...mapMutations(['saveNavState']),

    /**
     * 对chart元素尺寸进行监听，当发生变化时同步更新echart视图
     */
    addChartResizeListener() {
      const instance = ResizeListener({
        strategy: 'scroll',
        callOnAdd: true
      })

      instance.listenTo(this.$el, () => {
        if (!this.myChart) return
        this.myChart.resize()
      })
    },
    /**
     * 当窗口缩放时，echart动态调整自身大小
     */
    handleWindowResize() {
      if (!this.myChart) return
      this.myChart.resize()
    }
  }
}
</script>

<style scoped lang="less">
.my_echarts {
  width: 100%;
  height: 100%;
}
</style>
