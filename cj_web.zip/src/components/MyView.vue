<template>
  <div>
    <div v-if="viewList.length > 0">
      <el-tag
        v-for="(item, index) in viewList"
        effect="dark"
        type="info"
        :key="index"
        class="tag_box"
        >{{ item.name }}</el-tag
      >
    </div>
    <div v-else>
      <el-empty :image-size="100"> </el-empty>
    </div>
    <el-row class="formBtn">
      <el-button @click="$emit('closeView')" round>返 回</el-button>
    </el-row>
  </div>
</template>

<script>
export default {
  name: 'MyView',
  props: {
    viewList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less">
.tag_box {
  font-size: 20px;
  margin-right: 20px;
  margin-bottom: 10px;
}
</style>
