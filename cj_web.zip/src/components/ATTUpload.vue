<template>
  <el-upload
    ref="uploadRef"
    action="#"
    :http-request="goUpload"
    :on-remove="uploadRemove"
    :before-upload="uploadBefore"
    :on-preview="uploadPreview"
    :file-list="uploadList"
    :disabled="unloadDis"
    accept=".zip,.rar,.doc,.xls"
    :class="className"
  >
    <el-button size="small" type="primary" v-if="!unloadDis">点击上传</el-button>
  </el-upload>
</template>

<script>
import { upload } from '@/api/user'
export default {
  name: 'ATTUpload',
  data() {
    return {
      successUpList: []
    }
  },
  props: {
    uploadList: {
      type: Array,
      default: () => {
        return []
      }
    },
    unloadDis: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    className() {
      if (this.unloadDis) {
        return 'classDis'
      } else {
        return ''
      }
    }
  },
  mounted() {
    this.imgSrcListInit()
  },
  watch: {
    uploadList(newValue, oldValue) {
      this.imgSrcListInit()
    }
  },
  methods: {
    // 初始化时imgSrcList赋值
    imgSrcListInit() {
      if (this.uploadList.length > 0 && !this.unloadDis) {
        this.uploadList.forEach(item => {
          this.successUpList.push(item)
        })
      }
    },

    // 上传
    async goUpload(v) {
      const fd = new FormData()
      fd.append('name', v.file.name)
      fd.append('file', v.file)
      const res = await upload(fd)
      res.data.obj.uid = v.file.uid
      this.successUpList.push(res.data.obj)
    },

    // 文件上传之前
    uploadBefore(file) {
      const isLt20M = file.size / 1024 / 1024 < 20
      if (!isLt20M) {
        this.$message.warning('上传的附件不能超过20M')
        return false
      }
    },

    // 文件列表移除文件时的钩子
    uploadRemove(file, fileList) {
      this.successUpList = this.successUpList.filter(item => {
        return item.uid !== file.uid
      })
    },

    // 点击文件列表中已上传的文件时的钩子
    uploadPreview(file) {
      if (file.url) {
        var a = document.createElement('a')
        a.href = file.url
        a.download = file.name
        a.click()
      }
    },

    // 清空上传列表
    clear() {
      this.$refs.uploadRef.clearFiles()
      this.successUpList = []
    }
  }
}
</script>

<style scoped lang="less">
.classDis {
  /deep/ .el-upload--text {
    display: none;
  }
  /deep/ .el-upload-list__item-status-label {
    display: none !important;
  }
}
</style>
