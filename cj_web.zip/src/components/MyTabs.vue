<template>
  <div>
    <div
      class="exportDomain ignore"
      v-if="exportDomainFlag"
      @click="$refs.exportDomainDia.dialogVisible = true"
    >
      <span>导出域</span>
      <i class="el-icon-s-tools"></i>
    </div>
    <el-tabs
      v-model="newEditableTabsValue"
      type="card"
      @tab-remove="removeWorkTab"
      class="publicTabs"
    >
      <el-tab-pane name="1">
        <span slot="label"
          >{{ tabTitle }} <i :class="tabIcon + ' tabIcon'" @click="collapseWorkTab"></i
        ></span>
        <collapse-transition>
          <div v-show="collapseFlag" class="collapseForm">
            <slot name="collapseTab"></slot>
          </div>
        </collapse-transition>

        <slot></slot>
      </el-tab-pane>

      <slot name="customTab"></slot>
    </el-tabs>

    <My-dialog
      :title="'导出域设置'"
      :className="'publicNDialog'"
      ref="exportDomainDia"
      :width="'40%'"
    >
      <Export-domain @closeDialog="$refs.exportDomainDia.dialogVisible = false" />
    </My-dialog>
  </div>
</template>

<script>
// fade/zoom 等
import 'element-ui/lib/theme-chalk/base.css'
// collapse 展开折叠
import CollapseTransition from 'element-ui/lib/transitions/collapse-transition'
import { mapState, mapMutations } from 'vuex'
import ExportDomain from '../views/query/components/ExportDomain'
export default {
  name: 'MyTabs',
  components: {
    CollapseTransition,
    ExportDomain
  },
  props: {
    tabTitle: {
      type: String,
      default: '这是一个标题'
    },
    editableTabs: {
      type: Array,
      default: () => []
    },
    editableTabsFlag: {
      type: String,
      default: ''
    },
    exportDomainFlag: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      tabIcon: 'el-icon-arrow-down',
      collapseFlag: true,
      editableTabsValue: '1'
    }
  },
  computed: {
    ...mapState({
      queryTabsValue: state => state.CWork.queryTabsValue,
      disposeTabsValue: state => state.CKnowledge.disposeTabsValue
    }),
    newEditableTabsValue: {
      get() {
        if (this.editableTabsFlag === 'query') {
          return this.queryTabsValue
        } else if (this.editableTabsFlag === 'dispose') {
          return this.disposeTabsValue
        } else {
          return this.editableTabsValue
        }
      },
      set(newValue) {
        if (this.editableTabsFlag === 'query') {
          this.giveWorkTab(newValue)
        } else if (this.editableTabsFlag === 'dispose') {
          this.giveKnowledgeTab(newValue)
        }
      }
    }
  },
  mounted() {},
  methods: {
    ...mapMutations('CWork', ['giveWorkTab']),
    ...mapMutations('CKnowledge', ['giveKnowledgeTab']),

    // 折叠标签
    collapseWorkTab() {
      if (this.newEditableTabsValue !== '1') return
      this.collapseFlag = !this.collapseFlag
      if (this.collapseFlag) {
        this.tabIcon = 'el-icon-arrow-down'
      } else {
        this.tabIcon = 'el-icon-arrow-right'
      }
    },

    // 移出新建工单标签
    removeWorkTab(targetName) {
      const tabs = this.editableTabs
      let activeName = this.newEditableTabsValue
      if (activeName === targetName) {
        tabs.forEach((tab, index) => {
          if (tab.name === targetName) {
            const nextTab = tabs[index + 1] || tabs[index - 1]
            if (nextTab) {
              activeName = nextTab.name
            } else {
              activeName = '1'
            }
          }
        })
      }
      if (this.editableTabsFlag === 'query') {
        this.giveWorkTab(activeName)
      } else if (this.editableTabsFlag === 'dispose') {
        this.giveKnowledgeTab(activeName)
      } else {
        this.editableTabsValue = activeName
      }
      this.$emit('filterEditableTabs', tabs, targetName)
    }
  }
}
</script>

<style scoped lang="less">
.exportDomain.ignore {
  position: absolute;
  top: 10px;
  right: 40px;
  color: #5b81ff;
  cursor: pointer;
  z-index: 99;
  user-select: none;
  i {
    margin-left: 5px;
    vertical-align: middle;
  }
}
</style>
