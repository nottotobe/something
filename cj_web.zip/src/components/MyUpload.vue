<template>
  <el-upload
    ref="uploadRef"
    action="#"
    list-type="picture-card"
    :on-change="uploadChange"
    :on-remove="uploadRemove"
    :on-success="uploadSuccess"
    :on-error="uploadError"
    :before-upload="uploadBefore"
    :limit="6"
    :on-exceed="unloadExceed"
    :file-list="uploadList"
    :http-request="goUpload"
    accept=".mp4,.jpg,.png,.jpeg"
    :disabled="unloadDis"
    :class="className"
  >
    <!-- <div slot="tip" class="el-upload__tip" v-if="!unloadDis">
      最多上传6张，大小不能超过10M。图片支持jpg、png、jpeg格式，视频支持MP4格式
    </div> -->
    <i class="el-icon-plus"></i>
    <div slot="file" slot-scope="{ file }" class="upload_box">
      <div
        v-if="
          file.raw
            ? file.raw.type.indexOf('image') !== -1
            : '.jpg .png .jpeg'.indexOf(file.imageType) !== -1
        "
      >
        <el-image
          class="el-upload-list__item-thumbnail"
          :src="file.url ? file.url : file.imageUri"
          alt=""
          :preview-src-list="imgSrcList"
          fit="contain"
          :ref="`previewImg${file.uid}`"
        />
        <span class="el-upload-list__item-actions">
          <span class="el-upload-list__item-preview" @click="handlePictureCardPreview(file)">
            <i class="el-icon-zoom-in"></i>
          </span>
          <span class="el-upload-list__item-delete" @click="handleRemove(file)" v-if="!unloadDis">
            <i class="el-icon-delete"></i>
          </span>
        </span>
      </div>
      <div
        v-if="
          file.raw ? file.raw.type.indexOf('video') !== -1 : '.mp4'.indexOf(file.imageType) !== -1
        "
      >
        <video
          class="el-upload-list__item-thumbnail"
          :src="file.url ? file.url : file.imageUri"
        ></video>
        <span class="el-upload-list__item-actions">
          <span class="el-upload-list__item-preview" @click="showVideo(file)">
            <i class="el-icon-video-play"></i>
          </span>
          <span class="el-upload-list__item-delete" @click="handleRemove(file)" v-if="!unloadDis">
            <i class="el-icon-delete"></i>
          </span>
        </span>
      </div>
    </div>
  </el-upload>
</template>

<script>
import { upload } from '@/api/user'
export default {
  name: 'MyUpload',
  props: {
    uploadList: {
      type: Array,
      default: () => {
        return []
      }
    },
    unloadDis: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      imgSrcList: [],
      successUpList: []
    }
  },
  mounted() {
    this.imgSrcListInit()
  },
  watch: {
    uploadList(newValue, oldValue) {
      this.imgSrcListInit()
    }
  },
  computed: {
    className() {
      if (this.unloadDis) {
        return 'classDis'
      } else {
        return ''
      }
    }
  },
  methods: {
    // 初始化时imgSrcList赋值
    imgSrcListInit() {
      this.imgSrcList = []
      this.uploadList.forEach(item => {
        if ('.jpg .png .jpeg'.indexOf(item.imageType) !== -1) {
          this.imgSrcList.push(item.imageUri)
        }
        if (this.unloadDis) return
        this.successUpList.push(item)
      })
    },
    // 文件上传之前
    uploadBefore(file) {
      const isLt10M = file.size / 1024 / 1024 < 10
      if (!isLt10M) {
        this.$message.warning('上传图片或者视频大小不能超过10M')
        return false
      }
    },
    // 文件上传
    async goUpload(v) {
      const fd = new FormData()
      fd.append('name', v.file.name)
      fd.append('file', v.file)
      const res = await upload(fd)
      res.data.obj.uid = v.file.uid
      this.successUpList.push(res.data.obj)
    },
    // 文件上传成功时的钩子
    uploadSuccess(response, file, fileList) {
      if (file.raw.type.indexOf('image') !== -1) {
        this.imgSrcList.push(file.url)
      }
    },
    // 文件超出个数限制时的钩子
    unloadExceed(file, fileList) {
      this.$message({
        message: '最多上传六张图片',
        type: 'warning'
      })
    },
    // 点击播放视频按钮
    showVideo(file) {
      const url = file.url ? file.url : file.imageUri
      window.open(url)
    },
    // 点击预览按钮
    handlePictureCardPreview(file) {
      this.$refs[`previewImg${file.uid}`].showViewer = true
    },
    // 点击删除按钮
    handleRemove(file) {
      this.$refs.uploadRef.handleRemove(file)
    },
    // 文件列表移除文件时的钩子
    uploadRemove(file, fileList) {
      this.imgSrcList = this.imgSrcList.filter(item => {
        return item !== file.url
      })
      this.successUpList = this.successUpList.filter(item => {
        return item.uid !== file.uid
      })
    },
    // 文件上传失败时的钩子
    uploadError(file, fileList) {},
    // 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
    uploadChange(file, fileList) {},
    // 清空上传列表
    clear() {
      this.$refs.uploadRef.clearFiles()
      this.imgSrcList = []
      this.successUpList = []
    }
  }
}
</script>

<style scoped lang="less">
.upload_box {
  width: 100%;
  height: 100%;
}
.classDis {
  /deep/ .el-upload.el-upload--picture-card {
    display: none;
  }
}
</style>
