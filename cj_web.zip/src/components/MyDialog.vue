<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    :class="className"
    :fullscreen="fullscreen"
    :width="width"
    :close-on-click-modal="false"
    :append-to-body="appendBody"
  >
    <div v-if="dialogVisible">
      <slot></slot>
    </div>
  </el-dialog>
</template>

<script>
export default {
  name: 'MyDialog',
  props: {
    title: {
      type: String,
      default: '标题'
    },
    className: {
      type: String,
      default: 'publicFDialog'
    },
    width: {
      type: String,
      default: '40%'
    },
    appendBody: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    fullscreen() {
      let flag = null
      if (this.className === 'publicFDialog') {
        flag = true
      } else {
        flag = false
      }
      return flag
    }
  },
  data() {
    return {
      dialogVisible: false
    }
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
