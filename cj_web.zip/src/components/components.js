import Vue from 'vue'
import MyCollapse from './MyCollapse.vue'
import MyDialog from './MyDialog.vue'
import MyTabs from './MyTabs.vue'

Vue.component('MyCollapse', MyCollapse)
Vue.component('MyDialog', MyDialog)
Vue.component('MyTabs', MyTabs)
