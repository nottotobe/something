<template>
  <el-collapse :value="unfold" :class="'publicTitle ' + otherClass">
    <el-collapse-item :title="title" name="1">
      <slot></slot>
    </el-collapse-item>
  </el-collapse>
</template>

<script>
export default {
  name: 'MyCollapse',
  props: {
    title: {
      type: String,
      default: '这是一个标题'
    },
    unfold: {
      type: Array,
      default: () => ['1']
    },
    otherClass: {
      type: String,
      default: ''
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
