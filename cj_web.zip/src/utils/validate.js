/**
 * Created by PanJiaChen on 16/11/18.
 */

/**
 * @param {string} path
 * @returns {Boolean}
 */
/*
校验手机号
*/
export function validMobile(rule, value, callback) {
  if (!value) return
  const reg = /^1[356789]\d{9}$/
  if (!reg.test(value)) {
    callback(new Error('手机号格式错误'))
  } else {
    callback()
  }
}

/*
校验邮箱
*/
export function validEmail(rule, value, callback) {
  if (!value) return
  const reg = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/
  if (!reg.test(value)) {
    callback(new Error('邮箱格式错误'))
  } else {
    callback()
  }
}

/*
校验密码
*/
export function validPassword(rule, value, callback) {
  if (!value) return
  const reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z\\W]{6,18}$/
  if (!reg.test(value)) {
    callback(new Error('密码必须包含字母和数字，且在6~18位之间'))
  } else {
    callback()
  }
}

/*
校验非汉字
*/
export function validChinese(rule, value, callback) {
  if (!value) return
  const reg = /[\u4E00-\u9FA5]/g
  if (reg.test(value)) {
    callback(new Error('不可以输入中文'))
  } else {
    callback()
  }
}
