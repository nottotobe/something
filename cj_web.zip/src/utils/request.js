import axios from 'axios'
import qs from 'qs'
import router from '../router'
import store from '../store'
import { Message } from 'element-ui'
import { removeLocal } from '@/utils/storage'

let BASE_PATH = ''
if (process.env.NODE_ENV === 'development') {
  BASE_PATH = '/oam'
} else {
  BASE_PATH = '/oam'
}

const request = axios.create({
  baseURL: BASE_PATH, // 请求的基本路径
  // `timeout` 指定请求超时的毫秒数(0 表示无超时时间)
  // 如果请求话费了超过 `timeout` 的时间，请求将被中断
  timeout: 200000
})

// 添加请求拦截器
request.interceptors.request.use(
  function(config) {
    // 在发送请求之前做些什么
    if (config.method === 'get') {
      config.paramsSerializer = function(params) {
        return qs.stringify(params, { arrayFormat: 'repeat' })
      }
    }
    return config
  },
  function(error) {
    // 对请求错误做些什么
    return Promise.reject(error)
  }
)

// 添加响应拦截器
request.interceptors.response.use(
  function(response) {
    // 对响应数据做点什么
    return response
  },
  function(error) {
    if (error.message && error.message.includes('timeout')) {
      Message.error('请求超时')
    }
    // 对响应错误做点什么
    if (error.response.status) {
      switch (error.response.status) {
        case 401:
          router.replace('/login')
          removeLocal('isUser')
          store.commit('deleteNavState')
          Message.error('登陆过期，请重新登陆')
          window.location.reload()
          break
        case 404:
          Message.error('请求不存在')
          break
        case 400:
          Message.error('请求错误')
          break
        case 500:
          Message.error('服务器内部错误')
          break
        default:
          Message.error(error.response.data.msg)
          break
      }
    }
    return Promise.reject(error)
  }
)

export default request
