import request from '@/utils/request'

// 登陆
export const login = data => {
  return request({
    method: 'post',
    url: '/doLogin',
    data
  })
}

// 注册
export const register = data => {
  return request({
    method: 'post',
    url: '/register/add',
    data
  })
}

// 忘记密码
export const forgetPWD = data => {
  return request({
    method: 'put',
    url: '/register/edit',
    data
  })
}

// 手机验证码获取
export const getPhoneCode = data => {
  return request({
    method: 'get',
    url: '/verifyCode',
    params: data
  })
}

// 注销
export const logout = () => {
  return request({
    method: 'get',
    url: '/logout'
  })
}

// 获取侧边栏数据
export const getMenuList = () => {
  return request({
    method: 'get',
    url: '/userMenu'
  })
}

// 获取工单数据
export const getWorkData = data => {
  return request({
    method: 'get',
    url: '/ticket/query',
    params: data
  })
}

// 新建工单数据
export const addWorkData = data => {
  return request({
    method: 'post',
    url: '/ticket/exec/add',
    data
  })
}

// 查看工单详情
export const queryWorkData = data => {
  return request({
    method: 'get',
    url: '/ticket/queryDetail',
    params: {
      ticketId: data
    }
  })
}

// 回复工单
export const replyWork = data => {
  return request({
    method: 'post',
    url: '/ticket/exec/reply',
    data
  })
}

// 中止工单
export const suspendWork = data => {
  return request({
    method: 'put',
    url: '/ticket/enable',
    data
  })
}

// 反馈工单
export const feedbackWork = data => {
  return request({
    method: 'post',
    url: '/ticket/resubmit',
    data
  })
}

// 工单添加标签
export const addWorkTag = data => {
  return request({
    method: 'post',
    url: '/ticket/label/add',
    data
  })
}

// 工单批量添加标签
export const batchAddWorkTag = data => {
  return request({
    method: 'post',
    url: '/label/adds',
    data
  })
}

// 工单评价
export const evalWork = data => {
  return request({
    method: 'post',
    url: '/ticket/detail/eval',
    data
  })
}

// 匹配知识库时查询知识数据
export const matchKnowledgeData = data => {
  return request({
    method: 'get',
    url: '/knowledge/detail/matching',
    params: data
  })
}

// 知识评价
export const evalKnowledge = data => {
  return request({
    method: 'post',
    url: '/knowledge/detail/eval',
    data
  })
}

// 上传图片
export const upload = data => {
  return request({
    method: 'post',
    url: '/upload',
    data,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  })
}

// 获取问题平台，类型，程度
export const getClassifyData = data => {
  return request({
    method: 'get',
    url: '/types/query',
    params: data
  })
}

// 新增工单分类的数据
export const addClassifyData = data => {
  return request({
    method: 'post',
    url: '/types/add',
    data
  })
}

// 修改工单分类的数据
export const editClassifyData = data => {
  return request({
    method: 'put',
    url: '/types/edit',
    data
  })
}

// 工单分类模块中的启用、停用
export const classifyReset = data => {
  return request({
    method: 'put',
    url: '/types/enable',
    data
  })
}

// 获取预警管理的数据
export const getWarnData = data => {
  return request({
    method: 'get',
    url: '/types/ticketWarn/query',
    params: data
  })
}

// 新增预警管理的数据
export const addWarnData = data => {
  return request({
    method: 'post',
    url: '/types/ticketWarn/add',
    data
  })
}

// 修改预警管理的数据
export const editWarnData = data => {
  return request({
    method: 'put',
    url: '/types/ticketWarn/edit',
    data
  })
}

// 预警管理的启用、停用
export const warnReset = data => {
  return request({
    method: 'put',
    url: '/types/ticketWarn/enable',
    data
  })
}

// 工单统计数据查询
export const getStatisticData = data => {
  return request({
    method: 'get',
    url: '/ticket/statistic',
    params: data
  })
}

// 跟踪记录查询
export const getTrackData = data => {
  return request({
    method: 'get',
    url: '/ticket/track/query',
    params: data
  })
}

// 工单跟踪
export const trackData = data => {
  return request({
    method: 'post',
    url: '/ticket/track/add',
    data
  })
}

// 取消跟踪
export const trackCancel = data => {
  return request({
    method: 'put',
    url: '/ticket/track/cancel',
    data
  })
}

// 转交记录查询
export const getDeliverData = data => {
  return request({
    method: 'get',
    url: '/ticket/transfer/query',
    params: data
  })
}

// 工单转交
export const deliverData = data => {
  return request({
    method: 'post',
    url: '/ticket/transfer/add',
    data
  })
}

// 工单取回
export const takeBackData = data => {
  return request({
    method: 'put',
    url: '/ticket/transfer/retrieve',
    data
  })
}

// 机构数据查询
export const getDptData = () => {
  return request({
    method: 'get',
    url: '/dpt/query'
  })
}

// 轨迹图接口
export const getLocusCircleData = data => {
  return request({
    method: 'get',
    url: '/ticket/trail/query',
    params: {
      ticketId: data
    }
  })
}

// 消息列表查询
export const getMessageData = () => {
  return request({
    method: 'get',
    url: '/system/msg/query/all'
  })
}

// 新建消息
export const addMessageData = data => {
  return request({
    method: 'post',
    url: '/system/msg/add',
    data
  })
}

// 修改消息
export const editMessageData = data => {
  return request({
    method: 'put',
    url: '/system/msg/edit',
    data
  })
}

// 删除消息
export const delMessageData = data => {
  return request({
    method: 'put',
    url: '/system/msg/delete',
    data
  })
}

// 消息的启用、停用
export const messageReset = data => {
  return request({
    method: 'put',
    url: '/system/msg/enabled',
    data
  })
}

// 全部角色查询
export const getAllRoleData = () => {
  return request({
    method: 'get',
    url: '/role/query/all'
  })
}

// 轮播图消息查询
export const getCarouselData = () => {
  return request({
    method: 'get',
    url: '/system/msg/query/person'
  })
}

// 标签查询
export const getTagData = data => {
  return request({
    method: 'get',
    url: '/label/query',
    params: data
  })
}

// 新增标签
export const addTagData = data => {
  return request({
    method: 'post',
    url: '/label/add',
    data
  })
}

// 修改标签
export const editTagData = data => {
  return request({
    method: 'put',
    url: '/label/edit',
    data
  })
}

// 审核标签
export const reviewTagData = data => {
  return request({
    method: 'put',
    url: '/label/exam',
    data
  })
}

// 删除标签
export const delTagData = data => {
  return request({
    method: 'put',
    url: '/label/delete',
    data
  })
}

// 知识分类查询
export const getKnowledgeClass = data => {
  return request({
    method: 'get',
    url: '/knowledge/main/query/all',
    params: data
  })
}

// 新增知识分类
export const addKnowledgeClass = data => {
  return request({
    method: 'post',
    url: '/knowledge/main/add',
    data
  })
}

// 修改知识分类
export const editKnowledgeClass = data => {
  return request({
    method: 'put',
    url: '/knowledge/main/edit',
    data
  })
}

// 删除知识分类
export const delKnowledgeClass = data => {
  return request({
    method: 'put',
    url: '/knowledge/main/delete',
    data
  })
}

// 知识数据查询
export const getKnowledgeData = data => {
  return request({
    method: 'get',
    url: '/knowledge/detail/query',
    params: data
  })
}

// 新增知识数据
export const addKnowledgeData = data => {
  return request({
    method: 'post',
    url: '/knowledge/detail/add',
    data
  })
}

// 修改知识数据
export const editKnowledgeData = data => {
  return request({
    method: 'put',
    url: '/knowledge/detail/edit',
    data
  })
}

// 删除知识数据
export const delKnowledgeData = data => {
  return request({
    method: 'put',
    url: '/knowledge/detail/delete',
    data
  })
}

// 审核知识数据
export const reviewKnowledgeData = data => {
  return request({
    method: 'put',
    url: '/knowledge/detail/exam',
    data
  })
}

// 客服接口
export const getCustomer = () => {
  return request({
    method: 'get',
    url: '/customer'
  })
}

// 获取用户数据
export const getUserData = data => {
  return request({
    method: 'get',
    url: '/user/getUser',
    params: data
  })
}

// 新建用户
export const addUserData = data => {
  return request({
    method: 'post',
    url: '/user/add',
    data
  })
}

// 修改用户
export const editUserData = data => {
  return request({
    method: 'put',
    url: '/user/edit',
    data
  })
}

// 审批用户
export const userApprove = data => {
  return request({
    method: 'put',
    url: '/user/exam',
    data
  })
}

// 用户的启用、停用
export const userReset = data => {
  return request({
    method: 'put',
    url: '/user/enable',
    data
  })
}

// 权限复制
export const rightsCopy = data => {
  return request({
    method: 'post',
    url: '/user/copy',
    data
  })
}

// 角色查询
export const getRoleData = data => {
  return request({
    method: 'get',
    url: '/role/query',
    params: data
  })
}

// 新建角色
export const addRoleData = data => {
  return request({
    method: 'post',
    url: '/role/add',
    data
  })
}

// 修改角色
export const editRoleData = data => {
  return request({
    method: 'put',
    url: '/role/edit',
    data
  })
}

// 修改角色
export const roleReset = data => {
  return request({
    method: 'put',
    url: '/role/enable',
    data
  })
}

// 新建机构
export const addDptData = data => {
  return request({
    method: 'post',
    url: '/dpt/add',
    data
  })
}

// 修改机构
export const editDptData = data => {
  return request({
    method: 'put',
    url: '/dpt/edit',
    data
  })
}

// 删除机构
export const delDptData = data => {
  return request({
    method: 'put',
    url: '/dpt/delete',
    data
  })
}

// 机构中的启用、停用
export const dptReset = data => {
  return request({
    method: 'put',
    url: '/dpt/enable',
    data
  })
}

// 获取侧边栏数据
export const getAllMenuList = () => {
  return request({
    method: 'get',
    url: '/allMenu'
  })
}

// 个人中心查询
export const getPersonData = () => {
  return request({
    method: 'get',
    url: '/person/query'
  })
}

// 修改手机号
export const editMobile = data => {
  return request({
    method: 'put',
    url: '/person/edit/mobile',
    data
  })
}

// 获取验证码
export const getPersonCode = data => {
  return request({
    method: 'get',
    url: '/person/verifyCode',
    params: {
      mobile: data
    }
  })
}

// 修改密码
export const editPassword = data => {
  return request({
    method: 'put',
    url: '/person/edit/password',
    data
  })
}

// 修改邮箱
export const editEmail = data => {
  return request({
    method: 'put',
    url: '/person/edit/email',
    data
  })
}

// 获取验证码图片
export const getCodeImg = () => {
  return request({
    method: 'get',
    url: '/code',
    responseType: 'blob'
  })
}

// 修改头像
export const editAvatar = data => {
  return request({
    method: 'put',
    url: '/person/edit/avatar',
    data
  })
}

// 下载模板
export const templateDownload = () => {
  return request({
    method: 'get',
    url: '/user/download/template'
  })
}

// 上传模板
export const templateUpload = data => {
  return request({
    method: 'post',
    url: '/user/upload/template',
    data,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  })
}

// 导入Excel
export const ExcelImport = data => {
  return request({
    method: 'post',
    url: '/user/import',
    data,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  })
}

// 批量新建用户
export const batchNewUsers = data => {
  return request({
    method: 'post',
    url: '/user/batch/add',
    data
  })
}

// 获取所有导出域
export const getExportDomain = data => {
  return request({
    method: 'get',
    url: '/export/config',
    params: {
      type: data
    }
  })
}

// 获取当前用户导出域
export const getUserDomain = data => {
  return request({
    method: 'get',
    url: '/export/config/user',
    params: {
      type: data
    }
  })
}

// 修改当前用户导出域
export const editUserDomain = data => {
  return request({
    method: 'post',
    url: '/export/config/edit',
    data
  })
}

// 经办人选择列表
export const getHandlerData = () => {
  return request({
    method: 'get',
    url: '/user/query/exec'
  })
}
