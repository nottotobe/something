import Vue from 'vue'
import Vuex from 'vuex'
import { setSession, removeSession } from '@/utils/storage'
import { getCarouselData } from '@/api/user'
import CWork from './modules/createWork'
import CKnowledge from './modules/createKnowledge'
Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    activePath: '',
    carouselList: []
  },
  mutations: {
    // 保存侧边栏的状态
    saveNavState(state, value) {
      state.activePath = value
      setSession('activePath', value)
    },
    // 清楚侧边栏的状态
    deleteNavState(state) {
      state.activePath = null
      removeSession('activePath')
    },
    // 轮播图
    carouselData(state, res) {
      state.carouselList = res
    }
  },
  actions: {
    async getCarouselData(context) {
      const res = await getCarouselData()
      context.commit('carouselData', res.data.obj)
    }
  },
  modules: {
    CWork,
    CKnowledge
  }
})
