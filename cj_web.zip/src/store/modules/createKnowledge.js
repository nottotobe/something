import { Message } from 'element-ui'

const state = {
  disposeTabsValue: '1',
  disposeTabs: []
}

const mutations = {
  // 生成知识
  createKnowledgeTab(state, obj) {
    const workFlag = state.disposeTabs.some(item => {
      return item.name === '2'
    })
    if (workFlag) return Message.warning('请先完成当前的生成知识标签')
    state.disposeTabs.push({
      title: '生成知识',
      name: '2',
      type: 'CKnowledge',
      flag: obj.flag,
      rows: obj.rows
    })
    state.disposeTabsValue = '2'
  },
  // 给当前标签页赋值
  giveKnowledgeTab(state, value) {
    state.disposeTabsValue = value
  },
  // 删除后刷新标签数组
  delKnowledgeTab(state, value) {
    state.disposeTabs = value
  }
}

export default {
  namespaced: true,
  state,
  mutations
}
