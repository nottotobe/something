import { Message } from 'element-ui'

const state = {
  queryTabsValue: '1',
  queryTabs: []
}

const mutations = {
  // 新建工单标签
  createWorkTab(state) {
    const workFlag = state.queryTabs.some(item => {
      return item.name === '2'
    })
    if (workFlag) return Message.warning('请先完成当前的新建工单标签')
    state.queryTabs.push({
      title: '新建工单',
      name: '2',
      type: 'NewWork'
    })
    state.queryTabsValue = '2'
  },
  // 给当前标签页赋值
  giveWorkTab(state, value) {
    state.queryTabsValue = value
  },
  // 删除后刷新标签数组
  delWorkTab(state, value) {
    state.queryTabs = value
  }
}

export default {
  namespaced: true,
  state,
  mutations
}
