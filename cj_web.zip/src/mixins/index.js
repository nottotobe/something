// 一些公共数据和操作
import { getClassifyData, getDptData } from '@/api/user'

// 表格相关
export const tableMix = {
  data() {
    return {
      tableData: [], // 表格数据
      selectedRows: [], // 表格单行数据
      clickFlag: null // 单双击判断器
    }
  },
  methods: {
    // 单击一行勾选或取消复选框
    rowClick(row, column, event, flag) {
      // flag:有些不需要双击事件的
      if (flag) {
        if (this.clickFlag) {
          // 取消上次延时未执行的方法
          this.clickFlag = clearTimeout(this.clickFlag)
        }
        this.clickFlag = setTimeout(() => {
          row.tableFlag = !row.tableFlag
          this.$refs.tableRef.toggleRowSelection(row, row.tableFlag)
        }, 300) // 延时300毫秒执行
      } else {
        row.tableFlag = !row.tableFlag
        this.$refs.tableRef.toggleRowSelection(row, row.tableFlag)
      }
    },

    // 选中或取消复选框的回调
    selectionChange(selection) {
      this.selectedRows = selection
    },

    // 排序
    sortChange(par, met) {
      if (par.order === 'ascending') {
        this.filterForm.sortField = par.prop
        this.filterForm.sortType = '1'
        met()
      } else if (par.order === 'descending') {
        this.filterForm.sortField = par.prop
        this.filterForm.sortType = '0'
        met()
      } else {
        this.filterForm.sortField = ''
        this.filterForm.sortType = ''
        met()
      }
    },

    // 表单重置（基本与表格绑定在一起）
    resetForm(formName) {
      this.$refs[formName].resetFields()
    }
  }
}

// 下拉框相关（问题平台，问题类型，紧急程度）
export const selectMix = {
  data() {
    return {
      platformList: [], // 问题平台
      typeList: [], // 问题类型
      urgentList: [] // 紧急程度
    }
  },
  mounted() {
    this.getPTUData()
  },
  methods: {
    // 获取下拉数据
    async getPTUData() {
      const platform = await getClassifyData({
        item: 'platform'
      })
      this.platformList = platform.data.obj.typesList
      const type = await getClassifyData({
        item: 'type'
      })
      this.typeList = type.data.obj.typesList
      const urgent = await getClassifyData({
        item: 'urgent'
      })
      this.urgentList = urgent.data.obj.typesList
    }
  },
  computed: {
    newPlatformList() {
      return this.platformList.filter(item => {
        return item.status === '1'
      })
    },
    newTypeList() {
      return this.typeList.filter(item => {
        return item.status === '1'
      })
    },
    newUrgentList() {
      return this.urgentList.filter(item => {
        return item.status === '1'
      })
    }
  }
}

// 新增修改弹出框相关
export const addDiaMix = {
  data() {
    return {
      titleDia: '',
      flag: '',
      rows: {}
    }
  },
  methods: {
    addPublic(name, title) {
      this.$refs[name].dialogVisible = true
      this.titleDia = title
      this.flag = 'add'
    },

    editPublic(name, title) {
      if (this.selectedRows.length === 0) return this.$message.warning('请选择一条数据')
      if (this.selectedRows.length > 1) return this.$message.warning('只能勾选一条数据')
      this.$refs[name].dialogVisible = true
      this.titleDia = title
      this.flag = 'edit'
      this.rows = Object.assign({}, this.selectedRows[0])
    },

    closePublic(v, p, name) {
      if (v) {
        this.$refs[name].dialogVisible = false
      }
      if (p) return false
      return true
    }
  }
}

// 查看相关
export const viewMix = {
  data() {
    return {
      viewList: []
    }
  },
  methods: {
    viewTag(v) {
      this.viewList = v
      this.$refs.viewDia.dialogVisible = true
    },

    closeView() {
      this.$refs.viewDia.dialogVisible = false
    }
  }
}

// 获取机构相关
export const dptMix = {
  data() {
    return {
      dptCodeProps: {
        value: 'dptId',
        label: 'name',
        emitPath: false,
        checkStrictly: true,
        expandTrigger: 'hover'
      },
      dptCodeList: []
    }
  },
  mounted() {
    this.dptDataInit()
  },
  watch: {
    'filterForm.dptCode'(newVlaue, oldValue) {
      if (this.$refs.checkStrictlyRef) {
        this.$refs.checkStrictlyRef.dropDownVisible = false
      }
    }
  },
  methods: {
    // 获取机构数据
    async dptDataInit() {
      const res = await getDptData()
      if (res.data.status === 200) {
        this.dptCodeList = this.resetTreeData(this.getTreeData(res.data.obj))
      } else {
        this.$message.error(res.data.msg)
      }
    },

    getTreeData(data) {
      // for (var i = 0; i < data.length; i++) {
      //   if (data[i].status === '0') {
      //     const arr = []
      //     for (var j = 0; j < data.length; j++) {
      //       if (data[j].status === '0') {
      //         arr.push(j)
      //       }
      //     }
      //     for (var k = arr.length - 1; k >= 0; k--) {
      //       data.splice(arr[k], 1)
      //     }
      //   } else {
      //     this.getTreeData(data[i].children)
      //   }
      // }
      // 逆向删除，同上
      for (var i = data.length - 1; i >= 0; i--) {
        if (data[i].status === '0') {
          data.splice(i, 1)
        } else {
          this.getTreeData(data[i].children)
        }
      }

      return data
    },

    resetTreeData(data) {
      for (var i = 0; i < data.length; i++) {
        if ('children' in data[i]) {
          if (data[i].children.length < 1) {
            data[i].children = undefined
          } else {
            this.resetTreeData(data[i].children)
          }
        }
      }
      return data
    }
  }
}
