import Vue from 'vue'
import VueRouter from 'vue-router'
import { getLocal } from '@/utils/storage'

Vue.use(VueRouter)

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', name: 'login', component: () => import('@/views/login/Login') },
  { path: '/register', name: 'register', component: () => import('@/views/register/Register') },
  { path: '/password', name: 'password', component: () => import('@/views/password/Password') },
  {
    path: '/main',
    name: 'main',
    redirect: '/dashboard',
    component: () => import('@/views/layout/Main'),
    children: [
      {
        path: '/dashboard',
        name: 'dashboard',
        component: () => import('@/views/dashboard/Dashboard')
      },
      { path: '/message', name: 'message', component: () => import('@/views/message/Message') },
      {
        path: '/ticketDataAdd',
        name: 'GDxinjian',
        component: () => import('@/views/addWork/AddWork'),
        meta: {
          keepAlive: true
        }
      },
      {
        path: '/ticketDataQuery',
        name: 'GDchaxun',
        component: () => import('@/views/query/Query'),
        meta: {
          keepAlive: true
        }
      },
      {
        path: '/ticketDataStics',
        name: 'GDtongji',
        component: () => import('@/views/statistics/Statistics'),
        meta: {
          keepAlive: true
        }
      },
      {
        path: '/ticketDataExcute',
        name: 'GDchuli',
        component: () => import('@/views/dispose/Dispose'),
        meta: {
          keepAlive: true
        }
      },
      {
        path: '/dataTrackRecord',
        name: 'GDgenzong',
        component: () => import('@/views/track/Track')
      },
      {
        path: '/dataTransRecord',
        name: 'GDzhuangjiao',
        component: () => import('@/views/track/Deliver')
      },
      {
        path: '/typesPlatform',
        name: 'GDpingtai',
        component: () => import('@/views/classify/Classify')
      },
      {
        path: '/typesType',
        name: 'GDleixing',
        component: () => import('@/views/classify/Classify')
      },
      {
        path: '/typesUrgent',
        name: 'GDchengdu',
        component: () => import('@/views/classify/Classify')
      },

      {
        path: '/warningManager',
        name: 'GDyujing',
        component: () => import('@/views/classify/Warn')
      },
      {
        path: '/onlineService',
        name: 'GDkefu',
        component: () => import('@/views/customer/Customer')
      },
      {
        path: '/knowledgeType',
        name: 'GDzhishiku',
        component: () => import('@/views/knowledge/Knowledge')
      },
      {
        path: '/knowledgeData',
        name: 'GDzhishikushuju',
        component: () => import('@/views/knowledge/KnowledgeData'),
        meta: {
          keepAlive: true
        }
      },
      {
        path: '/labelManager',
        name: 'GDbiaoqian',
        component: () => import('@/views/knowledge/TagManage')
      },
      { path: '/userData', name: 'GDyonghu', component: () => import('@/views/user/User') },
      {
        path: '/permissionCopy',
        name: 'GDquanxian',
        component: () => import('@/views/user/Rights')
      },

      { path: '/roleData', name: 'GDjuese', component: () => import('@/views/baseData/RoleData') },
      { path: '/dptData', name: 'GDjigou', component: () => import('@/views/baseData/DptData') },
      {
        path: '/personManager',
        name: 'GDgerenzhongxin',
        component: () => import('@/views/person/Person')
      }
    ]
  }
]

const router = new VueRouter({
  routes
})

router.beforeEach(async (to, from, next) => {
  // to 表示将要访问的地址
  // from 表示从哪个页面路径跳转过来的
  // next 放行   next('/login') 强行跳转到登录页
  if (to.path === '/login') return next()
  if (to.path === '/register') return next()
  if (to.path === '/password') return next()
  // 获取token
  const isUser = getLocal('isUser')
  if (!isUser) return next('/login')
  next()
})

export default router
