let Client = require('ssh2-sftp-client');
const path = require('path')
const glob = require('glob')
let sftp = new Client();
const config = require('./ssh2.config.json')
const localPath = path.join(__dirname, config.localPath).replace(/\\/g, '/')
const remotePath = config.remotePath

sftp.connect({
    host: config.host,
    port: config.port,
    username: config.username,
    password: config.password
}).then(() => {
    console.log('连接成功');
    console.log('删除static');
    return sftp.rmdir(`${remotePath}`, true)
}).then(async () => {
    console.log('删除static成功');
    console.log('创建static中js,css,img,fonts文件');
    await sftp.mkdir(`${remotePath}`, true)
    await sftp.mkdir(`${remotePath}/static`, true)
    await sftp.mkdir(`${remotePath}/static/css`, true)
    await sftp.mkdir(`${remotePath}/static/img`, true)
    // await sftp.mkdir(`${remotePath}/static/fonts`, true)
    await sftp.mkdir(`${remotePath}/static/js`, true)
}).then(() => {
    console.log('创建static中js,css,img,fonts文件成功');

    const fileLiat = glob.sync(`${localPath}/**/*.{js,css,png,eot,woff,ttf,svg,gif,jpg,html,gz,ico}`)
    return Promise.all(
        fileLiat.map(file => {
            console.log(file);
            const remoteFile = file.replace(localPath, remotePath)
            return sftp.fastPut(file, remoteFile)
        })
    )
}).then(() => {
    console.log('成功');
    sftp.end()
}).catch((err) => {
    console.log(err.message, 'catch error');
    sftp.end()
});
