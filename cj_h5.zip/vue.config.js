const path = require('path')

function resolve(dir) {
  return path.join(__dirname, dir)
}

module.exports = {
  publicPath: process.env.VUE_APP_BASE_PATH,
  productionSourceMap: false,
  assetsDir: 'static',
  devServer: {
    proxy: {
      '/car': {
        target: 'https://muwtest.cjbx.com.cn:18881/',
        changeOrigin: true,
        pathRewrite: {
          '^/car': '/'
        }
      }
    },
    port: 5051,
    disableHostCheck: true
  },
  configureWebpack: config => {
    if (process.env.VUE_APP_MODE === 'development') {
      // 为开发环境修改配置...
    } else {
      // 为生产环境修改配置...
      // 去掉console
      config.optimization.minimizer[0].options.terserOptions.compress.drop_console = true
      // 去掉打包超过250kb的警告
      config.performance = {
        maxEntrypointSize: 10000000,
        maxAssetSize: 30000000,
        assetFilter: function(assetFilename) {
          return assetFilename.endsWith('.js')
        }
      }
    }
  },
  chainWebpack: config => {
    // 设置别名
    config.resolve.alias.set('@img', resolve('src/assets/images'))

    config.plugin('html').tap(args => {
      args[0].title = process.env.VUE_APP_TITLE
      return args
    })
  }
}
