import { getLocal } from '@/utils/storage'

// ios滑动异常处理
export const iosScroll = {
  data() {
    return {
      sticky: false,
      offsetTop: '',
      scrollTop: 0,
      currentVal: 0
    }
  },
  mounted() {
    window.addEventListener('scroll', this.scrollChange)
  },
  beforeDestroy() {
    window.removeEventListener('scroll', this.scrollChange)
  },
  methods: {
    // 解决ios下布局下问题
    scrollChange(e) {
      this.currentVal = this.scrollTop
      this.scrollTop = e.target.documentElement.scrollTop || e.target.body.scrollTop

      if (this.currentVal < this.scrollTop) {
        console.log(this.currentVal)
        console.log(this.scrollTop)
        // 滚动条下滑，实现下滑效果
        console.log('下滑')
        if (this.$refs.udrInfo) {
          this.$refs.udrInfo.changePo = ''
        }
      } else {
        console.log(this.currentVal)
        console.log(this.scrollTop)
        // 滚动条上滑，实现上滑效果
        console.log('上滑')
        if (this.$refs.udrInfo) {
          this.$refs.udrInfo.changePo = 'changePo'
        }
      }

      if (this.scrollTop <= 0 && this.sticky) {
        console.log('到头了')
        this.sticky = false
        this.offsetTop = ''
        if (this.$refs.udrInfo) {
          this.$refs.udrInfo.changePo = ''
        }
      }
      if (this.scrollTop > 0 && !this.sticky) {
        console.log('下滑')
        this.sticky = true
        this.offsetTop = '12.266667vw'
      }
    }
  }
}

// 下拉加载
export const onListLoad = {
  data() {
    return {
      udrList: [], // 列表数组
      listFlag: true // 列表显示与否
    }
  },
  methods: {
    // 获取下拉列表后的公共操作
    async publicLoad(method) {
      this.listFlag = true
      const res = await method(this.filterForm)
      console.log(res)
      if (res && res.status === 1) {
        // 精友车辆查询接口返回的数据格式不一样，这里做一下判断
        const result = res.data.Vehicle ? res.data.Vehicle : res.data
        if (result.length < this.filterForm.pageSize) {
          this.$refs.myList.finished = true
        }

        if (this.filterForm.pageNo === 1) {
          this.udrList = result
        } else {
          this.udrList = this.udrList.concat(result)
        }

        this.$refs.myList.loading = false
        this.$refs.myList.refreshing = false
      } else {
        if (this.filterForm.pageNo === 1) {
          this.listFlag = false
        } else {
          this.$refs.myList.finished = true
        }
      }
    },

    // 下拉加载的回调
    listLoad() {
      this.udrListInit().then(() => {
        this.filterForm.pageNo++
      })
    },

    // 上拉刷新的回调
    listRefresh() {
      this.filterForm.pageNo = 1
      this.$refs.myList.finished = false
      this.$refs.myList.loading = true
      this.udrListInit()
    }
  }
}

// 影像预览
export const onImgPreview = {
  data() {
    return {
      docList: ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pdf', 'mp4', 'zip', 'rar', 'txt'],
      imgList: ['png', 'jpg', 'jpeg', 'gif', 'bmp']
    }
  },
  computed: {
    newTitle() {
      return function(value) {
        const num = value.indexOf('照片')
        if (num !== -1) {
          value = value.split('照')[0]
        }
        return value
      }
    }
  },
  methods: {
    // 图片预览
    async imgPreview(val, title) {
      console.log(this.imageTypeList)
      // this.$toast.loading({
      //   message: '加载中...',
      //   forbidClick: true,
      //   duration: 0
      // })
      // const res = await getFileInfoNew({
      //   CFId: val.CFId
      // })
      // const url = window.URL.createObjectURL(res)
      // this.$toast.clear()
      // const par = getLocal('access_form').access_token
      // const envi = process.env.VUE_APP_BASE_PATH.replace(/\//g, '')
      // const url =
      //   envi === 'serverpro'
      //     ? `https://cmuw.cjbx.com.cn/serverpro/car/zuul-file/fileInfo?CFId=${val.CFId}&access_token=${par}`
      //     : `https://muw${envi}.cjbx.com.cn/${envi}/car/zuul-file/fileInfo?CFId=${val.CFId}&access_token=${par}`
      const allList = []
      this.imageTypeList.forEach(item => {
        item.fileList.forEach(value => {
          allList.push(value)
        })
      })
      console.log(allList)

      const newList = allList.filter(item => {
        return this.imgList.indexOf(item.CFileExt) !== -1
      })
      console.log(newList, 3333333333)
      // const list = this.imageTypeList.filter(item => {
      //   return item.title === title
      // })
      // console.log(this.imageTypeList, 2)
      // console.log(list, 3)
      // const newList = list[0].fileList.filter(item => {
      //   return this.imgList.indexOf(item.CFileExt) !== -1
      // })
      // 预览
      this.$refs.myPreview.previewShow = true
      this.$refs.myPreview.previewTitle = val.CFName
      this.$refs.myPreview.imageList = newList

      // this.$refs.myPreview.previewList = [url]
    },

    // 文档格式预览
    docPreview(val) {
      if (val.CFileExt === 'zip' || val.CFileExt === 'rar') {
        this.$toast('暂不支持压缩文件预览查看')
        return
      }

      if (val.CFileExt === 'txt') {
        this.$router.push({
          path: 'myTxT',
          query: {
            CFId: val.CFId,
            CFName: val.CFName
          }
        })
        return
      }

      const par = getLocal('access_form').access_token
      const envi = process.env.VUE_APP_BASE_PATH.replace(/\//g, '')
      window.wx.miniProgram.navigateTo({
        url: `/pages/preview/preview?par=${par}&CFId=${val.CFId}&envi=${envi}`
      })
    }
  }
}
