import request from '@/utils/request'

// 登陆
export const login = data => {
  return request({
    method: 'post',
    url: '/zuul-login/sso/login',
    data
  })
}

// 登陆
export const loginToken = data => {
  return request({
    method: 'post',
    url: '/zuul-login/sso/loginToken',
    data
  })
}

// 企业微信授权登录
export const QYlogin = data => {
  return request({
    method: 'get',
    url: '/zuul-login/sso/loginByQYWX',
    params: data
  })
}

// 投保单列表数量
export const getCarTask = () => {
  return request({
    method: 'get',
    url: '/zuul-undr/undr/monit/info'
  })
}

// 获取投保单清单列表
export const getUdrList = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underBill/findUnderBillList',
    data
  })
}

// 获取投保单详情
export const getUdrInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/apply',
    data
  })
}

// 费用信息查看接口
export const getFeeInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underBill/findApplyFeeInfo',
    data
  })
}

// 规则信息查看接口
export const getRuleInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underBill/findApplyPlatRuleInfo',
    data
  })
}

// 车型风险保费
export const getRiskInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/vhl/queryPlateVhlInfo',
    data
  })
}

// 历史保单列表获取接口
export const getHisPolicyInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underBill/findHisPolicyList',
    data
  })
}

// 历史核保意见查看接口
export const getOpnInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underBill/findUnderOpnHistory',
    data
  })
}

// 获取用户工号(暂未使用)
export const getUserCode = data => {
  return request({
    method: 'get',
    url: '/zuul-login/sso/getUserCode',
    params: data
  })
}

// 获取个人中心
export const getUserCenter = data => {
  return request({
    method: 'get',
    url: '/zuul-undr/underwriting/details/getUserCenter',
    params: data
  })
}

// 获取核保员机构信息和核保级别信息
export const getDptClsInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underBill/findUnderDptClsInfo',
    data
  })
}

// 获取核保员全部机构信息
export const getDptInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underBill/findUnderAllDptInfo',
    data
  })
}

// 理赔信息
export const getClaimInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underBill/findLPClaimsInfo',
    data
  })
}

// 再保风险信息
export const getReinsureInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underBill/findReInsureInfo',
    data
  })
}

// 收付信息
export const getPaymentInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underBill/findSFPlyFinInfo',
    data
  })
}

// 获取当天验车码
export const getTodayCarCode = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underBill/findVerifyCodeToday',
    data
  })
}

// 获取年度历史赔案
export const getYearList = data => {
  return request({
    method: 'post',
    url: '/zuul-query/customer/getYearList',
    data
  })
}

// 获取历史赔案-客户保单信息接口
export const getPolicyYearList = data => {
  return request({
    method: 'post',
    url: '/zuul-query/customer/getPolicyList',
    data
  })
}

// 获取历史赔案-客户理赔信息接口
export const getClaimYearList = data => {
  return request({
    method: 'post',
    url: '/zuul-query/customer/getClaimList',
    data
  })
}

// 获取影像清单
export const getFileList = data => {
  return request({
    method: 'post',
    url: '/zuul-file/fileServer/fileList',
    data
  })
}

// 获取缩略图base64编码接口
export const getThumbnailBase64 = data => {
  return request({
    method: 'post',
    url: '/zuul-file/fileServer/thumbnailBase64',
    data
  })
}

// 影像预览接口1
export const getFileInfo = data => {
  return request({
    method: 'post',
    url: '/zuul-file/fileServer/fileInfo',
    data
  })
}

// 影像预览接口2
export const getFileInfoNew = data => {
  return request({
    method: 'get',
    url: '/zuul-file/fileInfo',
    params: data,
    responseType: 'blob'
  })
}

// 核保意见暂存
export const udrOptSave = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/saveOpinionUnderwriting',
    data
  })
}

// 核保意见暂存查询接口
export const getUdrOpt = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/getOpinionUnderwritingBack',
    data
  })
}

// 核保意见提交
export const udrOptSubmit = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/submitOpinionUnderwriting',
    data
  })
}

// 暂存解除
export const udrTempClear = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/removeOpinionUnderwriting',
    data
  })
}

// 获取投保单流程
export const getUdrFlow = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/process',
    data
  })
}

// 获取全国车型平台预填信息
export const getVehicleType = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/vhl/queryVhlByVIN',
    data
  })
}

// 精友车辆查询
export const getVehicleQuery = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/vhl/queryVhlByPage',
    data
  })
}

// 获取车型详情
export const getVehicleDetail = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/vhl/queryVhlByVehicleModelCode',
    data
  })
}

// 获取消息列表
export const getMessage = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/getMessageCenter',
    data
  })
}

// 获取消息详情
export const getMsgDetail = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/getMessageDetail',
    data
  })
}

// 消息全部已读
export const readAllMsg = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/getCenterRead',
    data
  })
}

// 消息批量删除
export const delMsg = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/deleteCenterList',
    data
  })
}

// 获取验证码
export const getUdrCode = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/getSMSverifCode',
    data
  })
}

// 验证验证码
export const verifyUdrCode = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/verifSMSverifCode',
    data
  })
}

// 获取待核保任务
export const getDoingTask = () => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/getNewUdrInfo'
  })
}

// 消息推送
export const QYMessageSend = data => {
  return request({
    method: 'post',
    url: '/zuul-login/sso/messageNotif',
    data
  })
}

// 影像详细信息
export const getFileDetail = data => {
  return request({
    method: 'post',
    url: '/zuul-undr/underwriting/details/getCustomerDetail',
    data
  })
}

// 维护消息提示
export const getMaintainDetail = data => {
  return request({
    method: 'post',
    url: '/zuul-query/msg/getPromptMessage',
    data
  })
}
