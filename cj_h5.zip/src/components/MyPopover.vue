<template>
  <div>
    <van-popover
      v-model="showPopover"
      trigger="click"
      theme="dark"
      class="pulic_popover"
      @click.native="popoverClick"
    >
      <div style="padding:15px 20px">{{ params }}</div>
      <template #reference>
        <slot name="reference"></slot>
      </template>
    </van-popover>
  </div>
</template>

<script>
export default {
  name: 'MyPopover',
  props: {
    params: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      showPopover: false
    }
  },
  mounted() {},
  methods: {
    popoverClick() {
      if (!this.params) {
        this.showPopover = false
      }
    }
  }
}
</script>

<style scoped lang="less">
/deep/ .pulic_popover {
  width: 100%;
  display: unset;
  .van-col:nth-child(2) {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
</style>
