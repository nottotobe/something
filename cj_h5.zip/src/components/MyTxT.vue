<template>
  <div>
    <van-nav-bar
      fixed
      placeholder
      :title="TxTForm.titleTxT"
      left-text="返回"
      left-arrow
      safe-area-inset-top
      @click-left="$router.back()"
    />

    <van-field v-model="TxTForm.valueTxT" autosize readonly type="textarea" />
  </div>
</template>

<script>
import { getFileInfoNew } from '@/api'
export default {
  name: 'MyTxT',
  data() {
    return {
      TxTForm: {
        valueTxT: '',
        titleTxT: ''
      }
    }
  },
  mounted() {
    this.txtOpen()
  },
  methods: {
    // 打开txt文件
    async txtOpen() {
      console.log()
      const res = await getFileInfoNew({
        CFId: this.$route.query.CFId
      })
      console.log(res)
      const url = window.URL.createObjectURL(res)
      console.log(url)
      const reader = new FileReader()
      reader.onload = () => {
        this.showTxT = true
        this.TxTForm.valueTxT = reader.result
        this.TxTForm.titleTxT = this.$route.query.CFName
        console.log(reader.result) // reader.result为获取结果
      }
      reader.readAsText(res, 'gb2312')
    }
  }
}
</script>

<style scoped lang="less"></style>
