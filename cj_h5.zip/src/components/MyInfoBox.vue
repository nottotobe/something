<template>
  <van-collapse v-model="activeNames" class="info_collapse" accordion>
    <van-collapse-item :title="newTitle" :name="1" class="info_collapse_title">
      <van-row v-for="(item, index) in list" :key="index" class="info_row">
        <van-col :span="span">{{ item.name | isEmpty }}：</van-col>
        <van-col :span="otherSpan" :style="{ color: highlight(item) }">
          {{ item.value | isEmpty | units(item) }}
        </van-col>
      </van-row>

      <slot name="other"></slot>
    </van-collapse-item>
  </van-collapse>
</template>

<script>
import { isEmpty, units } from '@/utils/filiters'
import udrBox from './js/udrBox'
export default {
  name: 'MyInfoBox',
  filters: { isEmpty, units },
  props: {
    index: {
      type: Number,
      default: 1
    },
    title: {
      type: String,
      default: '这是一个标题'
    },
    obj: {
      type: [Object, Array],
      default: () => ({})
    },
    keyword: {
      type: String,
      default: '这是一个关键字'
    },
    span: {
      type: [Number, String],
      default: 6
    }
  },
  computed: {
    otherSpan() {
      return 24 - Number(this.span)
    },
    newTitle() {
      if (this.keyword === 'insuredPolicyInfo') {
        return this.obj.prm ? this.title + '：' + this.obj.prm + '元' : this.title
      }
      if (this.keyword === 'correctPolicyInfo') {
        return this.obj.nPrmVar ? this.title + '：' + this.obj.nPrmVar + '元' : this.title
      }
      if (this.keyword === 'vstax') {
        return this.obj['合计(元)'] ? this.title + '：' + this.obj['合计(元)'] : this.title
      }
      return this.title
    },
    highlight() {
      return function(item) {
        return item.highlight ? item.highlight : ''
      }
    }
  },
  data() {
    return {
      list: [],
      activeNames: this.index
    }
  },
  created() {
    this.mergeRende(this.obj)
  },
  mounted() {},
  watch: {
    obj: {
      handler(newValue) {
        this.mergeRende(newValue)
      },
      deep: true
    }
  },
  methods: {
    // 赋值
    mergeRende(newValue) {
      this.someJudge()

      if (this.list) {
        const newList = []
        this.list.forEach(item => {
          for (const k in newValue) {
            if (item.type === k) {
              item.value = newValue[k]
              newList.push(item)
            }
          }
        })
        this.list = newList
      }
    },

    // 赋值前判断
    someJudge() {
      if (this.keyword === 'insuredPolicyInfo' && this.$route.query.flag === 'SY') {
        this.list = udrBox[this.keyword].slice(1)
      } else {
        this.list = udrBox[this.keyword]
      }
    }
  }
}
</script>

<style scoped lang="less">
.info_collapse {
  margin-top: 20px;
  /deep/ .info_collapse_title {
    & > .van-collapse-item__title {
      font-weight: 700;
      &::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 0;
        width: 8px;
        height: 40px;
        transform: translateY(-50%);
        background: #5088ff;
        border-radius: 8px;
      }
    }
    .info_row {
      margin-bottom: 8px;
      .van-col:nth-child(2) {
        color: #323233;
      }
    }
  }
}
</style>
