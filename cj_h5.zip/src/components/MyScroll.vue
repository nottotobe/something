<template>
  <div ref="wrapper" :class="classN + ' wrapper'">
    <slot></slot>
  </div>
</template>

<script>
import BScroll from '@better-scroll/core'
import Pulldown from '@better-scroll/pull-down'
import Pullup from '@better-scroll/pull-up'
BScroll.use(Pulldown)
BScroll.use(Pullup)
export default {
  name: 'MyScroll',
  props: {
    classN: {
      type: String,
      default: ''
    },
    data: {
      default: null
    }
  },
  watch: {
    // 监听数据的变化，延时refreshDelay时间后调用refresh方法重新计算，保证滚动效果正常
    data() {
      setTimeout(() => {
        this.refresh()
      }, 300)
    }
  },
  data() {
    return {
      scroll: null
    }
  },
  mounted() {
    setTimeout(() => {
      this._initScroll()
    }, 20)
  },
  methods: {
    _initScroll() {
      this.scroll = new BScroll('.' + this.classN, {
        tap: 'tap',
        click: true,
        pullDownRefresh: {
          threshold: 35
        },
        pullUpLoad: {
          threshold: -35
        }
      })

      // 下拉到顶
      this.scroll.on('pullingDown', () => {
        this.$emit('pullingDown')
        this.scroll.finishPullDown()
      })

      // 上拉到底
      this.scroll.on('pullingUp', () => {
        this.$emit('pullingUp')
        this.scroll.finishPullUp()
      })
    },

    refresh() {
      // 代理better-scroll的refresh方法
      this.scroll && this.scroll.refresh()
    }
  }
}
</script>

<style scoped lang="less">
.wrapper {
  height: 100%;
}
</style>
