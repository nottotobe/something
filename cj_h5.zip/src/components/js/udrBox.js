// 交强险/商业险(保单)
const insuredPolicyInfo = [
  { name: '车船税', type: 'jqVsTax', value: '', unit: '元' },
  { name: '客户应缴款', type: 'prm', value: '', unit: '元' },
  { name: '保险费', type: 'netPrm', value: '', unit: '元' },
  { name: '增值税', type: 'vatAmt', value: '', unit: '元' },
  { name: '折扣', type: 'nrat', value: '' },
  { name: '标准保费', type: 'sybrm', value: '', unit: '元' }
]

// 交强险/商业险(批单)
const correctPolicyInfo = [
  { name: '原保额', type: 'nBefEdrAmt', value: '', unit: '元' },
  { name: '现保额', type: 'nAmt', value: '', unit: '元' },
  { name: '保额变化', type: 'nAmtVar', value: '', unit: '元', highlight: '#2447b7' },
  { name: '原客户应缴款', type: 'nBefEdrPrm', value: '', unit: '元' },
  { name: '现客户应缴款', type: 'nPrm', value: '', unit: '元' },
  { name: '客户应缴款变化', type: 'nPrmVar', value: '', unit: '元', highlight: '#2447b7' },
  { name: '原保险费', type: 'nBefNetPrm', value: '', unit: '元' },
  { name: '现保险费', type: 'nNetPrm', value: '', unit: '元' },
  { name: '保险费变化', type: 'nNetPrmVar', value: '', unit: '元', highlight: '#2447b7' },
  { name: '原增值税', type: 'nBefVatAmt', value: '', unit: '元' },
  { name: '现增值税', type: 'nVatAmt', value: '', unit: '元' },
  { name: '增值税变化', type: 'nVatAmtVar', value: '', unit: '元', highlight: '#2447b7' }
]

// 车船税
const vstax = [
  { name: '缴税方式', type: '缴税方式', value: '' },
  { name: '缴税车辆类型', type: '缴税车辆类型', value: '' },
  { name: '纳税人识别号性质', type: '纳税人识别号性质', value: '' },
  { name: '纳税人识别号', type: '纳税人识别号', value: '' },
  { name: '纳税标志', type: '纳税标志', value: '' },
  { name: '整备质量(吨)', type: '整备质量(吨)', value: '' },
  { name: '缴税起始日期', type: '缴税起始日期', value: '' },
  { name: '缴税终止日期', type: '缴税终止日期', value: '' },
  { name: '能源种类', type: '能源种类', value: '' },
  { name: '税务登记号码', type: '税务登记号码', value: '' },
  { name: '前次交强险保单到期日', type: '前次交强险保单到期日', value: '' },
  { name: '纳税地区', type: '纳税地区', value: '' },
  { name: '计税单位', type: '计税单位', value: '' },
  { name: '税费标准/年/单位', type: '税费标准/年/单位', value: '' },
  { name: '年单位税额', type: '年单位税额(元)', value: '' },
  { name: '当期逾期天数', type: '当期逾期天数', value: '' },
  { name: '当期逾期时间', type: '当期逾期时间', value: '' },
  { name: '当期滞纳金', type: '当期滞纳金', value: '' },
  { name: '当期应纳税额', type: '当期应纳税额', value: '' },
  { name: '当期合计金额', type: '当期合计金额', value: '' },
  { name: '平台合计', type: '平台合计', value: '' },
  { name: '本年应缴额度', type: '本年应缴额度(元)', value: '' },
  { name: '往年补缴金额', type: '往年补缴金额(元)', value: '' },
  { name: '滞纳金', type: '滞纳金(元)', value: '' },
  { name: '减免车辆类型', type: '减免车辆类型', value: '' },
  { name: '减免税原因', type: '减免税原因', value: '' },
  { name: '税务机关代码', type: '税务机关代码', value: '' },
  { name: '减免税方案', type: '减免税方案', value: '' },
  { name: '减免比例', type: '减免比例', value: '' },
  { name: '减免金额', type: '减免金额', value: '' },
  { name: '减税证明号', type: '减税证明号', value: '' },
  { name: '减税机关名称', type: '减税机关名称', value: '' },
  { name: '免税车辆类型', type: '免税车辆类型', value: '' },
  { name: '免税证明号', type: '免税证明号', value: '' },
  { name: '免税金额', type: '免税金额', value: '' },
  { name: '免税机关名称', type: '免税机关名称', value: '' },
  { name: '完税车辆类型', type: '完税车辆类型', value: '' },
  { name: '完税凭证号', type: '完税凭证号', value: '' },
  { name: '完税金额', type: '完税金额', value: '' },
  { name: '完税机关名称', type: '完税机关名称', value: '' },
  { name: '税票号码类型', type: '税票号码类型', value: '' },
  { name: '税票号', type: '税票号', value: '' },
  { name: '完税凭证填发日期', type: '完税凭证填发日期', value: '' },
  { name: '开具完税凭证地区', type: '开具完税凭证地区', value: '' },
  { name: '差额税款', type: '差额税款', value: '' },
  { name: '申报状态', type: '申报状态', value: '' },
  { name: '申报日期', type: '申报日期', value: '' },
  { name: '合计金额标识', type: '合计金额标识', value: '' },
  { name: '算税标识', type: '算税标识', value: '' },
  { name: '年度字别', type: '年度字别', value: '' },
  { name: '合计', type: '合计(元)', value: '' },
  { name: '合计变化', type: '合计变化(元)', value: '' }
]

// 驾乘人员意外伤害保险
const nvl = [
  { name: '方案', type: 'CPlanName', value: '' },
  { name: '份数', type: 'NCopies', value: '' },
  { name: '保险名称', type: 'CProdNme', value: '' },
  { name: '保额', type: 'NAmt', value: '', unit: '元' },
  { name: '基础保费', type: 'NBasePrm', value: '', unit: '元' },
  { name: '保费', type: 'NPrm', value: '', unit: '元' },
  { name: '意外身故伤残保额', type: 'NAmt1', value: '', unit: '元/人' },
  { name: '意外医疗保险保额', type: 'NAmt2', value: '', unit: '元/人' },
  { name: '非车业务员渠道', type: 'CBrkrNme', value: '' },
  { name: '特别约定', type: 'CUnfixSpc', value: '' }
]

// 基本信息
const baseInfo = [
  { name: '业务员姓名', type: 'cSlsNme', value: '' },
  { name: '业务员渠道', type: 'cSalegrpCdeName', value: '' },
  { name: '代理人', type: 'cBrkrCde', value: '' },
  { name: '争议处理', type: 'cDisptSttlCdeName', value: '' },
  { name: '仲裁名称', type: 'cDisptSttlOrg', value: '' },
  { name: '投保单类型', type: 'cInsuranceType', value: '' },
  { name: '是否电子保单', type: 'cElectronicPolicy', value: '' },
  { name: '固定特别约定', type: 'cUnfixSpc', value: '' },
  { name: '备注', type: 'cRemark', value: '' }
]

// 发票信息
const invoiceInfo = [
  { name: '购买方姓名', type: 'cPayName', value: '' },
  { name: '发票类型', type: 'cInvoiceTyp', value: '' },
  { name: '纳税人识别号', type: 'cTaxIdenNo', value: '' },
  { name: '移动电话', type: 'cPayMobile', value: '' },
  { name: '地址', type: 'cPayAdd', value: '' },
  { name: '邮箱', type: 'cPayMail', value: '' }
]

// 交强险系数
const jqPrmCoefInfo = [
  { name: '理赔浮动原因', type: 'cTrafIrr', value: '' },
  { name: '不浮动原因', type: 'cNdiscRsn', value: '' },
  { name: '醉酒后驾驶违法行为次数', type: 'nResvNum2', value: '' },
  { name: '醉酒一次费率浮动', type: 'cResvTxt2', value: '' },
  { name: '饮酒后驾驶违法行为次数', type: 'nResvNum1', value: '' },
  { name: '饮酒一次费率浮动', type: 'cResvTxt1', value: '' },
  { name: '理赔调整系数', type: 'nResvNum3', value: '' },
  { name: '违法调整系数', type: 'nResvNum4', value: '' },
  { name: '酒后驾驶违法总系数', type: 'nResvNum5', value: '' },
  { name: '交强险总浮动系数', type: 'nTotDisc', value: '' }
]

// 商业险系数
const syPrmCoefInfo = [
  { name: '自主定价系数', type: 'nPricingAdjustValue', value: '' },
  { name: '附加费用率', type: 'nResvNum8', value: '' },
  { name: '交通违法调整系数', type: 'nCalCoef', value: '' },
  { name: '无赔优调整系数', type: 'nNclmCoef', value: '' },
  { name: '交通违法不浮动原因', type: 'nNcalRsn', value: '' },
  { name: '无赔优不浮动原因', type: 'nNclmRsn', value: '' },
  { name: '商业险总浮动系数', type: 'nTotDisc', value: '' },
  { name: '连续承保年数', type: 'nInsureYears', value: '' },
  { name: '连续承保期间出险次数', type: 'nClaimTimes', value: '' },
  { name: '无赔款优待等级', type: 'cClaimAdjustLevel', value: '' },
  { name: '交通违法浮动原因', type: 'nCalRsn', value: '' },
  { name: '无赔优浮动原因', type: 'nClmRsn', value: '' }
]

// 批改信息
const correctInfo = [
  { name: '申请类型', type: 'cEdrMrk', value: '' },
  { name: '是否全程批改', type: 'cIsFullEndor', value: '' },
  { name: '批改申请日期', type: 'tEdrAppTm', value: '' },
  { name: '批改有效起期', type: 'tEdrBgnTm', value: '' },
  { name: '批改有效止期', type: 'tEdrEndTm', value: '' },
  { name: '批文', type: 'cEdrCtnt', value: '' }
]

// 车型详情
const vehicleDetail = [
  { name: '车型编码', type: 'VehicleCode', value: '' },
  { name: '车型名称', type: 'VehicleName', value: '' },
  { name: '车型速查码', type: 'SearchCode', value: '' },
  { name: '车辆型号', type: 'VehiclePubCode', value: '' },
  { name: '厂商编码', type: 'CompanyCode', value: '' },
  { name: '厂商名称', type: 'CompanyName', value: '' },
  { name: '品牌编码', type: 'BrandCode', value: '' },
  { name: '品牌名称', type: 'BrandName', value: '' },
  { name: '车系编码', type: 'FamilyCode', value: '' },
  { name: '车系名称', type: 'FamilyName', value: '' },
  { name: '备注', type: 'Remark', value: '' },
  { name: '排量', type: 'Displacement', value: '' },
  { name: '上市时间', type: 'MarketDate', value: '' },
  { name: '车型分类', type: 'VehicleClass', value: '' },
  { name: '车型新分类', type: 'VehicleClassNew', value: '' },
  { name: '系别名称编码', type: 'VehicleImport', value: '' },
  { name: '新车购置价', type: 'PurchasePrice', value: '' },
  { name: '新车购置价(含税)', type: 'PurchasePriceTax', value: '' },
  { name: '变速器类型', type: 'GearboxType', value: '' },
  { name: '安全气囊数量', type: 'AirbagNum', value: '' },
  { name: '额定座位数', type: 'Seat', value: '' },
  { name: '额定载质量', type: 'Tonnage', value: '' },
  { name: 'ABS标识', type: 'AbsFlag', value: '' },
  { name: '整备质量', type: 'FullWeightMax', value: '' },
  { name: '是否有防盗装备', type: 'AlarmFlag', value: '' },
  { name: '行业车型编码', type: 'IacVehicleCode', value: '' },
  { name: '行业车型名称', type: 'IacVehicleName', value: '' },
  { name: '车船税减免标识', type: 'HfName', value: '' },
  { name: '车船税减免标识码', type: 'HfCode', value: '' },
  { name: '车船税减免起期', type: 'HfStartDate', value: '' },
  { name: '车船税减免止期', type: 'HfEndDate', value: '' },
  { name: '别名', type: 'AliasName', value: '' },
  { name: '类比价格', type: 'KindredPrice', value: '' },
  { name: '类比价格(含税)', type: 'KindredPriceTax', value: '' },
  { name: '商业险编码', type: 'SyxInsuranceId', value: '' },
  { name: '商业险名称', type: 'SyxInsuranceName', value: '' },
  { name: '交强险编码', type: 'JqxInsuranceId', value: '' },
  { name: '交强险名称', type: 'JqxInsuranceName', value: '' }
]

// 纯风险车型保费  ------ 车辆信息
const carBaseInfo = [
  { name: '行业车型编码标识', type: 'CModelFlag', value: '' },
  { name: '车款名称', type: 'CCarName', value: '' },
  { name: '公告型号', type: 'CNoticeType', value: '' },
  { name: '行业车型编码', type: 'CModelCode', value: '' },
  { name: '车型识别编码', type: 'CModelIDCode', value: '' },
  { name: '厂商名称', type: 'CTradeName', value: '' },
  { name: '厂商编码', type: 'CTradeCode', value: '' },
  { name: '品牌名称', type: 'CBrand', value: '' },
  { name: '品牌编码', type: 'CBrandCode', value: '' },
  { name: '车系名称', type: 'CSeries', value: '' },
  { name: '车系编码', type: 'CSerriesCode', value: '' },
  { name: '配置款型编码', type: 'CConfigType', value: '' },
  { name: '类别名称', type: 'CCategoryName', value: '' },
  { name: '类别编码', type: 'CCategoryCode', value: '' },
  { name: '系别名称', type: 'CDeptName', value: '' },
  { name: '系别编码', type: 'CDeptCode', value: '' }
]

// 纯风险车型保费  ------ 车型保费信息
const cvrgBaseInfo = [
  { name: '险别编码', type: 'CCvrgCode', value: '' },
  { name: '行业车型编码', type: 'CCModelCode', value: '' },
  { name: '纯风险保费', type: 'NPureRiskPremium', value: '' },
  { name: '纯风险保费标志', type: 'NPureRiskPremiumFlag', value: '' }
]

// 历史基本信息
const baseHisInfo = [
  { name: '投保单号', type: 'cappNo', value: '' },
  { name: '续保', type: 'crenew', value: '' },
  { name: '保单号', type: 'cplyNo', value: '' },
  { name: '续保保单号', type: 'crenewPlyNO', value: '' },
  { name: '机构部门', type: 'cdptNme', value: '' },
  { name: '业务员渠道', type: 'csalegrpCde', value: '' },
  { name: '录单人', type: 'copr', value: '' },
  { name: '录单日期', type: 'TOpTm', value: '' },
  { name: '投保单业务来源', type: 'cappBsnsTyp', value: '' },
  { name: '保单归属(市)', type: 'cplyAttr', value: '' },
  { name: '保单归属(县)', type: 'cplyCty', value: '' }
]

// 账户信息
const account = [
  { name: '账户名', type: 'cacctNme', value: '' },
  { name: '账号', type: 'cacctNo', value: '' },
  { name: '银行省', type: 'cbankPro', value: '' },
  { name: '银行市', type: 'cbankArea', value: '' },
  { name: '收款行联行号', type: 'cbankRelCde', value: '' },
  { name: '开户行', type: 'cbankCde', value: '' }
]

export default {
  insuredPolicyInfo,
  correctPolicyInfo,
  vstax,
  nvl,
  baseInfo,
  invoiceInfo,
  jqPrmCoefInfo,
  syPrmCoefInfo,
  correctInfo,
  vehicleDetail,
  carBaseInfo,
  cvrgBaseInfo,
  baseHisInfo,
  account
}
