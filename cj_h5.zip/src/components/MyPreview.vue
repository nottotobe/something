<template>
  <div>
    <van-image-preview
      v-model="previewShow"
      :images="previewList"
      ref="previewRef"
      :class-name="'previewStyle ' + previewHeight"
      get-container="body"
      @close="previewClose"
      @change="previewChange"
      :start-position="previewStart"
    >
      <template #index>
        <transition name="van-slide-up">
          <van-tabs
            v-model="previewActive"
            v-if="previewFlag"
            class="previewTabs"
            color="#5980ff"
            title-active-color="#5980ff"
            swipeable
          >
            <van-tab title="行驶证信息">
              <van-row>
                <van-col span="8">号牌号码：</van-col>
                <van-col span="16">{{ vhlinfo.CPlateNo | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">车辆类型：</van-col>
                <van-col span="16">{{ vhlinfo.CRegVhlTyp | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">所有人：</van-col>
                <van-col span="16">{{ vhlinfo.COwnerNme | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">住址：</van-col>
                <van-col span="16">{{ vhlinfo.CClntAddr | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">使用性质：</van-col>
                <van-col span="16">{{ vhlinfo.CUsageCde | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">品牌型号：</van-col>
                <van-col span="16">{{ vhlinfo.CModelNme | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">车辆识别代号：</van-col>
                <van-col span="16">{{ vhlinfo.CVin | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">发动机号：</van-col>
                <van-col span="16">{{ vhlinfo.CEngNo | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">行驶证初登日期：</van-col>
                <van-col span="16">{{ vhlinfo.CFstRegYm | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">行驶证发证日期：</van-col>
                <van-col span="16">{{ vhlinfo.TDriverlienceYm | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">座位数：</van-col>
                <van-col span="16">{{ vhlinfo.NSeatNum | isEmpty }}</van-col>
              </van-row>
            </van-tab>
            <van-tab title="投保人">
              <van-row>
                <van-col span="8">投保人名称：</van-col>
                <van-col span="16">{{ applicant.CAppNme | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">证件号：</van-col>
                <van-col span="16">{{ applicant.CCertfCde | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">住址：</van-col>
                <van-col span="16">{{ applicant.CClntAddr | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">证件有效期：</van-col>
                <van-col span="16">{{
                  (applicant.CCertfCdeBgnTm + ' 至 ' + applicant.CCertfCdeEndTm) | isEmpty
                }}</van-col>
              </van-row>
            </van-tab>
            <van-tab title="被保人">
              <van-row>
                <van-col span="8">被保人名称：</van-col>
                <van-col span="16">{{ insured.CInsuredNme | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">证件号：</van-col>
                <van-col span="16">{{ insured.CCertfCde | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">住址：</van-col>
                <van-col span="16">{{ insured.CClntAddr | isEmpty }}</van-col>
              </van-row>
              <van-row>
                <van-col span="8">证件有效期：</van-col>
                <van-col span="16">{{
                  (insured.CCertfCdeBgnTm + ' 至 ' + insured.CCertfCdeEndTm) | isEmpty
                }}</van-col>
              </van-row>
            </van-tab>
          </van-tabs>
        </transition>
      </template>

      <template #cover>
        <van-nav-bar
          :title="previewTitle"
          left-arrow
          @click-left="previewLeft"
          @click-right="previewRight"
        >
          <template #right>
            <van-icon name="ellipsis" />
          </template>
        </van-nav-bar>
      </template>
    </van-image-preview>
  </div>
</template>

<script>
import { getFileDetail, getFileInfoNew } from '@/api'
import { getSession } from '@/utils/storage'
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'MyPreview',
  filters: { isEmpty },
  data() {
    return {
      previewShow: false, // 预览组件显示和关闭
      previewList: [], // 预览组件图片数组
      previewFlag: false, // 相关信息tabs显示和关闭
      previewActive: 0, // 相关信息tabs索引
      previewTitle: '', // 相关信息tabs标题
      previewHeight: 'preview92', // 相关信息tabs高度
      applicant: {},
      insured: {},
      vhlinfo: {},
      imageList: [],
      imageTitleList: [],
      previewStart: 0
    }
  },
  mounted() {
    this.fileDetailInit()
  },
  watch: {
    imageList(newValue, oldValue) {
      console.log(newValue)
      console.log(oldValue)
      this.previewInit()
    }
  },
  methods: {
    // 获取相关信息
    async fileDetailInit() {
      const res = await getFileDetail({
        CAppNo: getSession('something').appNo
      })
      console.log(res, '影像详情')
      this.applicant = Object.assign({}, res.data.applicant)
      this.insured = Object.assign({}, res.data.insured)
      this.vhlinfo = Object.assign({}, res.data.vhlinfo)
    },

    // 头部返回按钮
    previewLeft() {
      this.$refs.previewRef.close()
    },

    // 头部三个点
    previewRight() {
      this.previewFlag = !this.previewFlag
      if (this.previewFlag) {
        this.previewHeight = 'preview592'
      } else {
        this.previewHeight = 'preview92'
      }
    },

    // 预览器关闭
    previewClose() {
      this.previewList = []
      this.previewHeight = 'preview92'
      this.previewFlag = false
      this.previewActive = 0
    },

    // 图片切换
    previewChange(index) {
      this.imageTitleList.forEach((item, num) => {
        if (index === num) {
          this.previewTitle = item
        }
      })
    },

    // 同步得到大图的返回结果
    previewInit() {
      if (this.imageList.length > 0) {
        const proList = []
        this.imageTitleList = []
        console.log(this.imageList, 1)
        this.imageList.forEach((item, index) => {
          this.imageTitleList.push(item.CFName)

          if (this.previewTitle === item.CFName) {
            this.previewStart = index
          }
          const result = new Promise((resolve, reject) => {
            getFileInfoNew({
              CFId: item.CFId
            })
              .then(res => {
                return resolve(res)
              })
              .catch(_ => {
                return resolve('----') // 注意
              })
          })
          proList.push(result)
        })
        console.log(this.imageTitleList, '0000')
        console.log(this.previewList, '11111')
        Promise.all(proList)
          .then(itemList => {
            console.log(this.previewList)
            console.log(itemList) // itemList返回的数据是按顺序的

            // 执行自己接下来的操作
            // doSomething
            itemList.forEach(item => {
              const url = window.URL.createObjectURL(item)
              this.previewList.push(url)
            })
            // this.previewList = itemList.concat()
          })
          .catch(error => {
            console.log(error)
          })
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
