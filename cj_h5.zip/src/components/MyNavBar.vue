<template>
  <van-sticky>
    <van-nav-bar
      :title="title"
      left-arrow
      @click-left="onClickLeft"
      @click-right="$router.push('/policy')"
      class="white_bar"
    >
      <template #right>
        <van-icon name="wap-home" v-if="params !== '/policy'" />
      </template>
    </van-nav-bar>
  </van-sticky>
</template>

<script>
export default {
  name: 'MyNavBar',
  props: {
    title: {
      type: String,
      default: '这是一个标题'
    },
    params: {
      type: [String, Object],
      default: '这是一个参数'
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {
    onClickLeft() {
      if (this.params === '这是一个参数') {
        this.$router.back()
      } else {
        this.$router.push(this.params)
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
