<template>
  <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
    <van-list
      v-model="loading"
      :finished="finished"
      finished-text="没有更多了"
      @load="onLoad"
      :immediate-check="icheck"
    >
      <!-- 固定卡片 -->
      <div v-for="(item, index) in list" :key="index">
        <van-cell :class="cellStyle(item)" @click="saveSomething(item)">
          <template #title>
            <div class="list_cell_title">
              <span class="list_cell_name">{{ item.appName | isEmpty }}</span>
              <span class="list_cell_icon">
                <span v-if="$route.path === '/search'">
                  <van-tag type="primary" v-if="item.taskState === 'newUdr'">待核保</van-tag>
                  <van-tag type="success" v-if="item.taskState === 'completeUdr'">通过</van-tag>
                  <van-tag type="danger" v-if="item.taskState === 'backUdr'">退回</van-tag>
                  <van-tag type="warning" v-if="item.taskState === 'reportUdr'">已上报</van-tag>
                  <van-tag color="#7232dd" v-if="item.taskState === 'pendUdr'">暂存</van-tag>
                </span>
                <van-tag plain type="primary">{{ item.cProdNo === '0350' ? '交' : '商' }}</van-tag>
                <van-tag plain type="warning">{{ item.cType === 'A' ? '投' : '批' }}</van-tag>
              </span>
            </div>
          </template>
          <template #label>
            <van-row v-if="to === '/udrDetail'">
              <van-col span="6">申请机构：</van-col>
              <van-col span="18">{{ item.dptName | isEmpty }}</van-col>
            </van-row>
            <van-row v-if="to === '/udrDetail'">
              <van-col span="6">申请单号：</van-col>
              <van-col span="18">{{ item.appNo | isEmpty }}</van-col>
            </van-row>
            <van-row v-else>
              <van-col span="6">保单号：</van-col>
              <van-col span="18">{{ item.policyNo | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col span="6">车牌号码：</van-col>
              <van-col span="18">{{ item.vhlPlateNo | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col span="6">投保日期：</van-col>
              <van-col span="18">{{ item.appTime | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col span="6">保费合计：</van-col>
              <van-col span="18" style="color:red">¥ {{ item.nprm | isEmpty }}</van-col>
            </van-row>
            <van-image
              class="listIcon"
              v-if="listIconFlag"
              :src="listIconSrc"
              @click.stop="listIconClick(item)"
            />
          </template>
        </van-cell>
      </div>

      <!-- 自定义位置 -->
      <slot name="other"></slot>
    </van-list>
  </van-pull-refresh>
</template>

<script>
import { setSession } from '@/utils/storage'
import { udrTempClear } from '@/api'
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'MyList',
  props: {
    to: {
      type: String,
      default: ''
    },
    list: {
      type: Array,
      default: () => []
    },
    icheck: {
      type: Boolean,
      default: true
    }
  },
  filters: { isEmpty },
  computed: {
    // 暂存角标
    cellStyle() {
      return function(item) {
        if (item.cOpnSts === '0' && item.taskState === 'pendUdr') {
          return 'list_cell list_cell_special'
        }
        return 'list_cell'
      }
    }
  },
  data() {
    return {
      loading: false,
      finished: false,
      refreshing: false,
      listIconFlag: false,
      listIconSrc: '',
      listIconList: [require('@img/list/reject.png'), require('@img/list/information.png')]
    }
  },
  mounted() {
    this.listIconInit()
  },
  methods: {
    // 列表右下角的图片判断
    listIconInit() {
      const route = this.$route
      if (route.path === '/udrList') {
        this.listIconFlag = true
        if (route.query.id === 'newUdr') {
          this.listIconFlag = false
        } else if (route.query.id === 'pendUdr') {
          this.listIconSrc = this.listIconList[0]
        } else {
          this.listIconSrc = this.listIconList[1]
        }
      }
    },

    // 列表右下角的图片点击
    listIconClick(item) {
      const query = this.$route.query
      if (query.id === 'pendUdr') {
        this.$dialog
          .confirm({
            title: '解除接收',
            message: '解除接收后，可在待核保查看该数据，确认解除？'
          })
          .then(async () => {
            const res = await udrTempClear({
              appNo: item.appNo,
              dptCde: item.cDptCde
            })

            if (res && res.status === 1) {
              this.$toast(res.data.returnMassage)
              this.onRefresh()
            } else {
              this.$toast.fail(res.message)
            }
          })
          .catch(() => {
            // on cancel
          })
      } else {
        this.$router.push({
          path: '/udrFlow',
          query: {
            appNo: item.appNo,
            type: query.id
          }
        })
      }
    },

    // 下拉加载
    onLoad() {
      this.$emit('listLoad')
    },

    // 上拉刷新
    onRefresh() {
      this.$emit('listRefresh')
    },

    // 存储一些东西
    saveSomething(item) {
      console.log(item)
      const routeObj = {
        appNo: item.appNo,
        cProdNo: item.cProdNo,
        cType: item.cType,
        flag: item.cProdNo === '0350' ? 'JQ' : 'SY'
      }

      // 待核保状态的单子点进去要触发暂存
      if (item.taskState === 'newUdr') {
        setSession('taskStatus', 'newUdr')
      }

      // 投保单列表和搜索列表进入的时候
      if (this.$route.path === '/udrList' || this.$route.path === '/search') {
        console.log(item)
        const newObj = Object.assign({}, item)
        newObj.dataPath = this.$route.path
        setSession('something', newObj)
      }

      // 历史保单列表进入的时候  多加了一个保单号
      if (this.$route.path === '/udrType') {
        routeObj.policyNo = item.policyNo
      }

      // 历史保单里面有的保单号为空 再此加判断不让进历史保单详情
      // (后台升级后貌似不会出现保单号为空的单子了，此判断或许无用了)
      if (this.$route.path === '/udrType' && !item.policyNo) {
        this.$toast.fail('该保单无单号')
        return
      }

      this.$router.push({ path: this.to, query: routeObj })
    }
  }
}
</script>

<style scoped lang="less">
.list_cell {
  margin-top: 20px;
  .van-cell__title {
    .list_cell_title {
      display: flex;
      justify-content: space-between;
      margin-bottom: 16px;
      .list_cell_name {
        flex: 1;
        font-size: 35px;
        font-weight: 900;
      }
      .list_cell_icon {
        .van-tag {
          margin-right: 10px;
        }
      }
    }
    .van-cell__label {
      position: relative;
      & > .van-row {
        margin-bottom: 16px;
        font-size: 30px;
        .van-col:nth-child(2) {
          color: #323233;
        }
      }
      .listIcon {
        width: 56px;
        height: 56px;
        position: absolute;
        bottom: 0;
        right: 16px;
        margin-bottom: 0;
      }
    }
  }
}

.list_cell_special {
  &::before {
    content: '';
    position: absolute;
    top: -18px;
    left: -4px;
    width: 0;
    height: 0;
    border-top: 30px solid transparent;
    border-right: 30px solid #1a9bff;
    border-bottom: 30px solid transparent;
    transform: rotate(45deg);
  }
}
</style>
