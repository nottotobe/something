/**
 * 存储localStorage
 */
export const setLocal = (name, value) => {
  if (!name) return
  // if (typeof value !== 'string') {
  value = JSON.stringify(value)
  // }
  window.localStorage.setItem(name, value)
}

/**
 * 获取localStorage
 */
export const getLocal = name => {
  if (!name) return
  const data = window.localStorage.getItem(name)
  try {
    return JSON.parse(data)
  } catch (err) {
    return data
  }
}

/**
 * 删除localStorage
 */
export const removeLocal = name => {
  if (!name) return
  window.localStorage.removeItem(name)
}

/**
 * 清空localStorage
 */
export const emptyLocal = function() {
  window.localStorage.clear()
}

/**
 * 存储sessionStorage
 */
export const setSession = (name, value) => {
  if (!name) return
  // if (typeof value !== 'string') {
  value = JSON.stringify(value)
  // }
  window.sessionStorage.setItem(name, value)
}

/**
 * 获取sessionStorage
 */
export const getSession = name => {
  if (!name) return
  const data = window.sessionStorage.getItem(name)
  try {
    return JSON.parse(data)
  } catch (err) {
    return data
  }
}

/**
 * 删除sessionStorage
 */
export const removeSession = name => {
  if (!name) return
  window.sessionStorage.removeItem(name)
}

/**
 * 清空sessionStorage
 */
export const emptySession = function() {
  window.sessionStorage.clear()
}
