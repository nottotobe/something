import axios from 'axios'
import { setLocal, getLocal, removeLocal } from '@/utils/storage'
import { Toast } from 'vant'
import { loginToken } from '@/api/index'
import store from '../store'
// import { dateFormat } from '@/utils/filiters'

const request = axios.create({
  baseURL: `${process.env.VUE_APP_BASE_PATH}car`, // 请求的基本路径
  // `timeout` 指定请求超时的毫秒数(0 表示无超时时间)
  // 如果请求话费了超过 `timeout` 的时间，请求将被中断
  timeout: 30000
})

// 添加请求拦截器
request.interceptors.request.use(
  function(config) {
    // 在发送请求之前做些什么
    // console.log(dateFormat(new Date(), 'YYYY/mm/dd HH:MM:SS'), '发送请求的时间')
    // Toast.loading({
    //   message: '加载中...',
    //   forbidClick: true,
    //   duration: 0
    // })

    // token设置
    if (getLocal('access_form')) {
      const accessToken = getLocal('access_form').access_token
      config.headers.authorization = 'Bearer ' + accessToken
    }

    if (config.method === 'post') {
      config.data = {
        ...config.data,
        _t: Date.parse(new Date()) / 1000
      }
    } else if (config.method === 'get') {
      config.params = {
        _t: Date.parse(new Date()) / 1000,
        ...config.params
      }
    }

    // 路由跳转时取消未完成的请求
    config.cancelToken = new axios.CancelToken(function(cancel) {
      store.commit('pushCancelToken', { cancelToken: cancel })
    })
    return config
  },
  function(error) {
    // 对请求错误做些什么
    return Promise.reject(error)
  }
)

// 添加响应拦截器
request.interceptors.response.use(
  function(response) {
    // 对响应数据做点什么
    // Toast.clear()
    // console.log(dateFormat(new Date(), 'YYYY/mm/dd HH:MM:SS'), '响应成功的时间')
    return response.data
  },
  function(error) {
    // 对响应错误做点什么
    if (error.message && error.message.includes('timeout')) {
      Toast.fail('请求超时')
      return
    }
    // 对响应错误做点什么
    if (error.response && error.response.status) {
      switch (error.response.status) {
        case 401:
          store.commit('clearCancelToken')
          removeLocal('access_form')
          // 跳回小程序授权登录
          if (process.env.NODE_ENV !== 'development') {
            if (!store.state.codeErrorFlag) {
              Toast('用户信息过期')
              setTimeout(() => {
                const status = process.env.VUE_APP_ROUTE.replace(/\//g, '')
                window.wx.miniProgram.reLaunch({
                  url: `/pages/index/index?isLogin=1&status=${status}`
                })
              }, 500)
            } else {
              Toast(store.state.codeErrorMsg)
            }
          } else {
            Toast('用户信息过期')
            loginToken({
              account: '000776',
              password: '1'
            }).then(function(res) {
              if (res && res.access_token) {
                const accessToken = res.access_token
                setLocal('access_form', {
                  access_token: accessToken,
                  access_user: 'wangrunxian',
                  access_code: '000776'
                })
                window.location.reload()
              }
            })
          }
          break
        case 404:
          Toast.fail('请求不存在')
          break
        case 405:
          Toast.fail('请求方法未允许')
          break
        case 400:
          Toast.fail('请求错误')
          break
        case 500:
          Toast.fail('服务器内部错误')
          break
        case 501:
          Toast.fail('网络未实现')
          break
        case 502:
          Toast.fail('网络错误')
          break
        case 503:
          Toast.fail('服务不可用')
          break
        case 504:
          Toast.fail('网络超时')
          break
        default:
          Toast.fail(error.response.data.msg)
          break
      }
    }

    if (axios.isCancel(error)) {
      // Toast.clear()
      return new Promise(() => {})
    }

    return Promise.reject(error)
  }
)

export default request
