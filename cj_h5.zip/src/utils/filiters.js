// 格式化时间
export const dateFormat = (date, fmt) => {
  let ret
  if (!fmt) {
    fmt = 'YYYY/mm/dd'
  }
  const opt = {
    'Y+': date.getFullYear().toString(), // 年
    'm+': (date.getMonth() + 1).toString(), // 月
    'd+': date.getDate().toString(), // 日
    'H+': date.getHours().toString(), // 时
    'M+': date.getMinutes().toString(), // 分
    'S+': date.getSeconds().toString() // 秒
    // 有其他格式化字符需求可以继续添加，必须转化成字符串
  }
  for (const k in opt) {
    ret = new RegExp('(' + k + ')').exec(fmt)
    if (ret) {
      fmt = fmt.replace(ret[1], ret[1].length === 1 ? opt[k] : opt[k].padStart(ret[1].length, '0'))
    }
  }
  return fmt
}

// 判断时间不能超过三个月
export const checkTime = (begintime, endtime) => {
  // 判断时间跨度是否大于3个月
  var arr1 = begintime.split('/')
  var arr2 = endtime.split('/')
  arr1[1] = parseInt(arr1[1])
  arr1[2] = parseInt(arr1[2])
  arr2[1] = parseInt(arr2[1])
  arr2[2] = parseInt(arr2[2])
  var flag = true
  if (arr1[0] === arr2[0]) {
    // 同年
    if (arr2[1] - arr1[1] > 3) {
      // 月间隔超过3个月
      flag = false
    } else if (arr2[1] - arr1[1] === 3) {
      // 月相隔3个月，比较日
      if (arr2[2] > arr1[2]) {
        // 结束日期的日大于开始日期的日
        flag = false
      }
    }
  } else {
    // 不同年
    if (arr2[0] - arr1[0] > 1) {
      flag = false
    } else if (arr2[0] - arr1[0] === 1) {
      if (arr1[1] < 10) {
        // 开始年的月份小于10时，不需要跨年
        flag = false
      } else if (arr1[1] + 3 - arr2[1] < 12) {
        // 月相隔大于3个月
        flag = false
      } else if (arr1[1] + 3 - arr2[1] === 12) {
        // 月相隔3个月，比较日
        if (arr2[2] > arr1[2]) {
          // 结束日期的日大于开始日期的日
          flag = false
        }
      }
    }
  }
  if (!flag) {
    return false
  }
  return true
}

// 值为空显示'-'
export const isEmpty = value => {
  if (value || value === 0) {
    return value
  }
  return '-'
}

// 有些数值带单位
export const units = (value, item) => {
  if (value !== '-' && item.unit) {
    return value + item.unit
  }
  return value
}

// 增加小数点
export const point = value => {
  if (value !== '-') {
    return Number(value).toFixed(2)
  }
  return value
}
