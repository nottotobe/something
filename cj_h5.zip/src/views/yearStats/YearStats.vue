<template>
  <div class="public_box">
    <My-nav-bar :title="$route.query.type === 'policy' ? '客户保单信息' : '客户理赔信息'" />

    <Policy-num v-if="$route.query.type === 'policy'" @changeClaim="changeClaim" />
    <Claim-num v-else />
  </div>
</template>

<script>
import MyNavBar from '@/components/MyNavBar'
import PolicyNum from './components/PolicyNum'
import ClaimNum from './components/ClaimNum'
export default {
  name: 'YearStats',
  components: {
    MyNavBar,
    PolicyNum,
    ClaimNum
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {
    changeClaim(value, num) {
      if (Number(num) === 0) return
      this.$router.push({
        query: {
          type: 'claim',
          plyNo: value
        }
      })
    }
  }
}
</script>

<style scoped lang="less"></style>
