<template>
  <div>
    <My-info-box title="客户保单信息">
      <template #other>
        <div
          v-for="(item, index) in policyYearList"
          :key="index"
          class="public_info_box_other"
          @click="changeClaim(item.plyNo, item.clmCount)"
        >
          <van-row>
            <van-col span="6">保单号：</van-col>
            <van-col span="18">{{ item.plyNo | isEmpty }}</van-col>
          </van-row>
          <van-row v-if="item.cPlateNo">
            <van-col span="6">车牌号：</van-col>
            <van-col span="18">{{ item.cPlateNo | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">产品名称：</van-col>
            <van-col span="18">{{ item.prodCnm | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">出单机构：</van-col>
            <van-col span="18">{{ item.dptCnm | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">保险起期：</van-col>
            <van-col span="18">{{ item.insrncBgnTm | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">保险止期：</van-col>
            <van-col span="18">{{ item.insrncEndTm | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">分期次数：</van-col>
            <van-col span="18">{{ item.payNumber | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">续保次数：</van-col>
            <van-col span="18">{{ item.origTimes | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">共保方式：</van-col>
            <van-col span="18">{{ item.ciMrk | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">理赔件数：</van-col>
            <van-col span="18">{{ item.clmCount | isEmpty }}</van-col>
          </van-row>
          <van-divider v-if="policyYearList.length > 1 && index !== policyYearList.length - 1" />
        </div>
      </template>
    </My-info-box>
  </div>
</template>

<script>
import { getPolicyYearList } from '@/api'
import { getSession } from '@/utils/storage'
import { isEmpty } from '@/utils/filiters'
import MyInfoBox from '@/components/MyInfoBox'
export default {
  name: 'PolicyNum',
  components: { MyInfoBox },
  data() {
    return {
      policyYearList: []
    }
  },
  mounted() {
    this.policyYearListInit()
  },
  filters: { isEmpty },
  methods: {
    // 初始化
    async policyYearListInit() {
      const res = await getPolicyYearList({
        clientNme: getSession('something').appName,
        certCde: getSession('something').certfCde,
        policyYear: this.$route.query.year
      })
      console.log(res)
      if (res && res.status === 1) {
        this.policyYearList = res.data
      }
    },

    // 去理赔信息
    changeClaim(plyNo, clmCount) {
      this.$emit('changeClaim', plyNo, clmCount)
    }
  }
}
</script>

<style scoped lang="less"></style>
