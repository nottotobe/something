<template>
  <div>
    <My-info-box title="客户理赔信息">
      <template #other>
        <div v-for="(item, index) in claimYearList" :key="index" class="public_info_box_other">
          <van-row>
            <van-col span="6">赔案号：</van-col>
            <van-col span="18">{{ item.clmNo | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">保单号：</van-col>
            <van-col span="18">{{ item.plyNo | isEmpty }}</van-col>
          </van-row>
          <van-row v-if="item.cPlateNo">
            <van-col span="6">车牌号：</van-col>
            <van-col span="18">{{ item.cPlateNo | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">产品名称：</van-col>
            <van-col span="18">{{ item.prodCnm | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">理赔机构：</van-col>
            <van-col span="18">{{ item.clmDptCnm | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">已决金额：</van-col>
            <van-col span="18" style="color:#ff8d11">{{ item.yjamt | isEmpty | point }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">未决金额：</van-col>
            <van-col span="18" style="color:#ff8d11">{{ item.wjamt | isEmpty | point }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">赔案状态：</van-col>
            <van-col span="18">{{ item.clmStsCnm | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">重开次数：</van-col>
            <van-col span="18">{{ item.reopenTms | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">出险时间：</van-col>
            <van-col span="18">{{ item.accTm | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">出险原因：</van-col>
            <van-col span="18">{{ item.accRsn | isEmpty }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">是否涉诉：</van-col>
            <van-col span="18">{{ item.liratio | isEmpty }}</van-col>
          </van-row>
          <van-divider v-if="claimYearList.length > 1 && index !== claimYearList.length - 1" />
        </div>
      </template>
    </My-info-box>
  </div>
</template>

<script>
import { getClaimYearList } from '@/api'
import { getSession } from '@/utils/storage'
import { isEmpty, point } from '@/utils/filiters'
import MyInfoBox from '@/components/MyInfoBox'
export default {
  name: 'ClaimNum',
  components: { MyInfoBox },
  filters: { isEmpty, point },
  data() {
    return {
      claimYearList: []
    }
  },
  mounted() {
    this.policyYearListInit()
  },
  methods: {
    async policyYearListInit() {
      const query = this.$route.query
      const getSome = getSession('something')
      const res = await getClaimYearList({
        plyNo: query.plyNo ? query.plyNo : '',
        clientNme: getSome.appName,
        certCde: getSome.certfCde,
        policyYear: query.year ? query.year : ''
      })
      console.log(res)
      if (res && res.status === 1) {
        this.claimYearList = res.data
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
