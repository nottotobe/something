<template>
  <div class="public_box">
    <My-nav-bar title="车型预填信息" />

    <div>
      <div v-for="(item, index) in vehicleTypeList" :key="index" class="public_info_box_other">
        <My-info-box :title="item.AliasName">
          <template #other>
            <van-row>
              <van-col :span="9">车型编码：</van-col>
              <van-col :span="15">{{ item.VehicleCode | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">车型名称：</van-col>
              <van-col :span="15">{{ item.VehicleName | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">车型速查码：</van-col>
              <van-col :span="15">{{ item.SearchCode | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">车辆型号：</van-col>
              <van-col :span="15">{{ item.VehiclePubCode | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">厂商编码：</van-col>
              <van-col :span="15">{{ item.CompanyCode | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">厂商名称：</van-col>
              <van-col :span="15">{{ item.CompanyName | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">品牌编码：</van-col>
              <van-col :span="15">{{ item.BrandCode | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">品牌名称：</van-col>
              <van-col :span="15">{{ item.BrandName | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">车系编码：</van-col>
              <van-col :span="15">{{ item.FamilyCode | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">车系名称：</van-col>
              <van-col :span="15">{{ item.FamilyName | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">备注：</van-col>
              <van-col :span="15">{{ item.Remark | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">排量：</van-col>
              <van-col :span="15">{{ item.Displacement | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">上市时间：</van-col>
              <van-col :span="15">{{ item.MarketDate | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">车型分类：</van-col>
              <van-col :span="15">{{ item.VehicleClass | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">车型新分类：</van-col>
              <van-col :span="15">{{ item.VehicleClassNew | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">系别名称编码：</van-col>
              <van-col :span="15">{{ item.VehicleImport | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">新车购置价：</van-col>
              <van-col :span="15">{{ item.PurchasePrice | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">新车购置价(含税)：</van-col>
              <van-col :span="15">{{ item.PurchasePriceTax | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">变速器类型：</van-col>
              <van-col :span="15">{{ item.GearboxType | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">安全气囊数量：</van-col>
              <van-col :span="15">{{ item.AirbagNum | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">额定座位数：</van-col>
              <van-col :span="15">{{ item.Seat | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">额定载质量：</van-col>
              <van-col :span="15">{{ item.Tonnage | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">ABS标识：</van-col>
              <van-col :span="15">{{ item.AbsFlag | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">整备质量：</van-col>
              <van-col :span="15">{{ item.FullWeightMax | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">是否有防盗装备：</van-col>
              <van-col :span="15">{{ item.AlarmFlag | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">行业车型编码：</van-col>
              <van-col :span="15">{{ item.IacVehicleCode | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">行业车型名称：</van-col>
              <van-col :span="15">{{ item.IacVehicleName | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">车船税减免标识：</van-col>
              <van-col :span="15">{{ item.HfName | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">车船税减免标识码：</van-col>
              <van-col :span="15">{{ item.HfCode | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">车船税减免起期：</van-col>
              <van-col :span="15">{{ item.HfStartDate | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">车船税减免止期：</van-col>
              <van-col :span="15">{{ item.HfEndDate | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">别名：</van-col>
              <van-col :span="15">{{ item.AliasName | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">类比价格：</van-col>
              <van-col :span="15">{{ item.KindredPrice | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">类比价格(含税)：</van-col>
              <van-col :span="15">{{ item.KindredPriceTax | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">商业险编码：</van-col>
              <van-col :span="15">{{ item.SyxInsuranceId | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">商业险名称：</van-col>
              <van-col :span="15">{{ item.SyxInsuranceName | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">交强险编码：</van-col>
              <van-col :span="15">{{ item.JqxInsuranceId | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col :span="9">交强险名称：</van-col>
              <van-col :span="15">{{ item.JqxInsuranceName | isEmpty }}</van-col>
            </van-row>
          </template>
        </My-info-box>
      </div>
    </div>

    <van-empty description="暂无数据" v-show="vehicleTypeList.length === 0" />
  </div>
</template>

<script>
import MyNavBar from '@/components/MyNavBar'
import MyInfoBox from '@/components/MyInfoBox'
import { getVehicleType } from '@/api'
import { isEmpty } from '@/utils/filiters'
import { getSession } from '@/utils/storage'
export default {
  name: 'VehicleType',
  components: { MyNavBar, MyInfoBox },
  filters: { isEmpty },
  data() {
    return {
      vehicleTypeList: [],
      vehicleTypeObj: {}
    }
  },
  mounted() {
    this.vhlByVINInit()
  },
  methods: {
    async vhlByVINInit() {
      // 测试数据可用 LSVAK20C4L2209199
      const something = getSession('something')
      const res = await getVehicleType({
        vin: something.cFrmNo
      })
      if (res && res.status === 1) {
        this.vehicleTypeList = res.data.Vehicle
        this.vehicleTypeObj = Object.assign({}, res.data.VehicleBase)
      } else {
        this.$toast('vin码验证失败')
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
