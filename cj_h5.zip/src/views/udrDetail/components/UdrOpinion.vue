<template>
  <div>
    <div>
      <My-info-box title="核保意见" v-if="opinionFlag">
        <template #other>
          <van-form>
            <!-- 核保选项 -->
            <van-field
              readonly
              clickable
              v-model="filterForm.undrMrkName"
              label="核保选项"
              placeholder="请选择"
              @click="showPicker = true"
            />
            <van-popup v-model="showPicker" position="bottom">
              <van-picker
                show-toolbar
                :columns="optList"
                @confirm="onConfirm"
                @cancel="showPicker = false"
                value-key="name"
              />
            </van-popup>

            <!-- 核保意见 -->
            <van-field
              v-model="filterForm.undrOpn"
              rows="4"
              autosize
              label="核保意见"
              type="textarea"
              placeholder="请输入内容"
              class="udr_opinion_text"
            />

            <van-field
              v-model.trim="filterForm.sms"
              center
              clearable
              placeholder="请输入短信验证码"
              class="base_effect"
              v-if="messsgeFlag !== '0' && $route.query.cType === 'E'"
              :disabled="!verifyFlag"
            >
              <template #button>
                <van-button
                  size="small"
                  type="info"
                  icon="chat"
                  @click="sendSMS"
                  :disabled="!verifyFlag"
                ></van-button>
              </template>
            </van-field>
          </van-form>
        </template>
      </My-info-box>

      <My-info-box title="历史核保意见">
        <template #other>
          <Old-opinion ref="oldOpinion" />
        </template>
      </My-info-box>
    </div>

    <van-row class="udr_opinion_btn" gutter="20" v-if="opinionFlag">
      <van-col :span="12"><van-button plain type="info" @click="optSave">暂存</van-button></van-col>
      <van-col :span="12"> <van-button type="info" @click="optSubmit">提交</van-button></van-col>
    </van-row>
  </div>
</template>

<script>
import { getUdrOpt, udrOptSave, udrOptSubmit, getUdrCode, verifyUdrCode } from '@/api'
import { getSession } from '@/utils/storage'
import MyInfoBox from '@/components/MyInfoBox'
import OldOpinion from './widget/OldOpinion'
export default {
  name: 'UdrOpinion',
  inject: {
    rootapp: {
      default: null
    }
  },
  components: {
    MyInfoBox,
    OldOpinion
  },
  data() {
    return {
      filterForm: {
        undrMrkName: '',
        undrMrk: '',
        undrOpn: '',
        sms: ''
      },
      showPicker: false,
      opinionFlag: true,
      verifyFlag: true
    }
  },
  computed: {
    messsgeFlag() {
      if (this.rootapp.infoList.correctInfo) {
        return this.rootapp.infoList.correctInfo.messsgeFlag
      }
      return '0'
    },
    cissueCode() {
      if (this.rootapp.infoList.correctInfo) {
        return this.rootapp.infoList.correctInfo.cissueCode
      }
      return ''
    },
    optList() {
      return this.rootapp.infoList.mrks
    }
  },
  mounted() {
    this.parInit()
  },
  methods: {
    // 参数初始化
    parInit() {
      const taskState = getSession('something').taskState
      if (taskState !== 'newUdr' && taskState !== 'pendUdr') {
        this.opinionFlag = false
        return
      }

      const cOpnSts = getSession('something').cOpnSts
      const cDptCde = getSession('something').cDptCde
      this.filterForm.appNo = this.$route.query.appNo
      this.filterForm.dptCde = cDptCde
      this.filterForm.sms = this.cissueCode
      if (cOpnSts === '0') {
        this.udrOptInit()
      } else {
        const flag = this.optList.some(item => {
          return item.code === 'A'
        })
        if (flag) {
          this.filterForm.undrMrkName = '同意'
          this.filterForm.undrMrk = 'A'
        }
      }
    },

    // 点击完成按钮时触发
    onConfirm(value) {
      console.log(value)
      this.filterForm.undrMrkName = value.name
      this.filterForm.undrMrk = value.code

      this.showPicker = false
    },

    // 暂存意见查询
    async udrOptInit() {
      const res = await getUdrOpt({
        appNo: this.filterForm.appNo
      })
      console.log(res, '暂存意见查询')
      if (res && res.status === 1) {
        this.filterForm.undrMrk = res.data.undrMrkBack
        this.filterForm.undrOpn = res.data.undrOpnBack
        this.optList.forEach(item => {
          if (item.code === this.filterForm.undrMrk) {
            this.filterForm.undrMrkName = item.name
          }
        })
      } else {
        this.$toast.fail(res.message)
      }
    },

    // 暂存
    async optSave() {
      if (!this.filterForm.undrMrkName) {
        this.$toast('请输入核保选项')
        return
      }
      this.$toast.loading({
        message: '加载中...',
        forbidClick: true,
        duration: 0
      })
      const res = await udrOptSave(this.filterForm)

      if (res && res.status === 1) {
        this.$toast.success(res.data.returnMassage)
      } else {
        this.$toast.fail(res.message)
      }
    },

    // 提交
    async optSubmit() {
      if (!this.filterForm.undrMrkName) {
        this.$toast('请输入核保选项')
        return
      }

      this.verifyUdrCode().then(async res => {
        console.log(res)
        if (res) {
          this.$toast.loading({
            message: '加载中...',
            forbidClick: true,
            duration: 0
          })
          const res = await udrOptSubmit(this.filterForm)
          console.log(res)
          if (res && res.status === 1) {
            this.$toast.success(res.data.returnMassage)
            this.opinionFlag = false
            this.$refs.oldOpinion.opnInfoInit()
          } else {
            this.$toast.fail(res.message)
          }
        }
      })
    },

    // 发送验证码
    async sendSMS() {
      const res = await getUdrCode({
        appNo: this.filterForm.appNo,
        dptCde: this.filterForm.dptCde
      })
      console.log(res)
      if (res && res.status === 1) {
        if (res.data === '无需发送短信!') {
          this.$toast(res.data)
          this.verifyFlag = false
        } else {
          this.$toast.success('短信发送成功')
        }
      } else {
        this.$toast.fail(res.message)
      }
    },

    // 特殊情况需先验证验证码
    async verifyUdrCode() {
      if (
        this.messsgeFlag !== '0' &&
        this.$route.query.cType === 'E' &&
        this.filterForm.undrMrkName === '同意'
      ) {
        if (this.verifyFlag) {
          console.log(this.filterForm.sms)
          const res = await verifyUdrCode({
            appNo: this.filterForm.appNo,
            captcha: this.filterForm.sms,
            dptCde: this.filterForm.dptCde
          })
          console.log(res, '验证验证码')
          if (res && res.status === 1) {
            return true
          } else {
            this.$toast(res.message)
            return false
          }
        } else {
          return true
        }
      } else {
        return true
      }
    }
  }
}
</script>

<style scoped lang="less">
/deep/ .van-collapse-item__content {
  padding: 0;
}

.udr_opinion_btn {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  background: #fff;
  padding: 20px;
  padding-bottom: constant(safe-area-inset-bottom); ///兼容 IOS<11.2/
  padding-bottom: env(safe-area-inset-bottom); ///兼容 IOS>11.2/
  .van-button {
    width: 100%;
    font-weight: 900;
    font-size: 36px;
  }
}

.udr_opinion_text {
  flex-direction: column;
  /deep/ .van-cell__value {
    margin-top: 8px;
    padding: 10px 20px;
    background: #f5f5f5;
  }
}

/deep/ .info_collapse:nth-last-child(1) {
  padding-bottom: 120px;
  padding-bottom: calc(120px + constant(safe-area-inset-bottom));
  padding-bottom: calc(120px + env(safe-area-inset-bottom));
}

/deep/ .base_effect {
  .van-field__body {
    border-radius: 8px;
    height: 88px;
    padding-left: 20px;
    background: #f5f5f5;
  }
  .van-button {
    border-radius: 0 8px 8px 0;
    width: 88px;
    height: 88px;
    .van-icon {
      font-size: 48px;
    }
  }
}

/deep/ .van-popup.van-popup--bottom {
  .van-picker__cancel,
  .van-picker__confirm,
  .van-picker-column {
    font-size: 36px !important;
  }
}
</style>
