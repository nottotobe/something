<template>
  <div>
    <van-tabs :class="'info_tabs ' + changePo" color="#fff" ref="gogogo">
      <van-tab
        v-for="(item, index) in newGridList"
        :key="index"
        :to="{
          path: '/udrType',
          query: {
            id: item.id
          }
        }"
      >
        <template #title>
          <van-image slot="icon" :src="item.src" />
          <div>{{ item.text }}</div>
        </template>
      </van-tab>
    </van-tabs>

    <van-cell :title="`申请单号：${$route.query.appNo}`" class="public_cell_number" />

    <div v-for="(item, index) in newUdrInfoTitleList" :key="index">
      <My-info-box
        :title="item.title"
        :keyword="item.keyword"
        :obj="infoList[item.keyword]"
        :span="item.span"
        :index="item.index"
      >
        <template #other>
          <Personal-info :perObj="infoList[item.keyword]" v-if="item.keyword === 'personalInfo'" />
          <Cvrg-info :cvrgList="infoList[item.keyword]" v-if="item.keyword === 'cvrgInfo'" />
          <Car-info :carObj="infoList[item.keyword]" v-if="item.keyword === 'vehicleInfo'" />
          <Time-info :timeObj="infoList[item.keyword]" v-if="item.keyword === 'timeInfo'" />
          <Mechine-info :mechineList="infoList[item.keyword]" v-if="item.keyword === 'mechine'" />
          <Ners-info :nersList="infoList[item.keyword]" v-if="item.keyword === 'ners'" />
        </template>
      </My-info-box>
    </div>
  </div>
</template>

<script>
import MyInfoBox from '@/components/MyInfoBox'
import PersonalInfo from './widget/PersonalInfo'
import CvrgInfo from './widget/CvrgInfo'
import CarInfo from './widget/CarInfo'
import TimeInfo from './widget/TimeInfo'
import MechineInfo from './widget/MechineInfo'
import NersInfo from './widget/NersInfo'
export default {
  name: 'UdrInfo',
  components: {
    MyInfoBox,
    PersonalInfo,
    CvrgInfo,
    CarInfo,
    TimeInfo,
    MechineInfo,
    NersInfo
  },
  props: {
    infoList: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      changePo: '',
      gridList: [
        {
          id: 'car',
          text: '车型保费',
          src: require('@img/info/car.png'),
          flag: 'SY'
        },
        {
          id: 'cost',
          text: '费用信息',
          src: require('@img/info/cost.png')
        },
        {
          id: 'image',
          text: '影像信息',
          src: require('@img/info/image.png')
        },
        {
          id: 'rule',
          text: '规则信息',
          src: require('@img/info/rule.png')
        },
        {
          id: 'policy',
          text: '历史保单',
          src: require('@img/info/policy.png')
        },
        {
          id: 'claim',
          text: '历史赔案',
          src: require('@img/info/claim.png')
        }
      ],
      udrInfoTitleList: [
        { title: '交强险', keyword: 'insuredPolicyInfo' },
        { title: '商业险', keyword: 'insuredPolicyInfo' },
        { title: '交强险', keyword: 'correctPolicyInfo', span: 9 },
        { title: '商业险', keyword: 'correctPolicyInfo', span: 9 },
        { title: '车船税', keyword: 'vstax', span: 9 },
        { title: '险别信息', keyword: 'cvrgInfo' },
        { title: '新能源充电桩', keyword: 'ners' },
        { title: '驾乘人员意外伤害保险', keyword: 'nvl', span: 9 },
        { title: '新增设备明细', keyword: 'mechine' },
        { title: '基本信息', keyword: 'baseInfo', span: 9 },
        { title: '时间信息', keyword: 'timeInfo' },
        { title: '人员信息', keyword: 'personalInfo' },
        { title: '车辆信息', keyword: 'vehicleInfo' },
        { title: '发票信息', keyword: 'invoiceInfo', span: 7, index: 0 },
        { title: '交强险系数', keyword: 'jqPrmCoefInfo', span: 12 },
        { title: '商业险系数', keyword: 'syPrmCoefInfo', span: 12 },
        { title: '账户信息', keyword: 'account', span: 7, index: 0 }
      ]
    }
  },
  computed: {
    newUdrInfoTitleList() {
      const query = this.$route.query
      const AList = []
      const BList = []
      for (const k in this.infoList) {
        if (String(this.infoList[k]) !== 'null') {
          AList.push(k)
        }
      }
      console.log(AList)
      this.udrInfoTitleList.forEach(item => {
        AList.forEach(value => {
          if (item.keyword === value) {
            if (query.flag === 'JQ' && item.title !== '商业险' && item.title !== '险别信息') {
              BList.push(item)
            }
            if (query.flag === 'SY' && item.title !== '交强险') {
              BList.push(item)
            }
          }
        })
      })
      console.log(BList)
      return BList
    },
    newGridList() {
      const query = this.$route.query
      if (query.flag === 'JQ') {
        return this.gridList.filter(item => {
          return item.flag !== 'SY'
        })
      }
      return this.gridList
    }
  },
  created() {},
  mounted() {
    this.$refs.gogogo.$el.addEventListener('touchmove', this.tabsMove, { passive: true })
  },
  beforeDestroy() {
    this.$refs.gogogo.$el.removeEventListener('touchmove', this.tabsMove)
  },
  methods: {
    tabsMove(e) {
      e.stopPropagation()
    }
  }
}
</script>

<style scoped lang="less">
.info_tabs {
  top: 0;
  height: 168px;
  /deep/ .van-tabs__wrap {
    height: 100%;
    .van-tab--active {
      color: #646566;
      font-weight: unset;
    }
    .van-tab__text {
      height: 100%;
      display: flex;
      justify-content: center;
      flex-direction: column;
      align-items: center;
      font-weight: unset;
      .van-image {
        width: 64px;
        height: 64px;
        margin-bottom: 12px;
      }
    }
  }
}

.changePo {
  position: sticky;
  transition: top 1s;
  width: 100%;
  top: 180px;
  z-index: 20;
  box-shadow: #d8dbe0 0px 3px 8px;
}
</style>
