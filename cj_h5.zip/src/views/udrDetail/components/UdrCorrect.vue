<template>
  <div>
    <van-cell :title="`批改申请单号：${$route.query.appNo}`" class="public_cell_number" />

    <div v-for="(item, index) in udrCorrectList" :key="index" :class="'correctbox' + index">
      <My-info-box
        :title="item.title"
        :keyword="item.keyword"
        :obj="infoList[item.keyword]"
        :span="item.span"
      >
        <template #other>
          <Correct-compare
            :compareList="infoList[item.keyword]"
            v-if="item.keyword === 'correctCompare'"
          />
          <Correct-reason
            :reasonList="infoList[item.keyword]"
            v-if="item.keyword === 'correctReason'"
          />
        </template>
      </My-info-box>
    </div>
  </div>
</template>

<script>
import MyInfoBox from '@/components/MyInfoBox'
import CorrectCompare from './widget/CorrectCompare'
import CorrectReason from './widget/CorrectReason'
export default {
  name: 'UdrCorrect',
  components: {
    MyInfoBox,
    CorrectCompare,
    CorrectReason
  },
  props: {
    infoList: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      udrCorrectList: [
        { title: '批改信息', keyword: 'correctInfo', span: '8' },
        { title: '批改原因', keyword: 'correctReason' },
        { title: '批改比较项', keyword: 'correctCompare' }
      ]
    }
  },
  methods: {}
}
</script>

<style scoped lang="less">
.correctbox0 {
  /deep/ .van-collapse-item__content {
    .info_row:last-child {
      .van-col:last-child {
        color: #2447b7;
      }
    }
  }
}
</style>
