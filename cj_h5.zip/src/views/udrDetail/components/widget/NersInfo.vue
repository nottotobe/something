<template>
  <div>
    <div v-if="nersList.length > 0">
      <div v-for="(item, index) in nersList" :key="index">
        <van-row>
          <van-col span="9">充电桩种类：</van-col>
          <van-col span="15">{{ item.CChargingTyp | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">充电桩安装地点：</van-col>
          <van-col span="15">{{ item.CChargingLocation | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">充电桩使用年限：</van-col>
          <van-col span="15">{{ item.CChargingLife | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">充电桩编码：</van-col>
          <van-col span="15">{{ item.CChargingCde | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">充电桩型号：</van-col>
          <van-col span="15">{{ item.CChargingModel | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">充电桩地址：</van-col>
          <van-col span="15">{{ item.CChargingAddr | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">损失险保额：</van-col>
          <van-col span="15">{{ item.CLossSumlimit | isEmpty | units({ unit: '元' }) }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">责任险保额：</van-col>
          <van-col span="15">{{
            item.CLiabilitySumlimit | isEmpty | units({ unit: '元' })
          }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">损失险基础保费：</van-col>
          <van-col span="15">{{ item.CLossBasePrm | isEmpty | units({ unit: '元' }) }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">责任险基础保费：</van-col>
          <van-col span="15">{{
            item.CLiabilityBasePrm | isEmpty | units({ unit: '元' })
          }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">损失险签单保费：</van-col>
          <van-col span="15">{{ item.CLossPrm | isEmpty | units({ unit: '元' }) }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">责任险签单保费：</van-col>
          <van-col span="15">{{ item.CLiabilityPrm | isEmpty | units({ unit: '元' }) }}</van-col>
        </van-row>

        <van-divider v-if="nersList.length > 1 && index !== nersList.length - 1" />
      </div>
    </div>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import { isEmpty, units } from '@/utils/filiters'
export default {
  name: 'NersInfo',
  filters: { isEmpty, units },
  props: {
    nersList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less">
.van-row {
  margin-bottom: 8px;
  .van-col:nth-child(2) {
    color: #323233;
  }
}
</style>
