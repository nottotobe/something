<template>
  <div>
    <van-row class="personal_info_row">
      <van-col :span="20" class="personal_info_title">
        <span>{{ applicantInfo.cAppNme | isEmpty }}</span>
        <van-icon name="warning-o" @click="showPopover = true" />
      </van-col>
      <van-col :span="6">证件类型：</van-col>
      <van-col :span="18">{{ applicantInfo.cCertfCls | isEmpty }}</van-col>
      <van-col :span="6">证件号码：</van-col>
      <van-col :span="18">{{ applicantInfo.cCertfCde | isEmpty }}</van-col>
      <van-col :span="6">联系电话：</van-col>
      <van-col :span="18">{{ applicantInfo.cMobile | isEmpty }}</van-col>
      <van-tag color="#d9e9ff" text-color="#6085ff" class="personal_info_tag" size="large"
        >投保人</van-tag
      >
    </van-row>

    <van-row class="personal_info_row">
      <div v-if="insuredInfoFlag">
        <van-col :span="6" style="font-weight:900">被保人</van-col>
        <van-col :span="18">同投保人</van-col>
      </div>
      <div v-else>
        <van-col :span="20" style="font-weight:900">{{
          insuredInfo.cInsuredNme | isEmpty
        }}</van-col>
        <van-col :span="6">证件类型：</van-col>
        <van-col :span="18">{{ insuredInfo.cCertfCls | isEmpty }}</van-col>
        <van-col :span="6">证件号码：</van-col>
        <van-col :span="18">{{ insuredInfo.cCertfCde | isEmpty }}</van-col>
        <van-col :span="6">联系电话：</van-col>
        <van-col :span="18">{{ insuredInfo.cMobile | isEmpty }}</van-col>
      </div>
      <van-tag color="#eddeff" text-color="#7901ff" class="personal_info_tag" size="large"
        >被保人</van-tag
      >
    </van-row>

    <van-row class="personal_info_row">
      <div v-if="vhlOwnerInfoFlag">
        <van-col :span="6" style="font-weight:900">车主</van-col>
        <van-col :span="18">同投保人</van-col>
      </div>
      <div v-else>
        <van-col :span="20" style="font-weight:900">{{ vhlOwnerInfo.cOwnerNme | isEmpty }}</van-col>
        <van-col :span="6">证件类型：</van-col>
        <van-col :span="18">{{ vhlOwnerInfo.cCertfCls | isEmpty }}</van-col>
        <van-col :span="6">证件号码：</van-col>
        <van-col :span="18">{{ vhlOwnerInfo.cCertfCde | isEmpty }}</van-col>
        <van-col :span="6">联系电话：</van-col>
        <van-col :span="18">{{ vhlOwnerInfo.cResvTxt1 | isEmpty }}</van-col>
      </div>
      <van-tag color="#fff6e8" text-color="#ffaf4e" class="personal_info_tag" size="large"
        >车主</van-tag
      >
    </van-row>

    <van-dialog
      v-model="showPopover"
      close-on-click-overlay
      :show-confirm-button="false"
      class="dialog_box"
    >
      <van-col :span="24" style="font-weight:900">投保人信息</van-col>
      <van-col :span="4">地址：</van-col>
      <van-col :span="20">{{ applicantInfo.cClntAddr | isEmpty }}</van-col>
      <van-col :span="4">邮编：</van-col>
      <van-col :span="20">{{ applicantInfo.zipCode | isEmpty }}</van-col>
    </van-dialog>
  </div>
</template>

<script>
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'PersonalInfo',
  props: {
    perObj: {
      type: Object,
      default: () => ({})
    }
  },
  filters: { isEmpty },
  data() {
    return {
      applicantInfo: {},
      insuredInfo: {},
      vhlOwnerInfo: {},
      insuredInfoFlag: false,
      vhlOwnerInfoFlag: false,
      showPopover: false,
      actions: []
    }
  },
  watch: {
    perObj(newValue) {
      this.personalInfoInit(newValue)
    }
  },
  mounted() {},
  created() {
    this.personalInfoInit(this.perObj)
  },
  methods: {
    personalInfoInit(newValue) {
      if (newValue) {
        this.applicantInfo = Object.assign({}, newValue.applicantInfo)
        this.insuredInfo = Object.assign({}, newValue.insuredInfo)
        this.vhlOwnerInfo = Object.assign({}, newValue.vhlOwnerInfo)
        if (this.insuredInfo.cCertfCde === this.applicantInfo.cCertfCde) {
          this.insuredInfoFlag = true
        }
        if (this.vhlOwnerInfo.cCertfCde === this.applicantInfo.cCertfCde) {
          this.vhlOwnerInfoFlag = true
        }
      }
    }
  }
}
</script>

<style scoped lang="less">
.personal_info_row {
  position: relative;
  background: #f5f5f5;
  padding: 20px;
  color: #333333;
  margin-bottom: 20px;
  .personal_info_tag {
    width: 100px;
    justify-content: center;
    position: absolute;
    top: 0;
    right: 0;
  }
  .personal_info_title {
    font-weight: 900;
    .van-icon {
      vertical-align: -3px;
      margin-left: 8px;
      color: #4470ff;
    }
  }
}

.dialog_box {
  padding: 32px;
  border-radius: 8px;
  .van-col {
    margin-top: 22px;
    color: #666666;
  }
  .van-col--24 {
    margin-top: 0;
    font-weight: 900;
    color: #333333;
  }
}
</style>
