<template>
  <div>
    <van-row>
      <van-col span="7">投保申请日期：</van-col>
      <van-col span="17">{{ timeObj.tAppTm | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="7">保险起止期：</van-col>
      <van-col span="17">{{ newTime | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="7">保险期限：</van-col>
      <van-col span="17">{{ timeObj.cperiod | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="7">短期系数：</van-col>
      <van-col span="17">{{ timeObj.nRatioCoef | isEmpty }}</van-col>
    </van-row>

    <van-divider />
    <van-cell
      title="是否立即生效"
      :value="timeObj.cImmeffMrk === '0' ? '否' : '是'"
      class="time_effect"
    />
  </div>
</template>

<script>
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'TimeInfo',
  filters: { isEmpty },
  props: {
    timeObj: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    newTime() {
      return this.timeObj.tInsrncBgnTm + ' 至 ' + this.timeObj.tInsrncEndTm
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less">
.van-row {
  margin-bottom: 8px;
  .van-col:nth-child(2) {
    color: #323233;
  }
}

.time_effect {
  padding: 0;
  font-weight: 700;
  color: #333333;
  .van-cell__value {
    color: #333333;
  }
}
</style>
