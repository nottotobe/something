<template>
  <div>
    <div v-if="reasonList.length > 0">
      <div v-for="(item, index) in reasonList" :key="index">
        <van-row>
          <van-col span="8">批改原因：</van-col>
          <van-col span="16">{{ item.cEdrRsnNme | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="8">批改原因代码：</van-col>
          <van-col span="16">{{ item.cEdrRsnCde | isEmpty }}</van-col>
        </van-row>

        <van-divider v-if="reasonList.length > 1 && index !== reasonList.length - 1" />
      </div>
    </div>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'CorrectReason',
  filters: { isEmpty },
  props: {
    reasonList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less">
.van-row {
  margin-bottom: 8px;
  .van-col:nth-child(2) {
    color: #323233;
  }
}
</style>
