<template>
  <div>
    <div v-if="compareList.length > 0">
      <div v-for="(item, index) in compareList" :key="index">
        <van-row>
          <van-col span="6">批改对象：</van-col>
          <van-col span="18">{{ item.cTabNme | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="6">批改项目：</van-col>
          <van-col span="18">{{ item.cFldNme | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="6">原值：</van-col>
          <van-col span="18">{{ item.cOldVal | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="6">变化：</van-col>
          <van-col span="18">{{ item.cChgVal | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="6">新值：</van-col>
          <van-col span="18">{{ item.cNewVal | isEmpty }}</van-col>
        </van-row>

        <van-divider v-if="compareList.length > 1 && index !== compareList.length - 1" />
      </div>
    </div>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'CorrectCompare',
  filters: { isEmpty },
  props: {
    compareList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less">
.van-row {
  margin-bottom: 8px;
  .van-col:nth-child(2) {
    color: #323233;
  }
}
</style>
