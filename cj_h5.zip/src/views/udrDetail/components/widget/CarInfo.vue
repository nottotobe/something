<template>
  <div class="car_box">
    <van-row>
      <van-col span="10">车辆类型：</van-col>
      <van-col span="14">{{ carObj.cVhlTyp | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">车牌号码：</van-col>
      <van-col span="14">{{ carObj.cPlateNo | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">VIN/车架号：</van-col>
      <van-col span="14">{{ carObj.cFrmNo | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">发动机号：</van-col>
      <van-col span="14">{{ carObj.cEngNo | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">号牌种类：</van-col>
      <van-col span="14">{{ carObj.cPlateTyp | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">品牌车型：</van-col>
      <van-col span="12">{{ carObj.cModelNme | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">车辆种类：</van-col>
      <van-col span="14">{{ carObj.cVhlcategoryCde | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">使用性质：</van-col>
      <van-col span="14">{{ carObj.cUsageCde | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">交管车辆类型：</van-col>
      <van-col span="14">{{ carObj.cRegVhlTyp | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">核定载质量：</van-col>
      <van-col span="14">{{ carObj.nTonage | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">整备质量：</van-col>
      <van-col span="14">{{ carObj.outfitQuality | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">车龄：</van-col>
      <van-col span="14">{{ carObj.cUseYear | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">初登日期：</van-col>
      <van-col span="14">{{ carObj.cFstRegYm | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">行驶证发证日期：</van-col>
      <van-col span="14">{{ carObj.tDriverLienceYm | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">新车购置价：</van-col>
      <van-col span="14">{{ carObj.nNewPurchaseValue | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">过户车辆标志：</van-col>
      <van-col span="14">{{ carObj.cChgOwnerFlag | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">座位数：</van-col>
      <van-col span="14">{{ carObj.nSeatNum | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">进口/国产：</van-col>
      <van-col span="14">{{ carObj.cProdPlace | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">行驶证车主：</van-col>
      <van-col span="14">{{ carObj.cRegOwner | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">车型风险标志：</van-col>
      <van-col span="14">{{ carObj.cRiskFlag | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="10">被保险人与车辆关系：</van-col>
      <van-col span="14">{{ carObj.cVhlRelCde | isEmpty }}</van-col>
    </van-row>
    <van-collapse v-model="activeNames" accordion class="car_collapse" :border="false">
      <van-collapse-item title="查看更多" name="1">
        <van-row>
          <van-col span="10">验车情况：</van-col>
          <van-col span="14">{{ carObj.cInspectionCde | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="10">免验原因：</van-col>
          <van-col span="14">{{ carObj.cResvTxt1 | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="10">验车人：</van-col>
          <van-col span="14">{{ carObj.cInspectorNme | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="10">验车结果：</van-col>
          <van-col span="14">{{ carObj.cInspectRec | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="10">验车时间：</van-col>
          <van-col span="14">{{ carObj.cInspectTm | isEmpty }}</van-col>
        </van-row>
      </van-collapse-item>
    </van-collapse>

    <van-image
      class="car_icon car_choose"
      :src="require('@img/list/car_choose.png')"
      @click="$router.push('/vehicleType')"
    />

    <van-image
      class="car_icon car_search"
      :src="require('@img/list/car_search.png')"
      @click="toVehicleQuery"
    />
  </div>
</template>

<script>
import { isEmpty } from '@/utils/filiters'
import { setSession } from '@/utils/storage'
export default {
  name: 'CarInfo',
  filters: { isEmpty },
  props: {
    carObj: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      activeNames: '2'
    }
  },
  mounted() {},
  methods: {
    toVehicleQuery() {
      this.$router.push('/vehicleQuery')
      setSession('vehicleQueryWD', this.carObj.cModelNme)
    }
  }
}
</script>

<style scoped lang="less">
.car_box {
  position: relative;
  .van-row {
    margin-bottom: 8px;
    .van-col:nth-child(2) {
      color: #323233;
    }
  }
  .car_collapse {
    /deep/ .van-collapse-item__title {
      padding: 0;
      color: #6287ff;
      margin-bottom: 8px;
      &::after {
        border-bottom: none;
      }
      .van-cell__title {
        flex: unset;
      }
      .van-icon {
        color: #6287ff;
      }
    }
    /deep/ .van-collapse-item__content {
      padding: 0;
    }
  }
  .car_icon {
    position: absolute;
    right: 0;
    color: #5980ff;
    width: 48px;
    height: 48px;
  }

  .car_choose {
    top: 90px;
  }

  .car_search {
    top: 240px;
  }
}
</style>
