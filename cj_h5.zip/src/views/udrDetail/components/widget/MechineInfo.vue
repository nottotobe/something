<template>
  <div>
    <div v-if="mechineList.length > 0">
      <div v-for="(item, index) in mechineList" :key="index">
        <van-row>
          <van-col span="9">设备名称：</van-col>
          <van-col span="15">{{ item.CNme | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">设备数量：</van-col>
          <van-col span="15">{{ item.NBuyNum | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">购置日期：</van-col>
          <van-col span="15">{{ item.TBuyTime | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">购置价格：</van-col>
          <van-col span="15">{{ item.NPrice | isEmpty | units({ unit: '元' }) }}</van-col>
        </van-row>
        <van-row>
          <van-col span="9">实际价格小计：</van-col>
          <van-col span="15">{{ item.NTotalPrice | isEmpty | units({ unit: '元' }) }}</van-col>
        </van-row>

        <van-divider v-if="mechineList.length > 1 && index !== mechineList.length - 1" />
      </div>
    </div>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import { isEmpty, units } from '@/utils/filiters'
export default {
  name: 'MechineInfo',
  filters: { isEmpty, units },
  props: {
    mechineList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less">
.van-row {
  margin-bottom: 8px;
  .van-col:nth-child(2) {
    color: #323233;
  }
}
</style>
