<template>
  <div>
    <van-row class="public_table_title">
      <van-col span="12">保险项目</van-col>
      <van-col span="6">保额</van-col>
      <van-col span="6">保费</van-col>
    </van-row>

    <van-row
      class="public_table_content"
      v-for="(item, index) in cvrgList"
      :key="index"
      type="flex"
    >
      <van-col span="12">{{ item.CNMECN }}</van-col>
      <van-col span="6">{{ item.NAMT }}</van-col>
      <van-col span="6">{{ item.NNETPRM + '元' }}</van-col>
    </van-row>
  </div>
</template>

<script>
export default {
  name: 'CvrgInfo',
  props: {
    cvrgList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {}
  },
  methods: {}
}
</script>

<style scoped lang="less"></style>
