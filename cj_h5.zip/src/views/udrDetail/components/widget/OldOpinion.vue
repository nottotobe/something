<template>
  <div>
    <div v-if="oldOpinionList.length > 0">
      <div v-for="(item, index) in oldOpinionList" :key="index">
        <van-cell>
          <template #label>
            <div style="white-space: pre-wrap">{{ newCundrOpn(item.cundrOpn) }}</div>
          </template>
          <template #title>
            <div class="old_opinion_title">
              <span class="old_opinion_title">
                <span style="font-weight:900">{{ item.cundrMrk }}</span>
                &nbsp;/ {{ item.cundrCnm }}
              </span>
              <span class="old_opinion_time">
                {{ item.tundrTm }}
              </span>
            </div>
          </template>
        </van-cell>
      </div>
    </div>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import { getOpnInfo } from '@/api'
export default {
  name: 'OldOpinion',
  data() {
    return {
      oldOpinionList: []
    }
  },
  created() {
    this.opnInfoInit()
  },
  computed: {
    newCundrOpn() {
      return function(value) {
        if (value && value.indexOf('备注') !== -1) {
          value = value.replace(/备注/g, '\n备注')
        }
        console.log(value)
        return value
      }
    }
  },
  methods: {
    async opnInfoInit() {
      const res = await getOpnInfo({
        appNo: this.$route.query.appNo,
        billType: this.$route.query.cType
      })

      if (res && res.status === 1) {
        this.oldOpinionList = res.data
      } else {
        this.$toast.fail('历史核保意见请求异常')
      }
    }
  }
}
</script>

<style scoped lang="less">
.old_opinion_title {
  display: flex;
  justify-content: space-between;
}
</style>
