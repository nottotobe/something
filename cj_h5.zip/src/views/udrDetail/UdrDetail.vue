<template>
  <div class="public_box">
    <My-nav-bar title="申请单详情" :params="routeObj" />

    <van-tabs
      v-model="active"
      color="#5980ff"
      title-active-color="#5980ff"
      class="detail_tabs"
      swipeable
      :sticky="sticky"
      :offset-top="offsetTop"
    >
      <van-tab title="批改信息" name="E" v-if="$route.query.cType === 'E'">
        <Udr-correct :infoList="infoList" />
      </van-tab>
      <van-tab :title="udrInfoTitle" name="A">
        <Udr-info :infoList="infoList" ref="udrInfo" />
      </van-tab>
      <van-tab title="核保意见" name="EA">
        <Udr-opinion />
      </van-tab>
    </van-tabs>
  </div>
</template>

<script>
import { getUdrInfo, udrOptSave } from '@/api'
import { getSession, setSession, removeSession } from '@/utils/storage'
import { iosScroll } from '@/mixins'
import MyNavBar from '@/components/MyNavBar'
import UdrCorrect from './components/UdrCorrect'
import UdrInfo from './components/UdrInfo'
import UdrOpinion from './components/UdrOpinion'
export default {
  name: 'UdrDetail',
  components: { MyNavBar, UdrCorrect, UdrInfo, UdrOpinion },
  mixins: [iosScroll],
  provide() {
    return {
      rootapp: this
    }
  },
  data() {
    return {
      active: 'A',
      infoList: {},
      routeObj: null
    }
  },
  computed: {
    udrInfoTitle() {
      const taskState = getSession('something').taskState
      if (taskState === 'completeUdr') {
        return '保单信息'
      } else {
        return '投保单信息'
      }
    }
  },
  mounted() {
    this.udrInfoInit()
    this.getBackParams()
  },
  methods: {
    // 获取投保单详情
    async udrInfoInit() {
      this.$toast.loading({
        message: '加载中...',
        forbidClick: true,
        duration: 0
      })
      const res = await getUdrInfo({
        cAppNo: this.$route.query.appNo,
        cType: this.$route.query.cType,
        cProdNo: this.$route.query.cProdNo
      })
      console.log(res)
      if (res && res.status === 1) {
        this.infoList = Object.assign({}, res.data)
        this.$toast.clear()
        setSession('nId', res.data.nId)
        this.saveUdr(res.data.baseInfo.cDptCde)
      } else {
        this.$toast.fail('投保单详情请求异常')
      }
    },

    // 对待核保任务进行暂存
    async saveUdr(cDptCde) {
      const taskStatus = getSession('taskStatus')
      if (taskStatus === 'newUdr') {
        const res = await udrOptSave({
          appNo: this.$route.query.appNo,
          dptCde: cDptCde
        })
        if (res && res.status === 1) {
          this.$toast.success(res.data.returnMassage)
          removeSession('taskStatus')
        } else {
          this.$toast.fail('暂存' + res.message)
          removeSession('taskStatus')
        }
      }
    },

    // 回退操作参数
    getBackParams() {
      const something = getSession('something')
      this.routeObj = {
        path: something.dataPath,
        query: something.dataPath === '/udrList' ? { id: something.taskState } : {}
      }
    }
  }
}
</script>

<style scoped lang="less">
.public_box {
  display: flex;
  flex-direction: column;
}
.detail_tabs {
  flex: 1;
  display: flex;
  flex-direction: column;
  /deep/ .van-tab__text {
    font-weight: 900;
  }
  /deep/ .van-tabs__content {
    flex: 1;
  }
}
</style>
