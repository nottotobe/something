<template>
  <div style="height:100%">
    <!-- 路由占位符 -->
    <router-view />

    <van-tabbar v-model="active" route class="main_tabbar" placeholder>
      <van-tabbar-item to="/policy">
        <template #icon>
          <span class="iconfont icon-udr"></span>
        </template>
        <span>核保单</span>
      </van-tabbar-item>
      <van-tabbar-item icon="chat" to="/message">
        <template #icon>
          <span class="iconfont icon-message"></span>
        </template>
        <span>消息</span>
      </van-tabbar-item>
      <van-tabbar-item icon="manager" to="/user">
        <template #icon>
          <span class="iconfont icon-user"></span>
        </template>
        <span>我的</span>
      </van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
export default {
  name: 'Main',
  data() {
    return {
      active: 0
    }
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less">
.main_tabbar {
  height: 100px !important;
  user-select: none;
  /deep/ .van-tabbar--fixed {
    background: #f8f8f8;
  }

  .iconfont {
    font-size: 40px;
  }

  .van-tabbar-item--active {
    color: #5980ff;
  }
}
</style>
