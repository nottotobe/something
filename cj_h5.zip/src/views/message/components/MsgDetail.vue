<template>
  <div class="public_box">
    <My-nav-bar title="消息详情" params="/message" />
    <van-cell :border="false" class="message_cell">
      <template #title>
        <div class="message_title">
          <span>{{ DTitle }}</span>
          <span>{{ msgDetail.tAppTm }}</span>
        </div>
      </template>
      <template #label>
        <div class="van-ellipsis">申请单号{{ msgDetail.appNo }}，{{ DValue }}</div>
      </template>
    </van-cell>

    <van-cell class="msg_cell" @click="toUdrDetail">
      <template #title>
        <div class="list_cell_title">
          <span class="list_cell_name">{{ msgDetail.appName }}</span>
          <span class="list_cell_icon">
            <van-tag plain type="primary">{{ msgDetail.cProdNo === '0350' ? '交' : '商' }}</van-tag>
            <van-tag plain type="warning">{{ msgDetail.cType === 'A' ? '保' : '批' }}</van-tag>
          </span>
        </div>
      </template>
      <template #label>
        <div>
          申请单号：<span>{{ msgDetail.appNo | isEmpty }}</span>
        </div>
        <div>
          车牌号码：<span>{{ msgDetail.vhlPlateNo | isEmpty }}</span>
        </div>
        <div>
          投保日期：<span>{{ msgDetail.appTime | isEmpty }}</span>
        </div>
        <div>
          保费合计：<span style="color:red">¥ {{ msgDetail.nprm | isEmpty }}</span>
        </div>
        <van-image class="msg_img" :src="DSrc" v-show="undrMrk !== 'C'" />
      </template>
    </van-cell>
  </div>
</template>

<script>
import { getMsgDetail } from '@/api'
import { getSession, setSession } from '@/utils/storage'
import { isEmpty } from '@/utils/filiters'
import MyNavBar from '@/components/MyNavBar'
export default {
  name: 'MsgDetail',
  components: {
    MyNavBar
  },
  filters: { isEmpty },
  data() {
    return {
      msgDetail: {}
    }
  },
  computed: {
    undrMrk() {
      return getSession('messageQ').undrMrk
    },
    DTitle() {
      if (this.undrMrk === 'A') {
        return '申请单通过'
      } else if (this.undrMrk === 'B') {
        return '申请单退回'
      }
      return '申请单上报'
    },
    DValue() {
      if (this.undrMrk === 'A') {
        return '审核通过'
      } else if (this.undrMrk === 'B') {
        return '审核退回'
      }
      return '核保上报'
    },
    DSrc() {
      if (this.undrMrk === 'A') {
        return require('@img/message/checkpass.png')
      } else if (this.undrMrk === 'B') {
        return require('@img/message/checkback.png')
      }
      return ''
    }
  },
  mounted() {
    this.msgDetailInit()
  },
  methods: {
    async msgDetailInit() {
      const res = await getMsgDetail({
        cAppNo: getSession('messageQ').cAppNo,
        messageId: getSession('messageQ').messageId
      })
      if (res && res.status === 1) {
        this.msgDetail = Object.assign({}, res.data)
      }
      console.log(res)
    },

    toUdrDetail() {
      const routeObj = {
        appNo: this.msgDetail.appNo,
        cProdNo: this.msgDetail.cProdNo,
        cType: this.msgDetail.cType,
        flag: this.msgDetail.cProdNo === '0350' ? 'JQ' : 'SY'
      }
      this.msgDetail.dataPath = this.$route.path

      if (this.undrMrk === 'A') {
        this.msgDetail.taskState = 'completeUdr'
      } else if (this.undrMrk === 'B') {
        this.msgDetail.taskState = 'backUdr'
      } else {
        this.msgDetail.taskState = 'reportUdr'
      }

      setSession('something', this.msgDetail)
      this.$router.push({ path: 'udrDetail', query: routeObj })
    }
  }
}
</script>

<style scoped lang="less">
.message_cell {
  .van-cell__title {
    margin: 0 10px;
    .message_title {
      display: flex;
      justify-content: space-between;
      span:nth-child(1) {
        font-size: 30px;
        color: #101010;
      }
      span:nth-child(2) {
        font-size: 26px;
        color: #bec2c9;
      }
    }
    .van-cell__label {
      font-size: 26px;
      color: #999999;
    }
  }
}

.msg_cell {
  .van-cell__title {
    border-radius: 8px;
    box-shadow: 0px 1px 4px 0px rgb(179 192 210);
    padding: 30px;
    .list_cell_title {
      display: flex;
      justify-content: space-between;
      margin-bottom: 16px;
      .list_cell_name {
        font-size: 35px;
        font-weight: 900;
      }
      .list_cell_icon {
        .van-tag {
          margin-right: 10px;
        }
      }
    }
    .van-cell__label {
      & > div {
        margin-bottom: 16px;
        font-size: 30px;
        span {
          color: #333333;
        }
      }
    }
  }
}

.msg_img {
  position: absolute;
  bottom: 50px;
  right: 62px;
  width: 128px;
  height: 128px;
}
</style>
