<template>
  <div>
    <!-- 导航 -->
    <van-nav-bar title="消息中心" fixed placeholder>
      <template #left>
        <span v-if="multipleCheck" @click="cancelDel" style="color:#999999">取消</span>
      </template>
      <template #right>
        <van-image
          class="readImg"
          :src="require(`@img/message/read_${readFlag}.png`)"
          v-if="!multipleCheck"
          @click="readClick"
        />
        <span v-else style="color:#ea0b18" @click="msgBatchDel">删除</span>
      </template>
    </van-nav-bar>

    <!-- 下拉刷新上拉加载 -->
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh" v-show="listFlag">
      <van-list v-model="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
        <!-- 复选框 -->
        <van-checkbox-group v-model="checkboxList" ref="checkboxGroup">
          <!-- 滑动单元格 -->
          <van-swipe-cell v-for="(item, index) in msgList" :key="index" :disabled="multipleCheck">
            <div
              @touchstart="handlerTouchstart"
              @touchmove="handlerTouchmove"
              @touchend="handlerTouchend($event, index, item)"
            >
              <!-- 单元格 -->
              <van-cell-group>
                <van-cell class="message_cell" @click="toggle(index)">
                  <template #icon>
                    <van-image :src="require(`@img/message/${imgSrc(item.undrMrk)}.png`)">
                      <van-badge dot v-show="item.readMrk === '0'" />
                    </van-image>
                  </template>
                  <template #right-icon>
                    <van-checkbox :name="item.messageId" v-show="multipleCheck" ref="checkboxes" />
                  </template>
                  <template #label>
                    <div
                      :class="[
                        multipleCheck ? 'message_label_s' : 'message_label_b',
                        'van-ellipsis'
                      ]"
                    >
                      {{ labelSrc(item) }}
                    </div>
                  </template>
                  <template #title>
                    <div class="message_title">
                      <span>{{ titleSrc(item.undrMrk) }}</span>
                      <span>{{ item.messageTime }}</span>
                    </div>
                  </template>
                </van-cell>
              </van-cell-group>
            </div>
            <template #right>
              <van-button square type="danger" text="删除" @click="msgDel(item)" />
            </template>
          </van-swipe-cell>
        </van-checkbox-group>
      </van-list>
    </van-pull-refresh>

    <van-empty description="暂无数据" v-show="!listFlag" />
  </div>
</template>

<script>
import { getMessage, readAllMsg, delMsg, getDoingTask } from '@/api'
import { setSession, setLocal, getLocal } from '@/utils/storage'
export default {
  name: 'Message',
  data() {
    return {
      loop: null, // 定时器
      longClick: false, // 长按
      multipleCheck: false, // 多处要用到的判断
      readFlag: 'selected', // 全部已读
      listFlag: true, // 暂无数据显示与否
      checkboxList: [], // 复选框集合
      msgList: [], // 消息列表
      udrList: [], // 待核保列表
      loading: false, // 加载
      finished: false, // 完成
      refreshing: false, // 刷新
      newUdr: '', // 待核保单数量
      messageTime: '', // 待核保单时间
      doingDel: false, // 待核保删除标识
      doingDot: false, // 待核保已读标识
      filterForm: {
        PageIndex: 1,
        PageSize: 10
      }
    }
  },
  computed: {
    imgSrc() {
      return function(value) {
        if (value === 'A') {
          return 'pass'
        } else if (value === 'B') {
          return 'back'
        } else if (value === 'C') {
          return 'report'
        }
        return 'doing'
      }
    },
    titleSrc() {
      return function(value) {
        if (value === 'A') {
          return '申请单通过'
        } else if (value === 'B') {
          return '申请单退回'
        } else if (value === 'C') {
          return '申请单上报'
        }
        return '待核保单'
      }
    },
    labelSrc() {
      return function(item) {
        if (item.undrMrk === 'A') {
          return `投保人${item.CAppNme}，车牌号${item.CPlateNo}，审核通过`
        } else if (item.undrMrk === 'B') {
          return `投保人${item.CAppNme}，车牌号${item.CPlateNo}，审核退回`
        } else if (item.undrMrk === 'C') {
          return `投保人${item.CAppNme}，车牌号${item.CPlateNo}，核保上报`
        }
        return `有${item.newUdr}个待核保清单，请迅速处理`
      }
    }
  },
  methods: {
    toggle(index) {
      if (this.multipleCheck) {
        this.$refs.checkboxes[index].toggle()
      }
    },
    // 获取消息列表
    async messageInit() {
      const res = await getMessage(this.filterForm)
      console.log(res, '消息列表')
      if (res && res.status === 1) {
        this.doingTaskInit().then(() => {
          console.log(this.udrList, '待核保列表')
          if (res.data.length < this.filterForm.PageSize) {
            this.finished = true
          }

          if (this.filterForm.PageIndex === 1) {
            this.msgList = this.udrList.concat(res.data)
          } else {
            this.msgList = this.msgList.concat(res.data)
          }
          console.log(this.msgList, '新列表')
          console.log(this.finished, 'finished状态')
          this.loading = false
          this.refreshing = false
          this.filterForm.PageIndex++
        })
      } else {
        this.finished = true
        const doingMsg = getLocal('doingMsg')
        if (this.filterForm.PageIndex === 1) {
          if (doingMsg && !doingMsg.doingDel) {
            this.doingTaskInit()
            this.msgList = this.udrList
          } else {
            this.listFlag = false
          }
        }
      }
    },

    // 获取待核保任务
    async doingTaskInit() {
      this.udrList = []

      const res = await getDoingTask()
      console.log(res, '待核保任务数量')
      if (res && res.status === 1) {
        this.newUdr = res.data.newUdr
        this.messageTime = res.data.messageTime
        const doingMsg = getLocal('doingMsg')
        if (!doingMsg) {
          this.newUdrPush('0')
        } else {
          if (Number(doingMsg.doingNum) !== Number(this.newUdr)) {
            this.newUdrPush('0')
            return
          }
          if (!doingMsg.doingDel) {
            const read = doingMsg.doingDot ? '1' : '0'
            this.newUdrPush(read)
          }
        }
      } else {
        this.$toast.fail('获取待核保任务失败')
      }
    },

    // 下拉加载
    onLoad() {
      this.messageInit()
    },

    // 上拉刷新
    onRefresh() {
      this.resetLoad()
    },

    // 触摸
    handlerTouchstart() {
      this.longClick = false
      this.loop = setTimeout(() => {
        this.longClick = true
        // 此处为长按事件-----
        this.multipleCheck = true
      }, 500)
    },

    // 移动
    handlerTouchmove() {
      // 清除定时器
      clearTimeout(this.loop)
      this.loop = null
    },

    // 抬起
    async handlerTouchend(e, index, item) {
      if (this.longClick) {
        e.preventDefault()
      }
      // 清除定时器
      clearTimeout(this.loop)
      if (this.loop && !this.longClick) {
        // 此处为点击事件----
        if (!this.multipleCheck) {
          if (item.undrMrk === 'D') {
            this.newUdrDot()
          } else {
            this.$router.push('/msgDetail')
            setSession('messageQ', {
              cAppNo: item.cAppNo,
              undrMrk: item.undrMrk,
              messageId: item.messageId
            })
          }
        } else {
          // console.log(index)
          // this.$refs.checkboxes[index].toggle()
        }
      }
    },

    // 删除
    async msgDel(item) {
      if (item.undrMrk === 'D') {
        this.newUdrDel()
      } else {
        this.$toast.loading({
          message: '加载中...',
          forbidClick: true,
          duration: 0
        })
        const res = await delMsg({
          appNoList: [item.cAppNo],
          messageIds: [item.messageId]
        })
        console.log(res, '消息单条删除')
        if (res && res.status === 1) {
          this.$toast.success('删除成功')
          this.resetLoad()
        } else {
          this.$toast.fail('删除失败')
        }
      }
    },

    // 批量删除
    async msgBatchDel() {
      if (this.checkboxList.length === 0) {
        this.$toast('请先勾选数据')
        return
      }
      let doingFlag = false
      const num = this.checkboxList.indexOf('invalid')
      if (num !== -1) {
        if (this.checkboxList.length === 1) {
          this.newUdrDel()
          this.cancelDel()
          return
        } else {
          doingFlag = true
          this.checkboxList.splice(num, 1)
        }
      }

      const appList = []
      this.msgList.forEach(item => {
        this.checkboxList.forEach(value => {
          if (Number(item.messageId) === Number(value)) {
            appList.push(item.cAppNo)
          }
        })
      })
      console.log(this.checkboxList, '复选框ID集合')
      console.log(appList, '复选框保单号集合')
      const res = await delMsg({
        appNoList: appList,
        messageIds: this.checkboxList
      })
      console.log(res, '批量删除')
      if (res && res.status === 1) {
        this.$toast.success('批量删除成功')
        this.multipleCheck = false
        this.resetLoad()
        if (doingFlag) {
          this.newUdrDel()
        }
      } else {
        this.$toast.fail('删除失败')
        if (doingFlag) {
          this.$refs.checkboxes[0].toggle(true)
        }
      }
    },

    // 取消删除
    cancelDel() {
      this.$refs.checkboxGroup.toggleAll(false)
      this.multipleCheck = false
    },

    // 全部已读
    async readClick() {
      this.readFlag = 'default'
      setTimeout(() => {
        this.readFlag = 'selected'
      }, 3000)
      const res = await readAllMsg()
      console.log(res, '全部已读')
      if (res && res.status === 1) {
        this.newUdrDot()
      } else {
        this.$toast.fail('全部已读失败')
      }
    },

    // 待核保单删除操作
    newUdrDel() {
      this.msgList.shift()
      if (this.msgList.length === 0) {
        this.listFlag = false
      }
      this.doingDel = true
      setLocal('doingMsg', {
        doingNum: this.newUdr,
        doingDel: this.doingDel,
        doingDot: false
      })
    },

    // 待核保单已读操作
    newUdrDot() {
      this.doingDot = true
      setLocal('doingMsg', {
        doingNum: this.newUdr,
        doingDel: this.doingDel,
        doingDot: this.doingDot
      })
      this.resetLoad()
    },

    // 像数组中添加待核保任务
    newUdrPush(read) {
      this.udrList.unshift({
        cAppNo: 'invalid',
        messageId: 'invalid',
        messageTime: this.messageTime,
        newUdr: this.newUdr,
        readMrk: read,
        undrMrk: 'D'
      })
      setLocal('doingMsg', {
        doingNum: this.newUdr,
        doingDel: this.doingDel,
        doingDot: this.doingDot
      })
    },

    // 重新触发加载
    resetLoad() {
      this.filterForm.PageIndex = 1
      this.finished = false
      this.loading = true
      this.messageInit()
    }
  }
}
</script>

<style scoped lang="less">
.message_cell {
  align-items: center;
  .van-image {
    width: 70px;
    height: 70px;
    .van-badge {
      position: absolute;
      top: 0;
      right: 0;
      width: 20px;
      height: 20px;
    }
  }
  .van-cell__title {
    margin: 0 10px;
    .message_title {
      display: flex;
      justify-content: space-between;
      span:nth-child(1) {
        font-size: 30px;
        color: #101010;
      }
      span:nth-child(2) {
        font-size: 26px;
        color: #bec2c9;
      }
    }
    .van-cell__label {
      font-size: 26px;
      color: #999999;
    }
  }
}

.van-swipe-cell__right {
  .van-button {
    height: 100%;
  }
}

.message_label_b {
  width: 590px;
}

.message_label_s {
  width: 550px;
}

.readImg {
  width: 40px;
  height: 40px;
}
</style>
