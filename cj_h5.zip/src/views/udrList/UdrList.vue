<template>
  <div class="public_box">
    <van-sticky>
      <!-- 导航 -->
      <van-nav-bar
        :title="udrTitle"
        left-arrow
        @click-left="$router.push('/policy')"
        class="white_bar"
      >
        <template #right>
          <van-icon :name="ascFlag" @click="ascChange" class="special_icon" />
        </template>
      </van-nav-bar>

      <!-- 搜索 -->
      <form action="/">
        <van-search
          class="public_search"
          v-model="searchValue"
          placeholder="申请单号、投保人、车牌号"
          shape="round"
          @search="onSearch"
        >
          <template #right-icon>
            <van-icon name="search" @click="onSearch" />
          </template>
          <template #left-icon>
            <van-dropdown-menu active-color="#1989fa">
              <van-dropdown-item v-model="searchType" :options="searchTypeList" />
            </van-dropdown-menu>
          </template>
        </van-search>
      </form>

      <!-- 筛选 -->
      <van-dropdown-menu
        :close-on-click-outside="false"
        active-color="#1989fa"
        style="border-top:1px solid #ebedf0"
      >
        <van-dropdown-item
          v-model="filterForm.billType"
          :options="billTypeList"
          @change="onSearch"
        />
        <van-dropdown-item v-model="filterForm.dptCode" :options="dptCodeList" @change="onSearch" />
        <van-dropdown-item
          ref="sortTypeRef"
          v-model="filterForm.sortType"
          :options="sortTypeList"
          @change="onSortSearch"
          @open="sortTypeOpen"
        />
      </van-dropdown-menu>
    </van-sticky>

    <!-- 列表区 -->
    <My-list
      v-show="listFlag"
      :to="'/udrDetail'"
      :list="udrList"
      @listRefresh="listRefresh"
      @listLoad="listLoad"
      ref="myList"
    />

    <!-- 列表区无数据时展示 -->
    <van-empty description="暂无数据" v-show="!listFlag" />

    <!-- 选择时间框 -->
    <van-calendar
      v-model="showCalendar"
      type="range"
      @confirm="onConfirm"
      color="#5088ff"
      allow-same-day
      :max-range="31"
      range-prompt="时间跨度不能超过一个月"
      :min-date="new Date(1990, 0, 1)"
      :max-date="new Date()"
      :default-date="defaultTime"
      @close="onClose"
    >
      <template #title>
        <van-cell :title="codeValue" icon="notes-o" />
      </template>
    </van-calendar>
  </div>
</template>

<script>
import MyList from '@/components/MyList'
import { getUdrList, getDptInfo } from '@/api'
import { getLocal } from '@/utils/storage'
import { onListLoad } from '@/mixins'
import { dateFormat } from '@/utils/filiters'
export default {
  name: 'UdrList',
  components: {
    MyList
  },
  mixins: [onListLoad],
  data() {
    return {
      udrTitle: '',
      searchValue: '',
      searchType: 'appNo',
      searchTypeList: [
        { text: '投保人', value: 'appName' },
        { text: '申请单号', value: 'appNo' },
        { text: '车牌号', value: 'vhlPlateNo' }
      ],
      billTypeList: [
        { text: '全部类型', value: '' },
        { text: '投保单', value: 'A' },
        { text: '批改申请单', value: 'E' }
      ],
      dptCodeList: [{ text: '全部机构', value: '' }],
      sortTypeList: [
        { text: '全部时间', value: 'alltime' },
        { text: '一个月', value: 'amonth' },
        { text: '自定义', value: 'customize' }
      ],
      filterForm: {
        billType: '',
        dptCode: '',
        sortType: 'alltime',
        startDate: '',
        endDate: '',
        userCode: '',
        taskState: '',
        sortFlag: 'desc',
        pageNo: 1,
        pageSize: 5
      },
      showCalendar: false,
      codeValue: '请选择日期',
      defaultTime: [new Date(), new Date()],
      ascFlag: 'descending'
    }
  },
  created() {
    this.judgeTitle()
    this.judgeTime()
    this.dptInfoInit()
  },
  methods: {
    // 判断进来的时间选项
    judgeTime() {
      if (this.$route.query.id === 'newUdr' || this.$route.query.id === 'pendUdr') {
        this.filterForm.sortType = 'alltime'
        this.filterForm.startDateFlag = 2
      } else {
        this.filterForm.sortType = 'amonth'
        this.filterForm.startDateFlag = 0
      }
    },

    // 判断标题
    judgeTitle() {
      this.filterForm.userCode = getLocal('access_form').access_code
      const udrId = this.$route.query.id
      switch (udrId) {
        case 'newUdr':
          this.udrTitle = '待核保任务'
          break
        case 'pendUdr':
          this.udrTitle = '暂存任务'
          break
        case 'reportUdr':
          this.udrTitle = '已上报任务'
          break
        case 'completeUdr':
          this.udrTitle = '核保通过任务'
          break
        case 'backUdr':
          this.udrTitle = '已退回任务'
          break
        default:
          this.udrTitle = '这是一个标题'
      }
    },

    // 核保员下全部机构获取
    async dptInfoInit() {
      const res = await getDptInfo({ userCode: this.filterForm.userCode })
      if (res && res.status === 1) {
        res.data.forEach(item => {
          this.dptCodeList.push({
            text: item.cdptCnm,
            value: item.cdptCde
          })
        })
      } else {
        this.$toast.fail('获取机构请求异常')
      }
    },

    // 获取核保任务清单
    async udrListInit() {
      this.udrListBefore()
      this.publicLoad(getUdrList)
    },

    // 获取核保任务清单之前
    udrListBefore() {
      if (this.searchType === 'appName') {
        this.filterForm.appNo = ''
        this.filterForm.vhlPlateNo = ''
      }
      if (this.searchType === 'appNo') {
        this.filterForm.appName = ''
        this.filterForm.vhlPlateNo = ''
      }
      if (this.searchType === 'vhlPlateNo') {
        this.filterForm.appName = ''
        this.filterForm.appNo = ''
      }
      this.filterForm[this.searchType] = this.searchValue

      this.filterForm.taskState = this.$route.query.id
    },

    // 搜索框点击键盘上的搜索/回车按钮
    onSearch() {
      this.udrList = []
      this.filterForm.pageNo = 1
      this.$refs.myList.finished = false
      this.$refs.myList.loading = true
      this.udrListInit()
    },

    // 时间选项改变
    onSortSearch() {
      if (this.filterForm.sortType === 'customize') {
        this.showCalendar = true
      } else {
        this.codeValue = '请选择日期'
        this.defaultTime = [new Date(), new Date()]
        this.filterForm.startDate = ''
        this.filterForm.endDate = ''
        this.filterForm.startDateFlag = this.filterForm.sortType === 'alltime' ? 2 : 0
        this.onSearch()
      }
    },

    // 时间选项打开时
    sortTypeOpen() {
      if (this.filterForm.sortType === 'customize') {
        this.showCalendar = true
      }
    },

    // 时间选择完毕
    onConfirm(date) {
      const [start, end] = date
      this.filterForm.startDateFlag = 1
      this.filterForm.startDate = dateFormat(start)
      this.filterForm.endDate = dateFormat(end)
      this.codeValue = `${this.filterForm.startDate} - ${this.filterForm.endDate}`
      this.showCalendar = false
      this.$refs.sortTypeRef.toggle(false)
      this.onSearch()
    },

    // 时间框关闭时
    onClose() {
      if (this.codeValue === '请选择日期') {
        if (this.filterForm.startDateFlag === 2) {
          this.filterForm.sortType = 'alltime'
        }
        if (this.filterForm.startDateFlag === 0) {
          this.filterForm.sortType = 'amonth'
        }
      }
    },

    // 排序
    ascChange() {
      if (this.ascFlag === 'ascending') {
        this.ascFlag = 'descending'
        this.filterForm.sortFlag = 'desc'
      } else {
        this.ascFlag = 'ascending'
        this.filterForm.sortFlag = 'asc'
      }
      this.onSearch()
    }
  }
}
</script>

<style scoped lang="less">
.public_search {
  /deep/.van-dropdown-item {
    top: 200px !important;
  }
}

.special_icon {
  font-size: 44px !important;
}
</style>
