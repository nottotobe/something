<template>
  <div class="user_box">
    <!-- <van-nav-bar title="个人中心" class="blue_bar"></van-nav-bar> -->

    <van-cell center class="user_cell">
      <template #icon>
        <van-image
          round
          :src="userInfo.thumb_avatar"
          fit="cover"
          @click="viewBigImg(userInfo.avatar)"
        />
      </template>
      <template #title>
        <div class="user_name">{{ userInfo.name }}</div>
        <div class="user_type">{{ userInfo.position }}</div>
      </template>
    </van-cell>

    <van-cell title="工号" :value="code" class="public_cell" />
    <van-cell title="邮箱" :value="userInfo.email" class="public_cell" />
    <van-cell title="手机号" :value="userInfo.mobile" class="specialSty public_cell" />

    <van-cell title="组织机构" :value="DptValue" center class="public_cell" />
    <van-cell title="核保级别" :value="ClsValue" class="public_cell" />
  </div>
</template>

<script>
import { getSession, setSession, getLocal } from '@/utils/storage'
import { getDptClsInfo, getUserCenter } from '@/api'
import { ImagePreview } from 'vant'
export default {
  name: 'User',
  data() {
    return {
      DptValue: '',
      ClsValue: '',
      userInfo: {}
    }
  },
  mounted() {
    this.userCenterInit()
    this.dptClsInfoInit()
  },
  computed: {
    code() {
      return getLocal('access_form').access_code
    }
  },
  methods: {
    // 获取用户信息
    async userCenterInit() {
      if (!getSession('userInfo')) {
        const res = await getUserCenter({
          userId: getLocal('access_form').access_user
        })
        console.log(res)
        if (res && res.status === 1) {
          this.userInfo = JSON.parse(res.data)
          setSession('userInfo', res.data)
        } else {
          this.$toast.fail(res.message)
        }
      } else {
        this.userInfo = JSON.parse(getSession('userInfo'))
      }
    },

    // 获取核保员机构及级别
    async dptClsInfoInit() {
      if (!getSession('dptCls')) {
        const res = await getDptClsInfo({ userCode: getLocal('access_form').access_code })
        console.log('核保员机构及级别', res)
        if (res && res.status === 1) {
          this.DptValue = res.data.cdptCnm
          this.ClsValue = res.data.clsCnm
          setSession('dptCls', {
            DptValue: res.data.cdptCnm,
            ClsValue: res.data.clsCnm
          })
        } else {
          this.$toast.fail(res.message)
        }
      } else {
        this.DptValue = getSession('dptCls').DptValue
        this.ClsValue = getSession('dptCls').ClsValue
      }
    },

    // 查看头像大图
    viewBigImg(url) {
      ImagePreview({
        images: [url],
        showIndex: false
      })
    }
  }
}
</script>

<style scoped lang="less">
.specialSty {
  margin-bottom: 20px;
}

.user_box {
  min-height: calc(100% - 100px);
  background: #f5f5f5;
}

.user_cell {
  margin-bottom: 20px;
  .van-image {
    width: 136px;
    height: 136px;
  }
  .van-cell__title {
    padding-left: 24px;
    .user_name {
      font-weight: 700;
      font-size: 36px;
      color: #000000;
      margin-bottom: 4px;
    }
    .user_type {
      font-size: 28px;
      color: #797979;
    }
  }
}

.public_cell {
  .van-cell__title {
    flex: unset;
  }
}
</style>
