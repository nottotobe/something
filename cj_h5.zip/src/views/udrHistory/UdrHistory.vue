<template>
  <div class="public_box">
    <My-nav-bar title="历史保单信息" />

    <div class="nav_left">
      <My-scroll ref="wrapperLeft" classN="wrapper_left">
        <van-sidebar v-model="activeKey">
          <van-sidebar-item
            :title="item.title"
            v-for="(item, index) in newSidebarList"
            :key="index"
            @click="componentChange(item.commentId)"
          />
        </van-sidebar>
      </My-scroll>
    </div>

    <div class="nav_right">
      <My-scroll
        ref="wrapperRight"
        classN="wrapper_right"
        :data="componentId"
        @pullingDown="pullingDown(componentId)"
        @pullingUp="pullingUp(componentId)"
      >
        <div class="udr_history_content">
          <component :is="componentId" :infoList="newInfoList(componentId)"></component>
        </div>
      </My-scroll>
    </div>
  </div>
</template>

<script>
import {
  getUdrInfo,
  getReinsureInfo,
  getPaymentInfo,
  getClaimInfo,
  getFileList,
  getThumbnailBase64
} from '@/api'
import { getSession } from '@/utils/storage'
import MyNavBar from '@/components/MyNavBar'
import MyScroll from '@/components/MyScroll'
import HCorrect from './components/HCorrect'
import HClaim from './components/HClaim'
import HBase from './components/HBase'
import HCar from './components/HCar'
import HCoef from './components/HCoef'
import HPolicy from './components/HPolicy'
import HImage from './components/HImage'
import HPayment from './components/HPayment'
import HReinsure from './components/HReinsure'
import HVstax from './components/HVstax'
export default {
  name: 'UdrHistory',
  components: {
    MyNavBar,
    MyScroll,
    HCorrect,
    HClaim,
    HBase,
    HCar,
    HCoef,
    HPolicy,
    HImage,
    HPayment,
    HReinsure,
    HVstax
  },
  data() {
    return {
      activeKey: 0,
      componentId: '',
      sidebarList: [
        { title: '理赔信息', commentId: 'HClaim' },
        { title: '再保信息', commentId: 'HReinsure' },
        { title: '收付信息', commentId: 'HPayment' },
        { title: '基本信息', commentId: 'HBase' },
        { title: '车辆信息', commentId: 'HCar' },
        { title: '险别信息', commentId: 'HPolicy' },
        { title: '车船税', commentId: 'HVstax', itype: 'JQ' },
        { title: '系数信息', commentId: 'HCoef' },
        { title: '影像信息', commentId: 'HImage' }
      ],
      infoList: [],
      reinsureList: [],
      paymentList: [],
      claimList: [],
      imageTypeList: []
    }
  },
  computed: {
    newSidebarList() {
      const query = this.$route.query
      let newArr = []
      if (query.flag === 'JQ') {
        newArr = this.sidebarList.filter(item => {
          return item.itype !== 'SY'
        })
      }
      if (query.flag === 'SY') {
        newArr = this.sidebarList.filter(item => {
          return item.itype !== 'JQ'
        })
      }
      if (query.cType === 'E') {
        newArr.unshift({ title: '批单信息', commentId: 'HCorrect' })
      }
      return newArr
    },
    newInfoList() {
      return function(id) {
        if (id === 'HReinsure') {
          return this.reinsureList
        }
        if (id === 'HPayment') {
          return this.paymentList
        }
        if (id === 'HClaim') {
          return this.claimList
        }
        if (id === 'HImage') {
          return this.imageTypeList
        }
        return this.infoList
      }
    }
  },
  created() {
    this.udrInfoInit()
    this.reinsureInfoInit()
    this.paymentInfoInit()
    this.claimInfoInit()
    this.getCFMd5()
  },

  mounted() {},
  methods: {
    // 组件切换
    componentChange(value) {
      this.componentId = value
      this.$refs.wrapperRight.scroll.scrollTo(0, 0)
    },

    // 下拉到顶
    pullingDown(value) {
      this.pullingPublic(value, 'down')
    },

    // 上拉到底
    pullingUp(value) {
      this.pullingPublic(value, 'up')
    },

    // 拉取公共操作
    pullingPublic(value, act) {
      let keyword = ''
      let num = ''
      for (let i = 0; i < this.newSidebarList.length; i++) {
        if (value === this.newSidebarList[i].commentId) {
          if (act === 'up') {
            if (this.newSidebarList.length !== i + 1) {
              num = i + 1
            } else {
              return
            }
          } else {
            if (i !== 0) {
              num = i - 1
            } else {
              return
            }
          }
          keyword = this.newSidebarList[num].commentId
        }
      }
      setTimeout(() => {
        this.activeKey = num
        this.componentChange(keyword)
      }, 300)
    },

    // 获取保单信息
    async udrInfoInit() {
      const query = this.$route.query
      const res = await getUdrInfo({
        cAppNo: query.appNo,
        cType: query.cType,
        cProdNo: query.cProdNo
      })
      console.log(res)
      if (res && res.status === 1) {
        this.infoList = Object.assign({}, res.data)

        if (query.cType === 'E') {
          this.componentId = 'HCorrect'
        } else {
          this.componentId = 'HClaim'
        }
      } else {
        console.log('保单信息' + res.message)
      }
    },

    // 获取再保信息  测试数据可用 2000001022012000005
    async reinsureInfoInit() {
      let policyNo = ''
      if (process.env.VUE_APP_MODE === 'development') {
        policyNo = '2000001022012000005'
      } else {
        policyNo = this.$route.query.policyNo
      }
      const res = await getReinsureInfo({
        policyNo
      })
      if (res && res.status === 1) {
        this.reinsureList = Object.assign({}, res.data)
      } else {
        console.log('再保信息' + res.message)
      }
    },

    // 获取收付信息  测试数据可用 2090101002012000001
    async paymentInfoInit() {
      let policyNo = ''
      if (process.env.VUE_APP_MODE === 'development') {
        policyNo = '2090101002012000001'
      } else {
        policyNo = this.$route.query.policyNo
      }
      const res = await getPaymentInfo({
        policyNo
      })
      if (res && res.status === 1) {
        this.paymentList = res.data
      } else {
        console.log('收付信息' + res.message)
      }
    },

    // 获取理赔信息  测试数据可用 2000001022012000005
    async claimInfoInit() {
      let policyNo = ''
      if (process.env.VUE_APP_MODE === 'development') {
        policyNo = '2000001022012000005'
      } else {
        policyNo = this.$route.query.policyNo
      }
      const res = await getClaimInfo({
        policyNo
      })
      if (res && res.status === 1) {
        this.claimList = res.data
      } else {
        console.log('理赔信息' + res.message)
      }
    },

    // 获取影像md5码  测试数据可用 738286
    async getCFMd5() {
      let nid = ''
      if (process.env.VUE_APP_MODE === 'development') {
        nid = '738286'
      } else {
        nid = String(getSession('nId'))
      }
      const res = await getFileList({
        NId: nid
      })
      if (res && res.status === 1) {
        res.data.forEach((item, index) => {
          this.imageTypeList.push({ title: item.CFolderId, fileList: [] })
          item.FileList.forEach(value => {
            this.getBase64(index, value)
          })
        })
      } else {
        console.log('影像' + res.message)
      }
    },

    // 获取影像缩略图
    async getBase64(index, value) {
      const res = await getThumbnailBase64({
        CFMd5: value.CFMd5,
        CFileExt: value.CFileExt
      })

      if (res && res.status === 1) {
        this.imageTypeList[index].fileList.push({
          url: res.data.CFileBase64,
          CFMd5: value.CFMd5,
          CFileExt: value.CFileExt,
          CFId: value.CFId,
          CFName: value.CFName
        })
      } else {
        console.log('影像缩略图' + res.message)
      }
    }
  }
}
</script>

<style scoped lang="less">
.public_box {
  position: relative;
  overflow: hidden;
}

.van-nav-bar {
  position: fixed;
  width: 100%;
}
.nav_left {
  position: absolute;
  top: 92px;
  bottom: 0;
  // height: calc(100% - 92px);
  .van-sidebar {
    width: 170px;
    .van-sidebar-item--select::before {
      background: #1a9bff;
    }
    .van-sidebar-item {
      background: #f5f5f5;
    }
    .van-sidebar-item--select,
    .van-sidebar-item--select:active {
      background-color: #fff;
    }
  }
}

.nav_right {
  position: absolute;
  top: 92px;
  bottom: 0;
  right: 0;
  left: 170px;
  // height: calc(100% - 92px);
  // width: calc(100% - 190px);
  background-color: #fff;
  .udr_history_content {
    padding: 20px;
    /deep/ .history_widget {
      .van-row {
        // margin-bottom: 8px;
        font-size: 30px;
        line-height: 1.5;
        .van-col:nth-child(1) {
          color: #999999;
        }
        .van-col:nth-child(2) {
          color: #666666;
          word-wrap: break-word;
        }
      }
      .history_title {
        font-size: 30px;
        font-weight: 700;
        margin-bottom: 16px;
        &:nth-child(n + 2) {
          margin-top: 50px;
        }
      }
    }
  }
}
</style>
