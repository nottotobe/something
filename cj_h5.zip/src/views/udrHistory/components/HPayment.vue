<template>
  <div>
    <div class="history_widget" v-if="infoList.length > 0">
      <van-row class="history_title">收付信息</van-row>
      <div v-for="(item, index) in infoList" :key="index">
        <My-popover :params="item.cplyNo">
          <template #reference>
            <van-row>
              <van-col :span="10">保单号：</van-col>
              <van-col :span="14">{{ item.cplyNo | isEmpty }}</van-col>
            </van-row>
          </template>
        </My-popover>
        <My-popover :params="item.cedrNo">
          <template #reference>
            <van-row>
              <van-col :span="10">批单号：</van-col>
              <van-col :span="14">{{ item.cedrNo | isEmpty }}</van-col>
            </van-row>
          </template>
        </My-popover>
        <van-row>
          <van-col :span="10">期次：</van-col>
          <van-col :span="14">{{ item.ntms | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="10">缴费状态：</van-col>
          <van-col :span="14">{{ item.cprmSts | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="10">应缴日期：</van-col>
          <van-col :span="14">{{ item.tpayTm | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="10">保费缴纳时间：</van-col>
          <van-col :span="14">{{ item.tpaidTm | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="10">应收保费：</van-col>
          <van-col :span="14">{{ item.namt | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="10">实收保费：</van-col>
          <van-col :span="14">{{ item.ncalcPrm | isEmpty }}</van-col>
        </van-row>
        <van-divider v-if="infoList.length > 1 && index !== infoList.length - 1" />
      </div>
    </div>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import MyPopover from '@/components/MyPopover'
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'HPayment',
  components: { MyPopover },
  data() {
    return {
      listFlag: true,
      showPopover: false
    }
  },
  filters: { isEmpty },
  props: {
    infoList: {
      type: Array,
      default: () => []
    }
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
