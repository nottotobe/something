<template>
  <div>
    <div class="history_widget" v-if="list.length > 0">
      <van-row class="history_title">{{ newTitle }}</van-row>
      <van-row v-for="(item, index) in list" :key="index">
        <van-col :span="12">{{ item.name }}：</van-col>
        <van-col :span="12">{{ item.value | isEmpty }}</van-col>
      </van-row>
    </div>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import { isEmpty } from '@/utils/filiters'
import udrBox from '@/components/js/udrBox'
export default {
  name: 'HVstax',
  props: {
    infoList: {
      type: Object,
      default: () => ({})
    }
  },
  filters: { isEmpty },
  computed: {
    list() {
      const key = 'vstax'
      const oldArr = udrBox[key]
      const newArr = []
      oldArr.forEach(item => {
        for (const k in this.infoList[key]) {
          if (item.type === k) {
            item.value = this.infoList[key][k]
            newArr.push(item)
          }
        }
      })
      return newArr
    },
    newTitle() {
      return '车船税：' + this.infoList.vstax['合计(元)']
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
