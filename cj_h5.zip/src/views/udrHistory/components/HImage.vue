<template>
  <div class="history_widget">
    <van-row class="history_title">影像信息</van-row>

    <van-cell
      v-for="(value, num) in infoList"
      :key="num"
      :title="newTitle(value.title)"
      class="imageBigBox"
    >
      <template #label>
        <div class="imageBox">
          <div v-for="(item, index) in value.fileList" :key="index">
            <van-image
              v-if="imgList.indexOf(item.CFileExt) !== -1"
              :src="item.url"
              contain
              alt=""
              @click="imgPreview(item, value.title)"
            />
          </div>
        </div>
        <div class="docBox">
          <div v-for="(item, index) in value.fileList" :key="index">
            <van-cell
              v-if="docList.indexOf(item.CFileExt) !== -1"
              :title="item.CFName"
              @click="docPreview(item)"
            />
          </div>
        </div>
      </template>
    </van-cell>

    <van-empty description="暂无数据" v-show="infoList.length === 0" />

    <My-preview ref="myPreview" />
  </div>
</template>

<script>
import MyPreview from '@/components/MyPreview'
import { onImgPreview } from '@/mixins'
export default {
  name: 'HImage',
  components: {
    MyPreview
  },
  props: {
    infoList: {
      type: Array,
      default: () => []
    }
  },
  mixins: [onImgPreview],
  computed: {
    imageTypeList() {
      return this.infoList
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less">
.imageBigBox {
  padding: 0;
  margin-bottom: 20px;
  .van-cell__title {
    color: #101010;
    font-size: 26px;
  }
  .imageBox {
    display: flex;
    flex-wrap: wrap;
    .van-image {
      width: 160px;
      height: 110px;
      margin-right: 20px;
      margin-bottom: 20px;
    }
  }

  .docBox {
    .van-cell {
      padding-left: 0;
      padding-right: 0;
      .van-cell__title {
        background: #f8f8f8;
        padding: 14px 20px;
      }
    }
  }
}
</style>
