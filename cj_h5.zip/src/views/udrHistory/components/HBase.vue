<template>
  <div class="history_widget">
    <!-- -----------------------------------------基本信息----------------------------------------------- -->
    <van-row class="history_title">基本信息</van-row>
    <div v-for="(item, index) in list" :key="index">
      <My-popover
        v-if="item.type === 'cappNo' || item.type === 'cplyNo' || item.type === 'crenewPlyNO'"
        :params="item.value"
      >
        <template #reference>
          <van-row>
            <van-col :span="11">{{ item.name }}：</van-col>
            <van-col :span="13">{{ item.value | isEmpty }}</van-col>
          </van-row>
        </template>
      </My-popover>
      <van-row v-else>
        <van-col :span="11">{{ item.name }}：</van-col>
        <van-col :span="13">{{ item.value | isEmpty }}</van-col>
      </van-row>
    </div>

    <!-- -----------------------------------------投保人----------------------------------------------- -->
    <van-row class="history_title">投保人</van-row>
    <van-row>
      <van-col span="8">投保人：</van-col>
      <van-col span="16">{{ applicantInfo.cAppNme | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="8">证件类型：</van-col>
      <van-col span="16">{{ applicantInfo.cCertfCls | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="8">证件号码：</van-col>
      <van-col span="16">{{ applicantInfo.cCertfCde | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="8">联系电话：</van-col>
      <van-col span="16">{{ applicantInfo.cMobile | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="8">地址：</van-col>
      <van-col span="16">{{ applicantInfo.cClntAddr | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="8">邮编：</van-col>
      <van-col span="16">{{ applicantInfo.zipCode | isEmpty }}</van-col>
    </van-row>

    <!-- -----------------------------------------被保人----------------------------------------------- -->
    <van-row class="history_title">被保人</van-row>
    <div v-if="!insuredInfoFlag">
      <van-row>
        <van-col span="8">被保人：</van-col>
        <van-col span="16">{{ insuredInfo.cInsuredNme | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">证件类型：</van-col>
        <van-col span="16">{{ insuredInfo.cCertfCls | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">证件号码：</van-col>
        <van-col span="16">{{ insuredInfo.cCertfCde | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">联系电话：</van-col>
        <van-col span="16">{{ insuredInfo.cMobile | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">地址：</van-col>
        <van-col span="16">{{ insuredInfo.cClntAddr | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">邮编：</van-col>
        <van-col span="16">{{ insuredInfo.zipCode | isEmpty }}</van-col>
      </van-row>
    </div>
    <div v-else>
      <van-row>同投保人</van-row>
    </div>

    <!-- -----------------------------------------车主----------------------------------------------- -->
    <van-row class="history_title">车主</van-row>
    <div v-if="!vhlOwnerInfoFlag">
      <van-row>
        <van-col span="8">车主：</van-col>
        <van-col span="16">{{ vhlOwnerInfo.cOwnerNme | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">证件类型：</van-col>
        <van-col span="16">{{ vhlOwnerInfo.cCertfCls | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">证件号码：</van-col>
        <van-col span="16">{{ vhlOwnerInfo.cCertfCde | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">联系电话：</van-col>
        <van-col span="16">{{ vhlOwnerInfo.cResvTxt1 | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">地址：</van-col>
        <van-col span="16">{{ vhlOwnerInfo.cclntAddr | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">邮编：</van-col>
        <van-col span="16">{{ vhlOwnerInfo.zipCode | isEmpty }}</van-col>
      </van-row>
    </div>
    <div v-else>
      <van-row>同投保人</van-row>
    </div>
  </div>
</template>

<script>
import MyPopover from '@/components/MyPopover'
import udrBox from '@/components/js/udrBox'
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'HBase',
  components: { MyPopover },
  props: {
    infoList: {
      type: Object,
      default: () => ({})
    }
  },
  filters: { isEmpty },
  computed: {
    list() {
      const key = 'baseHisInfo'
      const newArr = udrBox[key]
      newArr.forEach(item => {
        for (const k in this.infoList[key]) {
          if (item.type === k) {
            item.value = this.infoList[key][k]
          }
        }
      })
      return newArr
    }
  },
  data() {
    return {
      applicantInfo: {},
      insuredInfo: {},
      vhlOwnerInfo: {},
      insuredInfoFlag: false,
      vhlOwnerInfoFlag: false
    }
  },
  watch: {
    infoList(newValue) {
      this.personalInfoInit(newValue)
    }
  },
  mounted() {
    this.personalInfoInit(this.infoList)
  },
  methods: {
    personalInfoInit(newValue) {
      const obj = newValue.personalInfo
      if (obj) {
        this.applicantInfo = Object.assign({}, obj.applicantInfo)
        this.insuredInfo = Object.assign({}, obj.insuredInfo)
        this.vhlOwnerInfo = Object.assign({}, obj.vhlOwnerInfo)
        if (this.insuredInfo.cCertfCde === this.applicantInfo.cCertfCde) {
          this.insuredInfoFlag = true
        }
        if (this.vhlOwnerInfo.cCertfCde === this.applicantInfo.cCertfCde) {
          this.vhlOwnerInfoFlag = true
        }
      }
    }
  }
}
</script>

<style scoped lang="less">
.longSty {
  .van-col:nth-child(1) {
    margin-bottom: 8px;
  }
  .van-col:nth-child(2) {
    line-height: 48px;
  }
}
</style>
