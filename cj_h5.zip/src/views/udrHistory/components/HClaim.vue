<template>
  <div>
    <div class="history_widget" v-if="infoList.length > 0">
      <van-row class="history_title">理赔信息</van-row>
      <div v-for="(item, index) in infoList" :key="index">
        <van-row>
          <van-col :span="7">保单号：</van-col>
          <van-col :span="17">{{ item.cplyNo | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="7">报案号：</van-col>
          <van-col :span="17">{{ item.crptNo | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="7">赔案号：</van-col>
          <van-col :span="17">{{ item.cclmNo | isEmpty }}</van-col>
        </van-row>
        <van-row v-if="item.cPlateNo">
          <van-col :span="7">车牌号：</van-col>
          <van-col :span="17">{{ item.cPlateNo | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="7">赔案状态：</van-col>
          <van-col :span="17">{{ item.cclmStatus | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="7">未决金额：</van-col>
          <van-col :span="17">{{ item.nclmAmt | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="7">出险时间：</van-col>
          <van-col :span="17">{{ item.tbsTm | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="7">起保日期：</van-col>
          <van-col :span="17">{{ item.startTime | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="7">终保日期：</van-col>
          <van-col :span="17">{{ item.endTime | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col :span="7">赔付金额：</van-col>
          <van-col :span="17">{{ item.npayAmt | isEmpty }}</van-col>
        </van-row>
        <van-divider v-if="infoList.length > 1 && index !== infoList.length - 1" />
      </div>
    </div>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'HClaim',
  data() {
    return {}
  },
  filters: { isEmpty },
  props: {
    infoList: {
      type: Array,
      default: () => []
    }
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
