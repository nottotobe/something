<template>
  <div class="history_widget">
    <van-row class="history_title">{{ newTitle }}</van-row>
    <van-row v-for="(item, index) in list" :key="index">
      <van-col :span="12">{{ item.name }}：</van-col>
      <van-col :span="12">{{ item.value | isEmpty | units(item) }}</van-col>
    </van-row>
    <van-row>
      <van-col :span="12">保单起期：</van-col>
      <van-col :span="12">{{ infoList.timeInfo.tInsrncBgnTm | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col :span="12">保单止期：</van-col>
      <van-col :span="12">{{ infoList.timeInfo.tInsrncEndTm | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col :span="12">共：</van-col>
      <van-col :span="12">
        {{ infoList.timeInfo.cTmSysCde | isEmpty | units({ unit: '天' }) }}
      </van-col>
    </van-row>

    <van-row class="history_title" v-if="infoList.cvrgInfo.length && infoList.cvrgInfo.length > 0">
      险别信息
    </van-row>
    <div v-for="(item, index) in infoList.cvrgInfo" :key="item.CCVRGNO">
      <van-row>
        <van-col :span="8">保障项目：</van-col>
        <van-col :span="16">{{ item.CNMECN | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col :span="8">保额：</van-col>
        <van-col :span="16">{{ item.NAMT | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col :span="8">保费：</van-col>
        <van-col :span="16">{{ item.NNETPRM | isEmpty | units({ unit: '元' }) }}</van-col>
      </van-row>

      <van-divider v-if="infoList.cvrgInfo.length > 1 && index !== infoList.cvrgInfo.length - 1" />
    </div>
  </div>
</template>

<script>
import { isEmpty, units } from '@/utils/filiters'
import udrBox from '@/components/js/udrBox'
export default {
  name: 'HPolicy',
  props: {
    infoList: {
      type: Object,
      default: () => ({})
    }
  },
  filters: { isEmpty, units },
  computed: {
    list() {
      const query = this.$route.query
      const key = query.cType === 'A' ? 'insuredPolicyInfo' : 'correctPolicyInfo'
      let newArr = []
      if (query.cType === 'A' && query.flag === 'SY') {
        newArr = udrBox[key].slice(1)
      } else {
        newArr = udrBox[key]
      }

      newArr.forEach(item => {
        for (const k in this.infoList[key]) {
          if (item.type === k) {
            item.value = this.infoList[key][k]
          }
        }
      })
      return newArr
    },
    newTitle() {
      const query = this.$route.query
      const key = query.cType === 'A' ? 'insuredPolicyInfo' : 'correctPolicyInfo'
      const title = query.flag === 'SY' ? '商业险：' : '交强险：'
      const cost = query.cType === 'A' ? 'prm' : 'nPrmVar'
      return title + this.infoList[key][cost] + '元'
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less">
.van-divider {
  margin: 15px 0;
}
</style>
