<template>
  <div class="history_widget">
    <!-- -----------------------------------------批改信息----------------------------------------------- -->
    <van-row class="history_title">批改信息</van-row>
    <van-row v-for="(item, index) in cInfoList" :key="index">
      <div v-if="item.name === '批文'" class="longSty">
        <van-col :span="24">{{ item.name }}：</van-col>
        <van-col :span="24">{{ item.value | isEmpty }}</van-col>
      </div>
      <div v-else>
        <van-col :span="10">{{ item.name }}：</van-col>
        <van-col :span="14">{{ item.value | isEmpty }}</van-col>
      </div>
    </van-row>

    <!-- -----------------------------------------批改原因----------------------------------------------- -->
    <van-row class="history_title">批改原因</van-row>
    <div v-for="(item, index) in reasonList" :key="'reason' + index">
      <van-row>
        <van-col span="10">批改原因：</van-col>
        <van-col span="14">{{ item.cEdrRsnNme | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="10">批改原因代码：</van-col>
        <van-col span="14">{{ item.cEdrRsnCde | isEmpty }}</van-col>
      </van-row>

      <van-divider v-if="reasonList.length > 1 && index !== reasonList.length - 1" />
    </div>

    <!-- -----------------------------------------批改比较项----------------------------------------------- -->
    <van-row class="history_title">批改比较项</van-row>
    <div v-for="(item, index) in compareList" :key="'compare' + index">
      <van-row>
        <van-col span="8">批改对象：</van-col>
        <van-col span="16">{{ item.cTabNme | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">批改项目：</van-col>
        <van-col span="16">{{ item.cFldNme | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">原值：</van-col>
        <van-col span="16">{{ item.cOldVal | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">变化：</van-col>
        <van-col span="16">{{ item.cChgVal | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col span="8">新值：</van-col>
        <van-col span="16">{{ item.cNewVal | isEmpty }}</van-col>
      </van-row>

      <van-divider v-if="compareList.length > 1 && index !== compareList.length - 1" />
    </div>
  </div>
</template>

<script>
import udrBox from '@/components/js/udrBox'
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'HCorrect',
  props: {
    infoList: {
      type: Object,
      default: () => ({})
    }
  },
  filters: { isEmpty },
  computed: {
    cInfoList() {
      const key = 'correctInfo'
      const newArr = udrBox[key]
      newArr.forEach(item => {
        for (const k in this.infoList[key]) {
          if (item.type === k) {
            item.value = this.infoList[key][k]
          }
        }
      })
      return newArr
    },
    reasonList() {
      return this.infoList.correctReason
    },
    compareList() {
      return this.infoList.correctCompare
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less">
.longSty {
  .van-col:nth-child(1) {
    margin-bottom: 8px;
  }
  .van-col:nth-child(2) {
    line-height: 48px;
  }
}
</style>
