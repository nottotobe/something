<template>
  <div class="history_widget">
    <van-row class="history_title">
      {{ $route.query.flag === 'SY' ? '商业险系数' : '交强险系数' }}
    </van-row>
    <van-row v-for="(item, index) in list" :key="index">
      <van-col :span="16">{{ item.name }}：</van-col>
      <van-col :span="8">{{ item.value | isEmpty }}</van-col>
    </van-row>
  </div>
</template>

<script>
import udrBox from '@/components/js/udrBox'
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'HCoef',
  props: {
    infoList: {
      type: Object,
      default: () => ({})
    }
  },
  filters: { isEmpty },
  computed: {
    list() {
      const query = this.$route.query
      const key = query.flag === 'SY' ? 'syPrmCoefInfo' : 'jqPrmCoefInfo'
      const newArr = udrBox[key]
      newArr.forEach(item => {
        for (const k in this.infoList[key]) {
          if (item.type === k) {
            item.value = this.infoList[key][k]
          }
        }
      })
      return newArr
    }
  },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
