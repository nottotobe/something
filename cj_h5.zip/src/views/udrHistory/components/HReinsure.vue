<template>
  <div>
    <div class="history_widget" v-if="!Array.isArray(infoList)">
      <van-row class="history_title">再保信息</van-row>
      <My-popover :params="infoList.cplyNo">
        <template #reference>
          <van-row>
            <van-col :span="12">保单号：</van-col>
            <van-col :span="12">{{ infoList.cplyNo | isEmpty }}</van-col>
          </van-row>
        </template>
      </My-popover>
      <van-row>
        <van-col :span="12">批改次数：</van-col>
        <van-col :span="12">{{ infoList.nedrPrjNo | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col :span="12">风险单位拆分序号：</van-col>
        <van-col :span="12">{{ infoList.nseqNo | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col :span="12">自留额：</van-col>
        <van-col :span="12">{{ infoList.nretAmt | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col :span="12">自留比例：</van-col>
        <van-col :span="12">{{ infoList.nfacPrpt | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col :span="12">进入合约比例：</van-col>
        <van-col :span="12">{{ infoList.ncedPrpt | isEmpty }}</van-col>
      </van-row>
      <van-row>
        <van-col :span="12">临分比例：</van-col>
        <van-col :span="12">{{ infoList.nfacPrpt | isEmpty }}</van-col>
      </van-row>
    </div>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import MyPopover from '@/components/MyPopover'
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'HReinsure',
  components: { MyPopover },
  data() {
    return {}
  },
  filters: { isEmpty },
  props: {
    infoList: {
      type: [Array, Object],
      default: () => []
    }
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
