<template>
  <div class="public_box">
    <My-nav-bar :title="typeTitle" :params="routeObj" />

    <van-tabs
      v-model="active"
      color="#fff"
      class="udr_type_tabs"
      @change="tabsChange"
      swipeable
      :sticky="sticky"
      :offset-top="offsetTop"
    >
      <div v-for="(item, index) in tabsList" :key="index">
        <van-tab :name="item.name" :to="{ query: { id: item.name } }">
          <template #title>
            <van-image :src="item.src" />
          </template>

          <component :is="item.component"></component>
        </van-tab>
      </div>
    </van-tabs>
  </div>
</template>

<script>
import { getSession } from '@/utils/storage'
import { iosScroll } from '@/mixins'
import MyNavBar from '@/components/MyNavBar'
import CarType from './components/CarType'
import CostType from './components/CostType'
import ImageType from './components/ImageType'
import RuleType from './components/RuleType'
import PolicyType from './components/PolicyType'
import ClaimType from './components/ClaimType'
export default {
  name: 'UdrType',
  components: {
    MyNavBar,
    CarType,
    CostType,
    ImageType,
    RuleType,
    PolicyType,
    ClaimType
  },
  mixins: [iosScroll],
  data() {
    return {
      typeTitle: '投保单费用信息',
      active: 'cost',
      tabsList: [
        { name: 'car', src: require('@img/info/car.png'), component: 'CarType' },
        { name: 'cost', src: require('@img/info/cost.png'), component: 'CostType' },
        { name: 'image', src: require('@img/info/image_d.png'), component: 'ImageType' },
        { name: 'rule', src: require('@img/info/rule_d.png'), component: 'RuleType' },
        { name: 'policy', src: require('@img/info/policy_d.png'), component: 'PolicyType' },
        { name: 'claim', src: require('@img/info/claim_d.png'), component: 'ClaimType' }
      ]
    }
  },
  watch: {
    $route(to, from) {
      this.judgeTitle()
    }
  },
  created() {
    this.judgeTitle()
    this.getBackParams()
  },
  mounted() {},
  methods: {
    // 当前激活的标签改变时触发
    tabsChange(name) {
      this.$router.push(`/udrType?id=${name}`)
    },

    // 判断标题
    judgeTitle() {
      const typeId = this.$route.query.id
      if (typeId) {
        this.active = typeId
        this.tabsList.forEach(item => {
          if (item.name === typeId) {
            item.src = require(`@img/info/${item.name}.png`)
          } else {
            item.src = require(`@img/info/${item.name}_d.png`)
          }
        })
        switch (typeId) {
          case 'car':
            this.typeTitle = '车型纯风险保费'
            break
          case 'cost':
            this.typeTitle = '投保单费用信息'
            break
          case 'image':
            this.typeTitle = '影像信息'
            break
          case 'rule':
            this.typeTitle = '规则信息'
            break
          case 'policy':
            this.typeTitle = '历史保单'
            break
          case 'claim':
            this.typeTitle = '历史赔案'
            break
        }
      }
    },

    // 回退操作参数
    getBackParams() {
      const something = getSession('something')

      if (something.cProdNo === '0350') {
        this.tabsList.splice(0, 1)
      }

      this.routeObj = {
        path: 'udrDetail',
        query: {
          appNo: something.appNo,
          cProdNo: something.cProdNo,
          cType: something.cType,
          flag: something.cProdNo === '0350' ? 'JQ' : 'SY'
        }
      }
    }
  }
}
</script>

<style scoped lang="less">
.public_box {
  display: flex;
  flex-direction: column;
}

/deep/ .udr_type_tabs {
  display: flex;
  flex: 1;
  flex-direction: column;
  .van-tabs__wrap {
    height: 104px;
    .van-tab {
      .van-image {
        width: 64px;
        height: 64px;
        vertical-align: middle;
      }
    }
  }
  .van-tabs__content {
    flex: 1;
  }
}
</style>
