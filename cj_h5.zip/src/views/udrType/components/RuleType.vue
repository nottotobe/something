<template>
  <div>
    <My-info-box title="规则平台返回信息">
      <template #other>
        <div v-if="ruleList.length > 0">
          <div v-for="(item, index) in ruleList" :key="index" class="public_info_box_other">
            <van-row>
              <van-col span="6">序号：</van-col>
              <van-col span="18">{{ item.id | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col span="6">规则ID：</van-col>
              <van-col span="18">{{ item.ruleId | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col span="6">规则描述：</van-col>
              <van-col span="18">{{ item.ruleDes | isEmpty }}</van-col>
            </van-row>

            <van-divider v-if="ruleList.length > 1 && index !== ruleList.length - 1" />
          </div>
        </div>
        <van-empty description="暂无数据" v-else />
      </template>
    </My-info-box>
  </div>
</template>

<script>
import MyInfoBox from '@/components/MyInfoBox'
import { isEmpty } from '@/utils/filiters'
import { getSession } from '@/utils/storage'
import { getRuleInfo } from '@/api'
export default {
  name: 'RuleType',
  components: {
    MyInfoBox
  },
  data() {
    return {
      ruleList: []
    }
  },
  filters: { isEmpty },
  created() {
    this.ruleInfoInit()
  },
  methods: {
    async ruleInfoInit() {
      this.$toast.loading({
        message: '加载中...',
        forbidClick: true,
        duration: 0
      })
      const appNo = getSession('something').appNo
      const res = await getRuleInfo({
        appNo
      })
      if (res && res.status === 1) {
        this.ruleList = res.data
        this.$toast.clear()
      } else {
        this.$toast.fail(res.message)
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
