<template>
  <div>
    <My-info-box title="车辆信息" keyword="carBaseInfo" :obj="carList[0]" span="9"> </My-info-box>
    <My-info-box title="车损险纯风险保费信息" keyword="cvrgBaseInfo" :obj="cvrgList[0]" span="9">
    </My-info-box>
  </div>
</template>

<script>
import MyInfoBox from '@/components/MyInfoBox'
import { isEmpty } from '@/utils/filiters'
import { getRiskInfo } from '@/api'
import { getSession } from '@/utils/storage'
export default {
  name: 'CarType',
  components: {
    MyInfoBox
  },
  filters: { isEmpty },
  data() {
    return {
      carList: [],
      cvrgList: []
    }
  },
  mounted() {
    this.riskInfoInit()
  },
  methods: {
    async riskInfoInit() {
      this.$toast.loading({
        message: '加载中...',
        forbidClick: true,
        duration: 0
      })

      const something = getSession('something')
      const res = await getRiskInfo({
        cAppNo: something.appNo
      })
      if (res && res.status === 1) {
        this.carList = res.data.base
        this.cvrgList = res.data.cvrg
        this.$toast.clear()
      } else {
        this.$toast.fail(res.message)
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
