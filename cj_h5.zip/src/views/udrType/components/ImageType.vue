<template>
  <div>
    <div v-for="(value, num) in imageTypeList" :key="num">
      <My-info-box :title="newTitle(value.title)">
        <template #other>
          <div class="imageBox">
            <div v-for="(item, index) in value.fileList" :key="index">
              <!-- {{ item.CFName }} -->
              <van-image
                v-if="imgList.indexOf(item.CFileExt) !== -1"
                :src="item.url"
                contain
                alt=""
                @click="imgPreview(item, value.title)"
              />
            </div>
          </div>
          <div class="docBox">
            <div v-for="(item, index) in value.fileList" :key="index">
              <van-cell
                v-if="docList.indexOf(item.CFileExt) !== -1"
                :title="item.CFName"
                @click="docPreview(item)"
              />
            </div>
          </div>
        </template>
      </My-info-box>
    </div>

    <van-empty description="暂无数据" v-show="imageListEmpty" />

    <My-preview ref="myPreview" />
  </div>
</template>

<script>
import MyInfoBox from '@/components/MyInfoBox'
import MyPreview from '@/components/MyPreview'
import { getFileList, getThumbnailBase64 } from '@/api'
import { getSession } from '@/utils/storage'
import { onImgPreview } from '@/mixins'
export default {
  name: 'ImageType',
  components: {
    MyInfoBox,
    MyPreview
  },
  mixins: [onImgPreview],
  data() {
    return {
      imageListEmpty: false,
      imageTypeList: []
    }
  },
  mounted() {
    this.getCFMd5()
  },
  methods: {
    // 获取md5码
    async getCFMd5() {
      this.$toast.loading({
        message: '加载中...',
        forbidClick: true,
        duration: 0
      })

      // 测试数据可用 738286
      let nid = ''
      if (process.env.VUE_APP_MODE === 'development') {
        nid = '738286'
      } else {
        nid = getSession('nId') ? getSession('nId') : getSession('something').appNo
      }
      const res = await getFileList({
        NId: String(nid)
      })
      console.log(res)
      if (res && res.status === 1) {
        res.data.forEach((item, index) => {
          this.imageTypeList.push({ title: item.CFolderId, fileList: [] })
          item.FileList.forEach(value => {
            this.getBase64(index, value)
          })
        })
      } else {
        this.imageListEmpty = true
      }
      this.$toast.clear()
    },

    // 获取缩略图
    async getBase64(index, value) {
      const res = await getThumbnailBase64({
        CFMd5: value.CFMd5,
        CFileExt: value.CFileExt
      })

      if (res && res.status === 1) {
        this.imageTypeList[index].fileList.push({
          url: res.data.CFileBase64,
          CFMd5: value.CFMd5,
          CFileExt: value.CFileExt,
          CFId: value.CFId,
          CFName: value.CFName
        })
      }
    }
  }
}
</script>

<style scoped lang="less">
.imageBox {
  display: flex;
  flex-wrap: wrap;
  .van-image {
    width: 190px;
    height: 120px;
    margin-right: 30px;
    margin-bottom: 30px;
  }
}

.docBox {
  .van-cell {
    padding-left: 0;
    padding-right: 0;
    .van-cell__title {
      background: #f8f8f8;
      padding: 14px 20px;
    }
  }
}
</style>
