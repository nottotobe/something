<template>
  <div>
    <My-list
      v-show="listFlag"
      :to="'/udrHistory'"
      :list="udrList"
      @listRefresh="listRefresh"
      @listLoad="listLoad"
      ref="myList"
    />
    <van-empty description="暂无数据" v-show="!listFlag" />
  </div>
</template>

<script>
import { getSession } from '@/utils/storage'
import { getHisPolicyInfo } from '@/api'
import MyList from '@/components/MyList'
export default {
  name: 'PolicyType',
  components: {
    MyList
  },
  data() {
    return {
      udrList: [],
      listFlag: true
    }
  },
  mounted() {},
  methods: {
    // 获取核保任务清单
    async udrListInit() {
      const res = await getHisPolicyInfo({
        cFrmNo: getSession('something').cFrmNo,
        appNo: getSession('something').appNo
      })

      if (res && res.status === 1) {
        console.log(res)
        this.listFlag = true
        this.udrList = res.data
        this.$refs.myList.finished = true
        this.$refs.myList.loading = false
        this.$refs.myList.refreshing = false
      } else {
        this.listFlag = false
      }
    },

    // 下拉加载的回调
    listLoad() {
      this.udrListInit()
    },

    // 上拉刷新的回调
    listRefresh() {
      this.$refs.myList.finished = false
      this.$refs.myList.loading = true
      this.udrListInit()
    }
  }
}
</script>

<style scoped lang="less"></style>
