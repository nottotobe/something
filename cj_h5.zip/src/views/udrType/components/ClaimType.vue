<template>
  <div>
    <My-info-box :title="filterForm.appName">
      <template #other>
        <div class="public_info_box_other">
          <van-row>
            <van-col span="6">客户证件号：</van-col>
            <van-col span="18">{{ filterForm.certfCde }}</van-col>
          </van-row>
          <van-row>
            <van-col span="6">手机号：</van-col>
            <van-col span="18">{{ filterForm.cMobile }}</van-col>
          </van-row>
        </div>
        <van-tag color="#d9e9ff" text-color="#6085ff" class="claim_type_tag" size="large"
          >投保人</van-tag
        >
      </template>
    </My-info-box>

    <My-info-box title="客户年度统计信息">
      <template #other>
        <van-row class="public_table_title">
          <van-col span="8">年度</van-col>
          <van-col span="8">承保件数</van-col>
          <van-col span="8">理赔件数</van-col>
        </van-row>
        <div v-if="yearList.length > 0">
          <van-row class="public_table_content" v-for="(item, index) in yearList" :key="index">
            <van-col span="8">{{ item.policyYear }}</van-col>
            <van-col span="8" @click="toYearStats('policy', item.policyYear, item.plyCount)">
              {{ item.plyCount }}
            </van-col>
            <van-col span="8" @click="toYearStats('claim', item.policyYear, item.clmCount)">
              {{ item.clmCount }}
            </van-col>
          </van-row>
        </div>
        <div v-else>
          <van-row class="public_table_content">
            <van-col span="24" style="text-align:center;padding:10px 0">暂无数据</van-col>
          </van-row>
        </div>
      </template>
    </My-info-box>
  </div>
</template>

<script>
import MyInfoBox from '@/components/MyInfoBox'
import { getSession } from '@/utils/storage'
import { getYearList } from '@/api'
export default {
  name: 'ClaimType',
  components: {
    MyInfoBox
  },
  data() {
    return {
      filterForm: {
        appName: '',
        certfCde: '',
        cMobile: ''
      },
      yearList: []
    }
  },
  created() {
    this.claimTypeInit()
  },
  mounted() {},
  methods: {
    // 初始化
    async claimTypeInit() {
      this.$toast.loading({
        message: '加载中...',
        forbidClick: true,
        duration: 0
      })

      const getSome = getSession('something')
      this.filterForm.appName = getSome.appName
      this.filterForm.certfCde = getSome.certfCde
      this.filterForm.cMobile = getSome.cMobile
      const res = await getYearList({
        clientNme: this.filterForm.appName,
        certCde: this.filterForm.certfCde
      })
      console.log(res)
      if (res && res.status === 1) {
        this.yearList = res.data.concat()
        this.yearList.reverse()
        this.$toast.clear()
      } else {
        this.$toast.fail(res.message)
      }
    },

    // 查看详细信息
    toYearStats(type, year, num) {
      if (Number(num) === 0) {
        if (type === 'policy') {
          this.$toast('暂无承保件数')
        } else {
          this.$toast('暂无理赔件数')
        }
        return
      }
      this.$router.push({
        path: '/yearStats',
        query: {
          type,
          year
        }
      })
    }
  }
}
</script>

<style scoped lang="less">
.claim_type_tag {
  position: absolute;
  top: 104px;
  right: 24px;
}
</style>
