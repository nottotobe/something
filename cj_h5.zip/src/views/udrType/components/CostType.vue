<template>
  <div>
    <div v-for="(item, index) in costList" :key="index">
      <My-info-box :title="item.cfeeTypNme | isEmpty">
        <template #other>
          <div class="public_des_table">
            <van-row>
              <van-col span="10">比例（%）</van-col>
              <van-col span="14">{{ item.nfeeProp | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col span="10">金额</van-col>
              <van-col span="14">{{ item.nfee | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col span="10">增值税税率（%）</van-col>
              <van-col span="14">{{ item.nfeeVatProp | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col span="10">金额（不含税）</van-col>
              <van-col span="14">{{ item.nnetFee | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col span="10">增值税</van-col>
              <van-col span="14">{{ item.nvatAmt | isEmpty }}</van-col>
            </van-row>
            <van-row>
              <van-col span="10">下限（%）</van-col>
              <!-- <van-col span="14">{{ item.nminPrmProp | isEmpty }}</van-col> -->
              <van-col span="14">-</van-col>
            </van-row>
            <van-row>
              <van-col span="10">上限（%）</van-col>
              <!-- <van-col span="14">{{ item.nmaxAmtProp | isEmpty }}</van-col> -->
              <van-col span="14">-</van-col>
            </van-row>
            <van-row>
              <van-col span="10">说明</van-col>
              <van-col span="14">{{ item.cfeeDesc | isEmpty }}</van-col>
            </van-row>
          </div>
        </template>
      </My-info-box>
    </div>
  </div>
</template>

<script>
import MyInfoBox from '@/components/MyInfoBox'
import { isEmpty } from '@/utils/filiters'
import { getSession } from '@/utils/storage'
import { getFeeInfo } from '@/api'
export default {
  name: 'CostType',
  components: {
    MyInfoBox
  },
  filters: { isEmpty },
  data() {
    return {
      costList: []
    }
  },
  mounted() {
    this.feeInfoInit()
  },
  methods: {
    async feeInfoInit() {
      this.$toast.loading({
        message: '加载中...',
        forbidClick: true,
        duration: 0
      })

      const appNo = getSession('something').appNo
      const res = await getFeeInfo({
        appNo
      })
      console.log(res)
      if (res && res.status === 1) {
        this.costList = res.data
        this.$toast.clear()
      } else {
        this.$toast.fail(res.message)
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
