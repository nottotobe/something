<template>
  <div class="history_box">
    <van-cell title="历史记录" center class="history_title">
      <van-icon name="delete-o" @click="onDelete" v-show="deleteFlag" />
      <div v-show="!deleteFlag">
        <span @click="deleteAll">全部删除</span>
        <span>&nbsp;|&nbsp;</span>
        <span @click="onFinish">完成</span>
      </div>
    </van-cell>

    <div v-if="historyList.length > 0" class="history_content">
      <div v-for="(item, index) in historyList" :key="index">
        <van-tag
          size="large"
          type="primary"
          color="#F8F8F8"
          text-color="#4D4A4A"
          :closeable="!deleteFlag"
          @close="onClose(item)"
          @click="onClick(item)"
        >
          {{ item }}
        </van-tag>
      </div>
    </div>

    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
export default {
  name: 'History',
  props: {
    historyList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      deleteFlag: true
    }
  },
  mounted() {},
  methods: {
    // 点击删除图标
    onDelete() {
      this.deleteFlag = false
    },

    // 点击完成
    onFinish() {
      this.deleteFlag = true
    },

    // 点击标签关闭图标
    onClose(value) {
      this.$emit('historyDel', value)
    },

    // 点击删除全部
    deleteAll() {
      this.$dialog
        .confirm({
          title: '确认要清空吗？'
        })
        .then(() => {
          this.$emit('historyAll')
          this.deleteFlag = true
        })
        .catch(() => {
          // on cancel
        })
    },

    // 点击标签
    onClick(value) {
      if (!this.deleteFlag) return
      this.$emit('historySearch', value)
    }
  }
}
</script>

<style scoped lang="less">
.history_box {
  background: #fff;
  .history_title {
    font-size: 32px;
    .van-icon {
      vertical-align: middle;
    }
  }
  .history_content {
    display: flex;
    flex-wrap: wrap;
    padding-top: 20px;
    padding-left: 20px;

    .van-tag {
      margin-right: 20px;
      margin-bottom: 20px;
    }
  }
}
</style>
