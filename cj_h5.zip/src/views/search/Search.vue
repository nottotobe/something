<template>
  <div class="public_box">
    <van-sticky>
      <form action="/">
        <van-search
          class="public_search"
          v-model.trim="searchValue"
          placeholder="申请单号、投保人、车牌号"
          shape="round"
          show-action
          @search="onSearch"
          @cancel="onCancel"
          @input="onInput"
        >
          <template #right-icon>
            <van-icon name="search" @click="onSearch" />
          </template>
          <template #left-icon>
            <van-dropdown-menu active-color="#1989fa">
              <van-dropdown-item v-model="searchType" :options="searchTypeList" />
            </van-dropdown-menu>
          </template>
        </van-search>
      </form>
    </van-sticky>

    <History
      :historyList="historyList"
      v-show="historyFlag"
      @historySearch="historySearch"
      @historyDel="historyDel"
      @historyAll="historyAll"
    />
    <My-list
      v-show="listFlag && !historyFlag"
      :to="'/udrDetail'"
      :list="udrList"
      @listRefresh="listRefresh"
      @listLoad="listLoad"
      ref="myList"
    />
    <van-empty description="暂无数据" v-show="!listFlag && !historyFlag" />
  </div>
</template>

<script>
import MyList from '@/components/MyList'
import { getUdrList } from '@/api'
import { setLocal, getLocal, removeLocal } from '@/utils/storage'
import History from './components/History'
import { onListLoad } from '@/mixins'
export default {
  name: 'Search',
  mixins: [onListLoad],
  data() {
    return {
      searchValue: '',
      searchType: 'appNo',
      searchTypeList: [
        { text: '投保人', value: 'appName' },
        { text: '申请单号', value: 'appNo' },
        { text: '车牌号', value: 'vhlPlateNo' }
      ],
      filterForm: {
        userCode: '',
        taskState: '',
        pageNo: 1,
        pageSize: 5
      },
      historyFlag: true,
      historyList: []
    }
  },
  components: {
    History,
    MyList
  },
  created() {
    this.filterForm.userCode = getLocal('access_form').access_code
  },
  mounted() {
    this.showHistory()
  },
  methods: {
    // 输入框内容变化时触发
    onInput(value) {
      if (!value) {
        this.historyFlag = true
      }
    },

    // 点击取消按钮时触发
    onCancel() {
      this.$router.push('/policy')
    },

    // 搜索框点击键盘上的搜索/回车按钮
    onSearch() {
      this.udrList = []
      this.filterForm.pageNo = 1
      this.$refs.myList.finished = false
      this.$refs.myList.loading = true
      this.saveHistory(this.searchValue)
      this.udrListInit()
    },

    // 获取核保任务清单
    async udrListInit() {
      this.udrListBefore()
      this.historyFlag = false
      this.publicLoad(getUdrList)
    },

    // 获取核保任务清单之前
    udrListBefore() {
      if (this.searchType === 'appName') {
        this.filterForm.appNo = ''
        this.filterForm.vhlPlateNo = ''
      }
      if (this.searchType === 'appNo') {
        this.filterForm.appName = ''
        this.filterForm.vhlPlateNo = ''
      }
      if (this.searchType === 'vhlPlateNo') {
        this.filterForm.appName = ''
        this.filterForm.appNo = ''
      }
      this.filterForm[this.searchType] = this.searchValue
    },

    // 初始化历史记录
    showHistory() {
      if (getLocal('historyList')) {
        this.historyList = getLocal('historyList')
      }
    },

    // 搜索成功后保存历史记录
    saveHistory(value) {
      if (!value) return
      if (getLocal('historyList')) {
        this.historyList = getLocal('historyList')
        const num = this.historyList.indexOf(value)
        if (num !== -1) {
          this.historyList.splice(num, 1)
        }
        this.historyList.unshift(value)
        if (this.historyList.length > 5) {
          this.historyList.splice(this.historyList.length - 1, 1)
        }
        setLocal('historyList', this.historyList)
      } else {
        this.historyList.unshift(value)
        setLocal('historyList', this.historyList)
      }
    },

    // 点击历史记录标签的回调
    historySearch(value) {
      console.log(this.filterForm)
      this.searchValue = value
      this.udrList = []
      this.filterForm.pageNo = 1
      this.$refs.myList.finished = false
      this.$refs.myList.loading = true
      this.udrListInit()
    },

    // 点击历史记录标签删除的回调
    historyDel(value) {
      this.historyList = getLocal('historyList')
      const num = this.historyList.indexOf(value)
      this.historyList.splice(num, 1)
      setLocal('historyList', this.historyList)
    },

    // 点击全部删除的回调
    historyAll() {
      this.historyList = []
      removeLocal('historyList')
    }
  }
}
</script>

<style scoped lang="less">
.public_search {
  /deep/ .van-dropdown-item {
    top: 100px !important;
  }
}
</style>
