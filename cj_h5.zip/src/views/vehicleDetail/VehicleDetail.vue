<template>
  <div class="public_box">
    <My-nav-bar title="车型详情" />
    <My-info-box title="车型详情" keyword="vehicleDetail" :obj="VehicleDetailObj" span="9" />
  </div>
</template>

<script>
import MyNavBar from '@/components/MyNavBar'
import MyInfoBox from '@/components/MyInfoBox'
import { getVehicleDetail } from '@/api'
export default {
  name: 'VehicleDetail',
  components: { MyNavBar, MyInfoBox },
  data() {
    return {
      VehicleDetailObj: {}
    }
  },
  mounted() {
    this.vehicleDetailInit()
  },
  methods: {
    async vehicleDetailInit() {
      const res = await getVehicleDetail({
        vehicleModelCode: this.$route.query.code
      })
      if (res && res.status === 1) {
        this.VehicleDetailObj = res.data.Vehicle[0]
      } else {
        this.$toast.fail('车型详情请求异常')
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
