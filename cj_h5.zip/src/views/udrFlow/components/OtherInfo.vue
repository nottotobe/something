<template>
  <div class="public_info_box_other">
    <van-row>
      <van-col span="7">核保通过时间：</van-col>
      <van-col span="17">{{ newPar.tUdrTm | isEmpty }}</van-col>
    </van-row>
    <van-row>
      <van-col span="7">核保缴费时间：</van-col>
      <van-col span="17">{{ newPar.tPayConfTm | isEmpty }}</van-col>
    </van-row>
  </div>
</template>

<script>
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'OtherInfo',
  props: {
    par: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    newPar() {
      if (this.par) {
        return this.par
      }
      return {}
    }
  },
  data() {
    return {}
  },
  filters: { isEmpty },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
