<template>
  <div>
    <div v-if="par.length > 0">
      <div v-for="(item, index) in par" :key="index" class="public_info_box_other">
        <van-row>
          <van-col span="7">任务名称：</van-col>
          <van-col span="17">{{ item.curtTaskName | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="7">任务类型：</van-col>
          <van-col span="17">{{ item.typess | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="7">接收人：</van-col>
          <van-col span="17">{{ item.curtUserName | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="7">接收时间：</van-col>
          <van-col span="17">{{ item.acptTm | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="7">完成时间：</van-col>
          <van-col span="17">{{ item.cmptTm | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="7">任务分发机构：</van-col>
          <van-col span="17">{{ item.preDptName | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="7">任务分发时间：</van-col>
          <van-col span="17">{{ item.crtTm | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="7">目的机构：</van-col>
          <van-col span="17">{{ item.dptName | isEmpty }}</van-col>
        </van-row>
        <van-row>
          <van-col span="7">目的角色：</van-col>
          <van-col span="17">{{ item.opgrpName | isEmpty }}</van-col>
        </van-row>
        <van-divider v-if="par.length > 1 && index !== par.length - 1" />
      </div>
    </div>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'TaskInfo',
  props: {
    par: {
      type: Array,
      default: () => []
    }
  },
  filters: { isEmpty },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
