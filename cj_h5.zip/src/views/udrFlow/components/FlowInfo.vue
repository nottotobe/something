<template>
  <div>
    <div v-if="par.length > 0">
      <van-steps direction="vertical" :active="0" class="flow_steps">
        <van-step v-for="(item, index) in par" :key="index">
          <template #active-icon>
            {{ par.length }}
          </template>
          <template #inactive-icon>
            {{ par.length - index }}
          </template>
          <van-cell>
            <template #title>
              <div>
                <span style="font-weight:900">{{ item.cUndrMrk }}</span>
                &nbsp;/ {{ item.cUndrCnm }}
              </div>
              <div>
                {{ item.tUndrTm }}
              </div>
              <div>
                {{ item.cUndrOpn | isEmpty }}
              </div>
            </template>
          </van-cell>
        </van-step>
      </van-steps>
    </div>
    <van-empty description="暂无数据" v-else />
  </div>
</template>

<script>
import { isEmpty } from '@/utils/filiters'
export default {
  name: 'FlowInfo',
  props: {
    par: {
      type: Array,
      default: () => []
    }
  },
  filters: { isEmpty },
  data() {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less">
.flow_steps {
  /deep/ .van-step {
    .van-step__circle-container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 40px;
      width: 40px;
      border-radius: 50%;
      background: #c6cad5;
      color: #fff;
      top: 50%;
      left: -52px;
      transform: translateY(-50%);
    }
  }

  /deep/ .van-step:last-child .van-step__line {
    width: 1px;
  }

  /deep/ .van-step--process {
    .van-step__circle-container {
      background: #5980ff;
    }
  }
}
</style>
