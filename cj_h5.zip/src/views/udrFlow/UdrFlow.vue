<template>
  <div class="public_box">
    <My-nav-bar title="投保单流程" />

    <My-info-box title="任务信息">
      <template #other>
        <Task-info :par="flowObj.taskInfo" />
      </template>
    </My-info-box>

    <My-info-box title="流程节点">
      <template #other>
        <Flow-info :par="flowObj.underwritingOpinionInfo" />
      </template>
    </My-info-box>

    <My-info-box title="其他信息">
      <template #other>
        <Other-info :par="flowObj.otherInfo" />
      </template>
    </My-info-box>
  </div>
</template>

<script>
import MyNavBar from '@/components/MyNavBar'
import MyInfoBox from '@/components/MyInfoBox'
import FlowInfo from './components/FlowInfo'
import OtherInfo from './components/OtherInfo'
import TaskInfo from './components/TaskInfo'
import { getUdrFlow } from '@/api'
export default {
  name: 'UdrFlow',
  components: { MyNavBar, MyInfoBox, FlowInfo, OtherInfo, TaskInfo },
  data() {
    return {
      flowObj: {}
    }
  },
  mounted() {
    this.udrFlowInit()
  },
  methods: {
    async udrFlowInit() {
      // 测试可用  1035011002020000011  U
      const query = this.$route.query
      const res = await getUdrFlow({
        cAppNo: query.appNo,
        cType: query.type === 'reportUdr' ? 'E' : 'U',
        pageNo: 1,
        pageSize: 10
      })
      console.log(res)
      if (res && res.status === 1) {
        this.flowObj = Object.assign({}, res.data)
      } else {
        this.$toast.fail('核保流程请求异常')
      }
    }
  }
}
</script>

<style scoped lang="less"></style>
