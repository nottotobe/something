<template>
  <div class="policy_box">
    <!-- 在版本更新时候提示语 -->
    <van-notice-bar :text="noticeMsg" v-if="noticeMsg" @click="noticeClick" color="#000000" />

    <!-- 导航 -->
    <!-- <van-nav-bar title="车险移动核保" class="blue_bar"></van-nav-bar> -->

    <!-- 轮播图 -->
    <van-swipe class="policy_swipe" :autoplay="3000" indicator-color="white">
      <van-swipe-item v-for="(image, index) in bannerList" :key="index">
        <van-image lazy-load :src="image" />
      </van-swipe-item>
    </van-swipe>

    <!-- 搜索跳转 -->
    <van-button class="policy_btn" size="large" to="/search">
      <span>申请单号、投保人、车牌号</span>
      <van-icon name="search" />
    </van-button>

    <!-- 验车码 -->
    <van-cell title="车险核保" class="policy_cell" :border="false" to="/vehicleCode">
      <span>今日验车码:</span>
      <span class="carCode">{{ todayCarCode }}</span>
      <van-icon name="notes-o" />
    </van-cell>

    <!-- 核保清单宫格 -->
    <van-grid :column-num="2" :border="false" :gutter="10" direction="horizontal">
      <van-grid-item
        v-for="(item, index) in taskList"
        :key="index"
        class="policy_grid_item"
        :to="{
          path: '/udrList',
          query: {
            id: item.id
          }
        }"
      >
        <div slot="icon">
          <van-image :src="item.src" />
        </div>
        <div slot="text" class="policy_text">
          <div class="textNum">{{ item.textNum }}</div>
          <div class="textName">{{ item.textName }}</div>
        </div>
      </van-grid-item>
    </van-grid>
  </div>
</template>

<script>
import { loginToken, getCarTask, getTodayCarCode, QYlogin, getMaintainDetail } from '@/api/index'
import { getLocal, setLocal, getSession, setSession } from '@/utils/storage'
export default {
  name: 'Policy',
  data() {
    return {
      value: '',
      active: 0,
      todayCarCode: '',
      loginError: false,
      noticeMsg: '',
      bannerList: [require('@img/task/banner1.png')],
      taskList: [
        {
          id: 'newUdr',
          textNum: '',
          textName: '待核保任务',
          src: require('@img/task/newUdr.png')
        },
        {
          id: 'pendUdr',
          textNum: '',
          textName: '暂存任务',
          src: require('@img/task/pendUdr.png')
        },
        {
          id: 'reportUdr',
          textNum: '',
          textName: '已上报任务',
          src: require('@img/task/reportUdr.png')
        },
        {
          id: 'completeUdr',
          textNum: '',
          textName: '核保通过任务',
          src: require('@img/task/completeUdr.png')
        },
        {
          id: 'backUdr',
          textNum: '',
          textName: '已退回任务',
          src: require('@img/task/backUdr.png')
        }
      ]
    }
  },
  created() {
    console.log(process.env)

    if (!getLocal('access_form')) {
      this.loginInit().then(() => {
        if (!this.loginError) {
          this.todayCarCodeInit()
          this.carTaskInit()
          this.maintainDetailInit()
        }
      })
    } else {
      this.todayCarCodeInit()
      this.carTaskInit()
      this.maintainDetailInit()
    }
  },
  mounted() {},
  methods: {
    // 初始化
    async loginInit() {
      if (process.env.NODE_ENV !== 'development') {
        await this.qywxLogin()
      } else {
        await this.webLogin()
      }
    },

    // 调试H5登陆
    async webLogin() {
      const res = await loginToken({
        account: '000776',
        password: '1'
      })
      const accessToken = res.access_token
      setLocal('access_form', {
        access_token: accessToken,
        access_user: 'wangrunxian',
        access_code: '000776'
      })
    },

    // 企业微信登陆
    async qywxLogin() {
      console.log(window.location, 'href')
      console.log(this.getQueryString('code'), 'code')
      console.log(this.loginError)
      console.log(this.$store.state.codeErrorFlag)
      if (this.getQueryString('code') && !this.$store.state.codeErrorFlag) {
        const res = await QYlogin({ code: this.getQueryString('code') })
        console.log(res)
        if (res && res.status === 1) {
          setLocal('access_form', {
            access_token: res.data.token.access_token,
            access_user: res.data.wxUserId,
            access_code: res.data.hxOperId
          })
        } else {
          this.$toast(res.message)
          this.loginError = true
          this.$store.commit('codeError', {
            codeFlag: true,
            codeMsg: res.message
          })
        }
      }
    },

    // 获取URL参数 传入字段名称
    getQueryString(name) {
      const reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i')
      const r = window.location.search.substr(1).match(reg)
      if (r != null) {
        return decodeURIComponent(r[2])
      }
      return null
    },

    // 获取列表数据
    async carTaskInit() {
      this.$toast.loading({
        message: '加载中...',
        forbidClick: true,
        duration: 0
      })
      const res = await getCarTask()
      this.$toast.clear()
      this.taskList.forEach(item => {
        for (const k in res) {
          if (item.id === k) {
            item.textNum = res[k]
          }
        }
      })
    },

    // 获取今日验车码
    async todayCarCodeInit() {
      if (!getSession('todayCarCode')) {
        const res = await getTodayCarCode({
          pageNo: 1,
          pageSize: 25
        })

        if (res.status === 1) {
          this.todayCarCode = res.data[0].verifyCode
          setSession('todayCarCode', this.todayCarCode)
        } else {
          this.todayCarCode = '-'
        }
      } else {
        this.todayCarCode = getSession('todayCarCode')
      }
    },

    // 维护消息提示
    async maintainDetailInit() {
      const res = await getMaintainDetail()
      console.log(res)
      if (res && res.status === 1) {
        if (res.data.length > 0) {
          this.noticeMsg = res.data[0].msgContent
        }
      }
    },

    // 维护消息点击
    noticeClick() {
      const that = this
      this.$dialog.alert({
        title: '温馨提示',
        message: that.noticeMsg,
        confirmButtonText: '已了解',
        confirmButtonColor: '#0076FF'
      })
    }
  }
}
</script>

<style scoped lang="less">
.policy_box {
  // 轮播图
  .policy_swipe {
    height: 360px;
    .van-image {
      width: 100%;
      height: 100%;
    }
  }

  // 搜索框
  .policy_btn {
    background: #f5f5f5;
    padding: 12px;
    .van-button__content {
      background: #fff;
      border-radius: 16px;
      .van-button__text {
        padding: 20px;
        width: 100%;
        display: flex;
        justify-content: space-between;
        color: #c4c6ca;
        .van-icon {
          color: #848486;
        }
      }
    }
  }

  // 标题
  .policy_cell {
    margin-bottom: 10px;
    .van-cell__title {
      font-weight: 900;
      font-size: 36px;
    }
    .van-cell__value {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      font-size: 26px;
      line-height: 26px;
      .carCode {
        margin: 0 10px;
        color: #5982ff;
      }
      .van-icon {
        font-size: 36px;
      }
    }
  }

  // 宫格
  .policy_grid_item {
    /deep/ .van-grid-item__content {
      border-radius: 8px;
      box-shadow: 0px 1px 4px 0px rgba(179, 192, 210, 30);
      display: flex;
      justify-content: flex-start;
      .van-image {
        width: 100px;
        height: 100px;
        vertical-align: middle;
      }
      .policy_text {
        margin-left: 15px;
        .textNum {
          max-width: 196px;
          white-space: nowrap;
          text-overflow: ellipsis;
          overflow: hidden;
          font-size: 50px;
          font-weight: 900;
        }
        .textName {
          max-width: 196px;
          white-space: nowrap;
          text-overflow: ellipsis;
          overflow: hidden;
          font-size: 32px;
        }
      }
    }
  }
}
</style>
