<template>
  <div class="public_box">
    <van-sticky>
      <My-nav-bar title="历史验车码" params="/policy" />

      <van-search
        v-model="codeValue"
        placeholder="请输入搜索关键词"
        shape="round"
        class="car_code_search"
        @focus="showCalendar = true"
        :clearable="false"
        readonly
      >
        <template #left-icon>
          <van-icon name="notes-o" />
        </template>
      </van-search>
    </van-sticky>

    <van-calendar
      v-model="showCalendar"
      type="range"
      @confirm="onConfirm"
      :show-confirm="false"
      color="#5088ff"
      allow-same-day
      :min-date="new Date(minTime, 0, 1)"
      :max-date="new Date()"
      :default-date="defaultTime"
      @open="onOpen"
    />

    <My-list @listRefresh="listRefresh" @listLoad="listLoad" ref="myList" v-show="listFlag">
      <template #other>
        <van-cell
          v-for="(item, index) in udrList"
          :key="index"
          :title="item.currentDate"
          :value="item.verifyCode"
        />
      </template>
    </My-list>

    <van-empty description="暂无数据" v-show="!listFlag" />
  </div>
</template>

<script>
import MyNavBar from '@/components/MyNavBar'
import MyList from '@/components/MyList'
import { dateFormat, checkTime } from '@/utils/filiters'
import { getTodayCarCode } from '@/api/index'
import { onListLoad } from '@/mixins'
export default {
  name: 'vehicleCode',
  components: { MyNavBar, MyList },
  mixins: [onListLoad],
  data() {
    return {
      minTime: null,
      defaultTime: [],
      codeValue: '',
      showCalendar: false,
      filterForm: {
        startDate: '',
        endDate: '',
        pageNo: 1,
        pageSize: 25
      }
    }
  },
  mounted() {
    this.codeInit()
  },
  methods: {
    // 初始化
    codeInit() {
      const nowTime = new Date()
      nowTime.setMonth(nowTime.getMonth() - 1)
      this.filterForm.startDate = dateFormat(nowTime)
      this.filterForm.endDate = dateFormat(new Date())
      this.codeValue = `${this.filterForm.startDate} - ${this.filterForm.endDate}`
      this.defaultTime = [nowTime, new Date()]
      this.minTime = new Date().getFullYear() - 1
    },

    // 获取历史验证码列表
    async udrListInit() {
      this.publicLoad(getTodayCarCode)
    },

    // 打开弹出层时触发
    onOpen() {
      const newStr = this.codeValue.split('-')
      this.defaultTime = [new Date(newStr[0]), new Date(newStr[1])]
    },

    // 日期选择完成后触发
    onConfirm(date) {
      const [start, end] = date
      this.filterForm.startDate = dateFormat(start)
      this.filterForm.endDate = dateFormat(end)
      if (!checkTime(this.filterForm.startDate, this.filterForm.endDate)) {
        this.$toast('时间跨度不能超过三个月')
        return
      }
      this.codeValue = `${this.filterForm.startDate} - ${this.filterForm.endDate}`
      this.udrList = []
      this.showCalendar = false
      this.filterForm.pageNo = 1
      this.$refs.myList.finished = false
      this.$refs.myList.loading = true
      this.udrListInit()
    }
  }
}
</script>

<style scoped lang="less">
.car_code_search {
  margin-bottom: 20px;
  .van-field__left-icon,
  .van-search__action {
    div {
      color: #5982ff;
      font-size: 28px;
    }
    .van-icon {
      font-size: 36px;
      color: #5982ff;
    }
  }
}
</style>
