<template>
  <div class="public_box">
    <van-sticky>
      <My-nav-bar title="车辆查询" />

      <form action="/">
        <van-search
          v-model="filterForm.queryStr"
          placeholder="请输入品牌型号"
          shape="round"
          @search="onSearch"
          show-action
        >
          <template #action>
            <div @click="onSearch">搜索</div>
          </template>
        </van-search>
      </form>
    </van-sticky>

    <My-list
      @listRefresh="listRefresh"
      @listLoad="listLoad"
      ref="myList"
      v-show="listFlag"
      :icheck="false"
    >
      <template #other>
        <van-card
          v-for="(item, index) in udrList"
          :key="index"
          class="vehicle_query_list"
          :title="item.VehicleName + '  ' + item.Remark"
          :desc="item.VehicleCode + ' / ' + item.BrandName"
          @click="toDetail(item)"
        >
          <template #price>
            <span style="color:red">¥{{ item.PurchasePrice | isEmpty }}</span>
          </template>
          <template #origin-price>
            <span>上市年月 {{ newMarketDate(item.MarketDate) | isEmpty }}</span>
          </template>
        </van-card>
      </template>
    </My-list>

    <van-empty description="暂无数据" v-show="!listFlag" />
  </div>
</template>

<script>
import MyNavBar from '@/components/MyNavBar'
import MyList from '@/components/MyList'
import { getVehicleQuery } from '@/api'
import { getSession, removeSession } from '@/utils/storage'
import { isEmpty } from '@/utils/filiters'
import { onListLoad } from '@/mixins'
export default {
  name: 'VehicleQuery',
  components: { MyNavBar, MyList },
  filters: { isEmpty },
  mixins: [onListLoad],
  data() {
    return {
      filterForm: {
        queryStr: '',
        pageNo: 1,
        pageSize: 10
      }
    }
  },
  computed: {
    newMarketDate() {
      return function(value) {
        if (value) {
          var year = value.slice(0, 4)
          var mouth = value.slice(-2)
          return year + '-' + mouth
        }
        return value
      }
    }
  },
  mounted() {},
  activated() {
    if (getSession('vehicleQueryWD')) {
      this.filterForm.queryStr = getSession('vehicleQueryWD')
      this.filterForm.pageNo = 1
      this.udrList = []
      this.$refs.myList.finished = false
      this.$refs.myList.loading = true
      this.udrListInit()
    }
  },
  methods: {
    // 获取精友车辆查询
    async udrListInit() {
      this.publicLoad(getVehicleQuery)
    },

    // 搜索框点击键盘上的搜索/回车按钮
    onSearch() {
      if (!this.filterForm.queryStr.trim()) {
        this.$toast('请输入关键字')
        return
      }
      this.udrList = []
      this.filterForm.pageNo = 1
      this.$refs.myList.finished = false
      this.$refs.myList.loading = true
      this.udrListInit()
    },

    // 去车型详情
    toDetail(item) {
      this.$router.push({
        path: '/vehicleDetail',
        query: {
          code: item.VehicleCode
        }
      })
      removeSession('vehicleQueryWD')
    }
  }
}
</script>

<style scoped lang="less">
.vehicle_query_list {
  background: #fff;
  .van-card__title {
    color: #101010;
    font-size: 28px;
  }
  .van-card__desc {
    color: #4d4a4a;
    font-size: 22px;
    margin-top: 14px;
  }
  .van-card__bottom {
    display: flex;
    justify-content: space-between;
    .van-card__origin-price {
      text-decoration: unset;
    }
  }
}
</style>
