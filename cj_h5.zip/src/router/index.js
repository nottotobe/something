import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '../store'
import { Toast } from 'vant'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: '/main'
  },
  {
    path: '/main',
    name: 'Main',
    redirect: '/policy',
    component: () => import(/* webpackChunkName: "main" */ '@/views/main/Main'),
    children: [
      {
        path: '/policy',
        name: 'Policy',
        component: () => import(/* webpackChunkName: "main" */ '@/views/policy/Policy'),
        meta: {
          title: '车险移动核保'
        }
      },
      {
        path: '/message',
        name: 'Message',
        component: () => import(/* webpackChunkName: "message" */ '@/views/message/Message'),
        meta: {
          title: '消息中心'
        }
      },
      {
        path: '/user',
        name: 'User',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/User'),
        meta: {
          title: '个人中心'
        }
      }
    ]
  },
  {
    path: '/msgDetail',
    name: 'msgDetail',
    component: () =>
      import(/* webpackChunkName: "msgDetail" */ '@/views/message/components/MsgDetail')
  },
  {
    path: '/search',
    name: 'search',
    component: () => import(/* webpackChunkName: "search" */ '@/views/search/Search')
  },
  {
    path: '/udrList',
    name: 'udrList',
    component: () => import(/* webpackChunkName: "udrList" */ '@/views/udrList/UdrList')
  },
  {
    path: '/udrDetail',
    name: 'udrDetail',
    component: () => import(/* webpackChunkName: "udrDetail" */ '@/views/udrDetail/UdrDetail')
  },
  {
    path: '/udrType',
    name: 'udrType',
    component: () => import(/* webpackChunkName: "udrType" */ '@/views/udrType/UdrType')
  },
  {
    path: '/udrHistory',
    name: 'udrHistory',
    component: () => import(/* webpackChunkName: "udrHistory" */ '@/views/udrHistory/UdrHistory')
  },
  {
    path: '/udrFlow',
    name: 'udrFlow',
    component: () => import(/* webpackChunkName: "udrFlow" */ '@/views/udrFlow/UdrFlow')
  },
  {
    path: '/vehicleType',
    name: 'vehicleType',
    component: () => import(/* webpackChunkName: "vehicleType" */ '@/views/vehicleType/VehicleType')
  },
  {
    path: '/vehicleQuery',
    name: 'vehicleQuery',
    component: () =>
      import(/* webpackChunkName: "vehicleQuery" */ '@/views/vehicleQuery/VehicleQuery'),
    meta: {
      keepAlive: true
    }
  },
  {
    path: '/vehicleDetail',
    name: 'vehicleDetail',
    component: () =>
      import(/* webpackChunkName: "vehicleDetail" */ '@/views/vehicleDetail/VehicleDetail')
  },
  {
    path: '/vehicleCode',
    name: 'vehicleCode',
    component: () => import(/* webpackChunkName: "vehicleCode" */ '@/views/vehicleCode/VehicleCode')
  },
  {
    path: '/yearStats',
    name: 'yearStats',
    component: () => import(/* webpackChunkName: "yearStats" */ '@/views/yearStats/YearStats')
  },
  {
    path: '/myTxT',
    name: 'myTxT',
    component: () => import(/* webpackChunkName: "myTxT" */ '@/components/MyTxT')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.VUE_APP_ROUTE,
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      return { x: 0, y: 0 }
    }
  }
})

router.beforeEach(function(to, from, next) {
  if (to.meta.title) {
    document.title = to.meta.title
  }

  store.commit('clearCancelToken') // 取消请求
  Toast.clear()

  next()
})

export default router
