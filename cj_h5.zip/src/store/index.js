import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    cancelTokenArr: [], // 取消请求token数组
    codeErrorFlag: false, // 未配置工号
    codeErrorMsg: '' // 未配置工号提示语
  },
  mutations: {
    // ----------------------start-----------------------------
    pushCancelToken({ cancelTokenArr }, payload) {
      cancelTokenArr.push(payload.cancelToken)
    },
    clearCancelToken({ cancelTokenArr }) {
      cancelTokenArr.forEach(item => {
        item('路由跳转取消请求')
      })
      cancelTokenArr = []
    },
    // ----------------------end-----------------------------

    // ----------------------start-----------------------------
    codeError(state, obj) {
      state.codeErrorFlag = obj.codeFlag
      state.codeErrorMsg = obj.codeMsg
    }
    // ----------------------end-----------------------------
  },
  actions: {},
  modules: {}
})
